# ARQUITECTURA DEL SISTEMA

## Estructura de Paquetes

```
com.gymsystem
├── config/        → Configuración global (conexión BD, propiedades)
├── model/         → Entidades del dominio (POJO/POCO)
├── dao/           → Interfaces DAO (contratos de acceso a datos)
├── dao/impl/      → Implementaciones JDBC de los DAO
├── service/       → Interfaces de servicios (lógica de negocio)
├── service/impl/  → Implementaciones de servicios
├── controller/    → Controladores (preparado para Vaadin)
├── dto/           → Objetos de transferencia de datos
├── util/          → Utilidades transversales
├── exception/     → Excepciones personalizadas del sistema
└── validator/     → Validadores de negocio
└── security/      → Autenticación, autorización, BCrypt
```

## Responsabilidades

| Paquete | Responsabilidad |
|---------|----------------|
| config | Configuración de conexión a BD vía HikariCP, carga de properties |
| model | Clases de dominio anémicas con atributos, getters/setters, equals/hashCode |
| dao | Interfaces DAO genéricas con CRUD básico y operaciones específicas |
| dao/impl | Implementaciones JDBC con PreparedStatement, manejo de ResultSet |
| service | Interfaces con contratos de lógica de negocio |
| service/impl | Implementaciones con validaciones, reglas de negocio, transacciones |
| controller | Puntos de entrada (preparado para la capa de presentación Vaadin) |
| dto | Clases ligeras para transferencia entre capas sin exponer entidades |
| util | Funciones helper (formateo, cálculos, constantes) |
| exception | Jerarquía de excepciones (NotFoundException, DuplicateException, etc.) |
| validator | Validación de reglas de negocio antes de persistir |
| security | Login, BCrypt, manejo de sesiones, control de roles (RBAC) |
