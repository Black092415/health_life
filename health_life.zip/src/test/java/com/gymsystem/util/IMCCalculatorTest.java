package com.gymsystem.util;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class IMCCalculatorTest {

    @Test
    void testCalcularIMC() {
        BigDecimal imc = IMCCalculator.calcular(
                BigDecimal.valueOf(70),
                BigDecimal.valueOf(1.75));
        assertEquals(0, BigDecimal.valueOf(22.86).compareTo(imc));
    }

    @Test
    void testClasificacionNormal() {
        BigDecimal imc = BigDecimal.valueOf(22.0);
        assertEquals("Peso normal", IMCCalculator.clasificar(imc));
    }

    @Test
    void testClasificacionSobrepeso() {
        BigDecimal imc = BigDecimal.valueOf(27.0);
        assertEquals("Sobrepeso", IMCCalculator.clasificar(imc));
    }

    @Test
    void testClasificacionObesidad() {
        BigDecimal imc = BigDecimal.valueOf(32.0);
        assertEquals("Obesidad tipo I", IMCCalculator.clasificar(imc));
    }

    @Test
    void testClasificacionInfrapeso() {
        BigDecimal imc = BigDecimal.valueOf(17.0);
        assertEquals("Infrapeso moderado", IMCCalculator.clasificar(imc));
    }

    @Test
    void testClasificacionNull() {
        assertEquals("Desconocido", IMCCalculator.clasificar(null));
    }

    @Test
    void testAlturaCeroRetornaNull() {
        BigDecimal resultado = IMCCalculator.calcular(BigDecimal.valueOf(70), BigDecimal.ZERO);
        assertNull(resultado);
    }

    @Test
    void testCalcularDouble() {
        double imc = IMCCalculator.calcular(70.0, 1.75);
        assertEquals(22.86, imc, 0.01);
    }
}
