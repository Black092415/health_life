package com.gymsystem.service;

import com.gymsystem.dao.EjercicioDAO;
import com.gymsystem.model.Ejercicio;
import com.gymsystem.service.impl.EjercicioServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EjercicioServiceTest {

    @Mock
    private EjercicioDAO ejercicioDAO;

    private EjercicioService ejercicioService;

    @BeforeEach
    void setUp() {
        ejercicioService = new EjercicioServiceImpl(ejercicioDAO);
    }

    @Test
    void testCrearEjercicio() {
        Ejercicio ejercicio = new Ejercicio("Press Banca", "Pecho", "fuerza");
        when(ejercicioDAO.save(any())).thenAnswer(i -> {
            Ejercicio e = i.getArgument(0);
            e.setId(1L);
            return e;
        });

        Ejercicio saved = ejercicioService.crearEjercicio(ejercicio);
        assertNotNull(saved.getId());
        assertEquals("Press Banca", saved.getNombre());
    }

    @Test
    void testBuscarPorGrupoMuscular() {
        Ejercicio e1 = new Ejercicio("Press Banca", "Pecho", "fuerza");
        e1.setId(1L);
        Ejercicio e2 = new Ejercicio("Aperturas", "Pecho", "fuerza");
        e2.setId(2L);

        when(ejercicioDAO.findByGrupoMuscular("Pecho")).thenReturn(List.of(e1, e2));

        List<Ejercicio> resultados = ejercicioService.buscarPorGrupoMuscular("Pecho");
        assertEquals(2, resultados.size());
    }

    @Test
    void testBuscarPorIdNoEncontrado() {
        when(ejercicioDAO.findById(anyLong())).thenReturn(Optional.empty());
        assertThrows(com.gymsystem.exception.NotFoundException.class, () -> {
            ejercicioService.buscarPorId(999L);
        });
    }
}
