package com.gymsystem.service;

import com.gymsystem.dao.ClienteDAO;
import com.gymsystem.dao.MedidasCorporalesDAO;
import com.gymsystem.dao.ProgresoFisicoDAO;
import com.gymsystem.dto.EstadisticaDTO;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.exception.ValidationException;
import com.gymsystem.model.*;
import com.gymsystem.service.impl.ProgresoServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProgresoServiceTest {

    @Mock
    private ProgresoFisicoDAO progresoDAO;

    @Mock
    private MedidasCorporalesDAO medidasDAO;

    @Mock
    private ClienteDAO clienteDAO;

    private ProgresoService progresoService;

    @BeforeEach
    void setUp() {
        progresoService = new ProgresoServiceImpl(progresoDAO, medidasDAO, clienteDAO);
    }

    @Test
    void testRegistrarPesoExitoso() {
        Cliente cliente = new Cliente(1L);
        Usuario usuario = new Usuario();
        usuario.setNombre("Juan");
        usuario.setApellido("Perez");
        cliente.setUsuario(usuario);

        ProgresoFisico progreso = new ProgresoFisico(cliente, BigDecimal.valueOf(75.5));

        when(clienteDAO.findById(anyLong())).thenReturn(Optional.of(cliente));
        when(progresoDAO.save(any())).thenAnswer(i -> {
            ProgresoFisico p = i.getArgument(0);
            p.setId(1L);
            return p;
        });

        ProgresoFisico resultado = progresoService.registrarPeso(progreso);

        assertNotNull(resultado.getId());
        assertEquals(0, BigDecimal.valueOf(75.5).compareTo(resultado.getPesoKg()));
    }

    @Test
    void testRegistrarPesoNegativoLanzaExcepcion() {
        ProgresoFisico progreso = new ProgresoFisico(new Cliente(1L), BigDecimal.valueOf(-5));

        assertThrows(ValidationException.class, () -> {
            progresoService.registrarPeso(progreso);
        });
    }

    @Test
    void testGenerarEstadisticas() {
        List<ProgresoFisico> registros = List.of(
                crearProgreso(1L, BigDecimal.valueOf(80), LocalDateTime.now().minusDays(30)),
                crearProgreso(1L, BigDecimal.valueOf(78), LocalDateTime.now().minusDays(15)),
                crearProgreso(1L, BigDecimal.valueOf(75.5), LocalDateTime.now())
        );

        Cliente cliente = new Cliente(1L);
        Usuario usuario = new Usuario();
        usuario.setNombre("Juan");
        usuario.setApellido("Gomez");
        cliente.setUsuario(usuario);

        when(progresoDAO.findByClienteId(1L)).thenReturn(registros);
        when(clienteDAO.findById(1L)).thenReturn(Optional.of(cliente));
        when(medidasDAO.findByClienteId(1L)).thenReturn(List.of());

        EstadisticaDTO stats = progresoService.generarEstadisticas(1L);

        assertEquals(1L, stats.getClienteId());
        assertEquals(0, BigDecimal.valueOf(75.5).compareTo(stats.getPesoActual()));
        assertEquals(0, BigDecimal.valueOf(80).compareTo(stats.getPesoInicial()));
        assertEquals(3, stats.getTotalRegistros());
    }

    @Test
    void testClasificarIMC() {
        ProgresoFisico progreso = new ProgresoFisico(new Cliente(1L), BigDecimal.valueOf(70));
        progreso.setImc(BigDecimal.valueOf(22.86));

        String clasificacion = clasificarIMCHelper(progreso.getImc());
        assertEquals("Normal", clasificacion);
    }

    private String clasificarIMCHelper(BigDecimal imc) {
        double valor = imc.doubleValue();
        if (valor < 18.5) return "Infrapeso";
        if (valor < 25.0) return "Normal";
        if (valor < 30.0) return "Sobrepeso";
        return "Obesidad";
    }

    private ProgresoFisico crearProgreso(Long clienteId, BigDecimal peso, LocalDateTime fecha) {
        ProgresoFisico p = new ProgresoFisico(new Cliente(clienteId), peso);
        p.setId(clienteId);
        p.setFechaRegistro(fecha);
        return p;
    }
}
