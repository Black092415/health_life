package com.gymsystem.security;

import com.gymsystem.dao.SesionDAO;
import com.gymsystem.dao.UsuarioDAO;
import com.gymsystem.dto.LoginDTO;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.exception.UnauthorizedException;
import com.gymsystem.model.Sesion;
import com.gymsystem.model.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UsuarioDAO usuarioDAO;

    @Mock
    private SesionDAO sesionDAO;

    @Mock
    private PasswordService passwordService;

    private AuthService authService;

    @BeforeEach
    void setUp() {
        authService = new AuthService(usuarioDAO, sesionDAO, passwordService);
    }

    @Test
    void testLoginExitoso() {
        LoginDTO loginDTO = new LoginDTO("user@test.com", "password123");
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setEmail("user@test.com");
        usuario.setPasswordHash("$2a$10$hash");
        usuario.setActivo(true);

        when(usuarioDAO.findByEmailWithRoles(anyString())).thenReturn(Optional.of(usuario));
        when(passwordService.verifyPassword(anyString(), anyString())).thenReturn(true);
        lenient().when(sesionDAO.save(any())).thenAnswer(i -> {
            Sesion s = i.getArgument(0);
            s.setId(1L);
            return s;
        });

        Sesion sesion = authService.login(loginDTO);
        assertNotNull(sesion);
    }

    @Test
    void testLoginEmailInvalido() {
        LoginDTO loginDTO = new LoginDTO("noexiste@test.com", "password123");
        when(usuarioDAO.findByEmailWithRoles(anyString())).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> {
            authService.login(loginDTO);
        });
    }

    @Test
    void testLoginPasswordIncorrecto() {
        LoginDTO loginDTO = new LoginDTO("user@test.com", "wrongpassword");
        Usuario usuario = new Usuario();
        usuario.setEmail("user@test.com");
        usuario.setPasswordHash("$2a$10$hash");
        usuario.setActivo(true);

        when(usuarioDAO.findByEmailWithRoles(anyString())).thenReturn(Optional.of(usuario));
        when(passwordService.verifyPassword(anyString(), anyString())).thenReturn(false);

        assertThrows(UnauthorizedException.class, () -> {
            authService.login(loginDTO);
        });
    }

    @Test
    void testLoginUsuarioInactivo() {
        LoginDTO loginDTO = new LoginDTO("inactivo@test.com", "password123");
        Usuario usuario = new Usuario();
        usuario.setEmail("inactivo@test.com");
        usuario.setPasswordHash("$2a$10$hash");
        usuario.setActivo(false);

        when(usuarioDAO.findByEmailWithRoles(anyString())).thenReturn(Optional.of(usuario));

        assertThrows(UnauthorizedException.class, () -> {
            authService.login(loginDTO);
        });
    }
}
