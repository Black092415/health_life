package com.gymsystem.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PasswordServiceTest {

    private PasswordService passwordService;

    @BeforeEach
    void setUp() {
        passwordService = new PasswordService();
    }

    @Test
    void testHashPassword() {
        String hash = passwordService.hashPassword("miPassword123");
        assertNotNull(hash);
        assertTrue(hash.startsWith("$2a$"));
    }

    @Test
    void testVerifyCorrectPassword() {
        String hash = passwordService.hashPassword("miPassword123");
        assertTrue(passwordService.verifyPassword("miPassword123", hash));
    }

    @Test
    void testVerifyWrongPassword() {
        String hash = passwordService.hashPassword("miPassword123");
        assertFalse(passwordService.verifyPassword("otroPassword", hash));
    }

    @Test
    void testHashNullThrows() {
        assertThrows(IllegalArgumentException.class, () -> {
            passwordService.hashPassword(null);
        });
    }

    @Test
    void testHashEmptyThrows() {
        assertThrows(IllegalArgumentException.class, () -> {
            passwordService.hashPassword("");
        });
    }

    @Test
    void testVerifyNullReturnsFalse() {
        assertFalse(passwordService.verifyPassword(null, "hash"));
        assertFalse(passwordService.verifyPassword("pass", null));
    }
}
