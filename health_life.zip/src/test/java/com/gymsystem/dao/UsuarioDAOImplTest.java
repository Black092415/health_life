package com.gymsystem.dao;

import com.gymsystem.dao.impl.UsuarioDAOImpl;
import com.gymsystem.exception.DuplicateException;
import com.gymsystem.model.Usuario;
import org.junit.jupiter.api.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de integración para UsuarioDAOImpl.
 * Requiere conexión a PostgreSQL con la base de datos configurada.
 * Estas pruebas deben ejecutarse con un perfil de integración.
 */
@Tag("integration")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class UsuarioDAOImplTest {

    private UsuarioDAO usuarioDAO;
    private static final String TEST_EMAIL = "test@integration.com";
    private static final String TEST_USERNAME = "testuser";

    @BeforeAll
    void setUp() {
        usuarioDAO = new UsuarioDAOImpl();
    }

    @BeforeEach
    void cleanUp() {
        usuarioDAO.findByEmail(TEST_EMAIL).ifPresent(u -> usuarioDAO.delete(u.getId()));
        usuarioDAO.findByUsername(TEST_USERNAME).ifPresent(u -> usuarioDAO.delete(u.getId()));
    }

    @Test
    void testSaveAndFindById() {
        Usuario usuario = new Usuario(TEST_USERNAME, TEST_EMAIL, "$2a$10$hash", "Test", "User");
        Usuario saved = usuarioDAO.save(usuario);

        assertNotNull(saved.getId());
        assertTrue(saved.getId() > 0);

        Optional<Usuario> found = usuarioDAO.findById(saved.getId());
        assertTrue(found.isPresent());
        assertEquals(TEST_EMAIL, found.get().getEmail());
    }

    @Test
    void testFindByEmail() {
        Usuario usuario = new Usuario(TEST_USERNAME, TEST_EMAIL, "$2a$10$hash", "Test", "User");
        usuarioDAO.save(usuario);

        Optional<Usuario> found = usuarioDAO.findByEmail(TEST_EMAIL);
        assertTrue(found.isPresent());
        assertEquals(TEST_USERNAME, found.get().getUsername());
    }

    @Test
    void testSaveDuplicateEmailThrowsException() {
        Usuario usuario1 = new Usuario("user1", TEST_EMAIL, "$2a$10$hash", "Test", "User");
        usuarioDAO.save(usuario1);

        Usuario usuario2 = new Usuario("user2", TEST_EMAIL, "$2a$10$hash", "Test2", "User2");
        assertThrows(DuplicateException.class, () -> {
            usuarioDAO.save(usuario2);
        });
    }

    @Test
    void testDelete() {
        Usuario usuario = new Usuario("deleteuser", "delete@test.com", "$2a$10$hash", "Delete", "User");
        usuarioDAO.save(usuario);

        usuarioDAO.delete(usuario.getId());
        Optional<Usuario> found = usuarioDAO.findById(usuario.getId());
        assertFalse(found.isPresent());
    }
}
