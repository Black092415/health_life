package com.gymsystem.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario("jperez", "jperez@email.com", "hash123", "Juan", "Perez");
    }

    @Test
    void testCrearUsuario() {
        assertEquals("jperez", usuario.getUsername());
        assertEquals("jperez@email.com", usuario.getEmail());
        assertEquals("Juan", usuario.getNombre());
        assertEquals("Perez", usuario.getApellido());
    }

    @Test
    void testNombreCompleto() {
        assertEquals("Juan Perez", usuario.getNombreCompleto());
    }

    @Test
    void testUsuarioActivoPorDefecto() {
        assertTrue(usuario.isActivo());
    }

    @Test
    void testAgregarRol() {
        Rol rol = new Rol("CLIENTE", "Cliente del sistema");
        usuario.addRol(rol);
        assertTrue(usuario.tieneRol("CLIENTE"));
    }

    @Test
    void testNoTieneRol() {
        assertFalse(usuario.tieneRol("ADMIN"));
    }

    @Test
    void testEqualsByEmail() {
        Usuario otro = new Usuario();
        otro.setEmail("jperez@email.com");
        otro.setUsername("jperez2");
        assertEquals(usuario, otro);
    }

    @Test
    void testNotEqualsDifferentEmail() {
        Usuario otro = new Usuario();
        otro.setEmail("otro@email.com");
        assertNotEquals(usuario, otro);
    }
}
