package com.gymsystem.model;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class ProgresoFisicoTest {

    @Test
    void testCrearProgreso() {
        Cliente cliente = new Cliente(1L);
        ProgresoFisico progreso = new ProgresoFisico(cliente, BigDecimal.valueOf(75.5));

        assertNotNull(progreso.getFechaRegistro());
        assertEquals(0, BigDecimal.valueOf(75.5).compareTo(progreso.getPesoKg()));
        assertEquals(cliente.getId(), progreso.getCliente().getId());
    }

    @Test
    void testRegistradoPorDefault() {
        ProgresoFisico p = new ProgresoFisico();
        assertNull(p.getRegistradoPor());
    }

    @Test
    void testSetImc() {
        ProgresoFisico p = new ProgresoFisico();
        p.setImc(BigDecimal.valueOf(24.5));
        assertEquals(0, BigDecimal.valueOf(24.5).compareTo(p.getImc()));
    }
}
