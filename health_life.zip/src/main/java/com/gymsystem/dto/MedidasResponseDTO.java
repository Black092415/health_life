package com.gymsystem.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class MedidasResponseDTO {

    private Long id;
    private Long clienteId;
    private LocalDateTime fechaRegistro;
    private BigDecimal cinturaCm;
    private BigDecimal caderaCm;
    private BigDecimal pechoCm;
    private BigDecimal brazoIzqCm;
    private BigDecimal brazoDerCm;
    private BigDecimal piernaIzqCm;
    private BigDecimal piernaDerCm;
    private BigDecimal cinturaCaderaRatio;
    private String registradoPor;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public BigDecimal getCinturaCm() { return cinturaCm; }
    public void setCinturaCm(BigDecimal cinturaCm) { this.cinturaCm = cinturaCm; }

    public BigDecimal getCaderaCm() { return caderaCm; }
    public void setCaderaCm(BigDecimal caderaCm) { this.caderaCm = caderaCm; }

    public BigDecimal getPechoCm() { return pechoCm; }
    public void setPechoCm(BigDecimal pechoCm) { this.pechoCm = pechoCm; }

    public BigDecimal getBrazoIzqCm() { return brazoIzqCm; }
    public void setBrazoIzqCm(BigDecimal brazoIzqCm) { this.brazoIzqCm = brazoIzqCm; }

    public BigDecimal getBrazoDerCm() { return brazoDerCm; }
    public void setBrazoDerCm(BigDecimal brazoDerCm) { this.brazoDerCm = brazoDerCm; }

    public BigDecimal getPiernaIzqCm() { return piernaIzqCm; }
    public void setPiernaIzqCm(BigDecimal piernaIzqCm) { this.piernaIzqCm = piernaIzqCm; }

    public BigDecimal getPiernaDerCm() { return piernaDerCm; }
    public void setPiernaDerCm(BigDecimal piernaDerCm) { this.piernaDerCm = piernaDerCm; }

    public BigDecimal getCinturaCaderaRatio() { return cinturaCaderaRatio; }
    public void setCinturaCaderaRatio(BigDecimal cinturaCaderaRatio) { this.cinturaCaderaRatio = cinturaCaderaRatio; }

    public String getRegistradoPor() { return registradoPor; }
    public void setRegistradoPor(String registradoPor) { this.registradoPor = registradoPor; }
}
