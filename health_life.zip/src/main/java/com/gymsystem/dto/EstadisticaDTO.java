package com.gymsystem.dto;

import java.math.BigDecimal;
import java.util.Map;

public class EstadisticaDTO {

    private Long clienteId;
    private String clienteNombre;
    private BigDecimal pesoActual;
    private BigDecimal pesoInicial;
    private BigDecimal imcActual;
    private BigDecimal imcInicial;
    private BigDecimal variacionPeso;
    private BigDecimal variacionPorcentual;
    private BigDecimal pesoPromedio;
    private BigDecimal pesoMinimo;
    private BigDecimal pesoMaximo;
    private int totalRegistros;
    private int totalMedidas;
    private int diasDesdePrimerRegistro;
    private BigDecimal perdidaSemanalPromedio;
    private String clasificacionIMC;
    private Map<String, BigDecimal> evolucionMensual;

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }

    public BigDecimal getPesoActual() { return pesoActual; }
    public void setPesoActual(BigDecimal pesoActual) { this.pesoActual = pesoActual; }

    public BigDecimal getPesoInicial() { return pesoInicial; }
    public void setPesoInicial(BigDecimal pesoInicial) { this.pesoInicial = pesoInicial; }

    public BigDecimal getImcActual() { return imcActual; }
    public void setImcActual(BigDecimal imcActual) { this.imcActual = imcActual; }

    public BigDecimal getImcInicial() { return imcInicial; }
    public void setImcInicial(BigDecimal imcInicial) { this.imcInicial = imcInicial; }

    public BigDecimal getVariacionPeso() { return variacionPeso; }
    public void setVariacionPeso(BigDecimal variacionPeso) { this.variacionPeso = variacionPeso; }

    public BigDecimal getVariacionPorcentual() { return variacionPorcentual; }
    public void setVariacionPorcentual(BigDecimal variacionPorcentual) { this.variacionPorcentual = variacionPorcentual; }

    public BigDecimal getPesoPromedio() { return pesoPromedio; }
    public void setPesoPromedio(BigDecimal pesoPromedio) { this.pesoPromedio = pesoPromedio; }

    public BigDecimal getPesoMinimo() { return pesoMinimo; }
    public void setPesoMinimo(BigDecimal pesoMinimo) { this.pesoMinimo = pesoMinimo; }

    public BigDecimal getPesoMaximo() { return pesoMaximo; }
    public void setPesoMaximo(BigDecimal pesoMaximo) { this.pesoMaximo = pesoMaximo; }

    public int getTotalRegistros() { return totalRegistros; }
    public void setTotalRegistros(int totalRegistros) { this.totalRegistros = totalRegistros; }

    public int getTotalMedidas() { return totalMedidas; }
    public void setTotalMedidas(int totalMedidas) { this.totalMedidas = totalMedidas; }

    public int getDiasDesdePrimerRegistro() { return diasDesdePrimerRegistro; }
    public void setDiasDesdePrimerRegistro(int diasDesdePrimerRegistro) { this.diasDesdePrimerRegistro = diasDesdePrimerRegistro; }

    public BigDecimal getPerdidaSemanalPromedio() { return perdidaSemanalPromedio; }
    public void setPerdidaSemanalPromedio(BigDecimal perdidaSemanalPromedio) { this.perdidaSemanalPromedio = perdidaSemanalPromedio; }

    public String getClasificacionIMC() { return clasificacionIMC; }
    public void setClasificacionIMC(String clasificacionIMC) { this.clasificacionIMC = clasificacionIMC; }

    public Map<String, BigDecimal> getEvolucionMensual() { return evolucionMensual; }
    public void setEvolucionMensual(Map<String, BigDecimal> evolucionMensual) { this.evolucionMensual = evolucionMensual; }
}
