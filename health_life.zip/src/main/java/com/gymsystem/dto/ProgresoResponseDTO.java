package com.gymsystem.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ProgresoResponseDTO {

    private Long id;
    private Long clienteId;
    private String clienteNombre;
    private LocalDateTime fechaRegistro;
    private BigDecimal pesoKg;
    private BigDecimal imc;
    private BigDecimal porcentajeGrasa;
    private BigDecimal masaMuscularKg;
    private BigDecimal pesoInicial;
    private BigDecimal pesoAnterior;
    private BigDecimal variacionPeso;
    private BigDecimal variacionPorcentual;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public BigDecimal getPesoKg() { return pesoKg; }
    public void setPesoKg(BigDecimal pesoKg) { this.pesoKg = pesoKg; }

    public BigDecimal getImc() { return imc; }
    public void setImc(BigDecimal imc) { this.imc = imc; }

    public BigDecimal getPorcentajeGrasa() { return porcentajeGrasa; }
    public void setPorcentajeGrasa(BigDecimal porcentajeGrasa) { this.porcentajeGrasa = porcentajeGrasa; }

    public BigDecimal getMasaMuscularKg() { return masaMuscularKg; }
    public void setMasaMuscularKg(BigDecimal masaMuscularKg) { this.masaMuscularKg = masaMuscularKg; }

    public BigDecimal getPesoInicial() { return pesoInicial; }
    public void setPesoInicial(BigDecimal pesoInicial) { this.pesoInicial = pesoInicial; }

    public BigDecimal getPesoAnterior() { return pesoAnterior; }
    public void setPesoAnterior(BigDecimal pesoAnterior) { this.pesoAnterior = pesoAnterior; }

    public BigDecimal getVariacionPeso() { return variacionPeso; }
    public void setVariacionPeso(BigDecimal variacionPeso) { this.variacionPeso = variacionPeso; }

    public BigDecimal getVariacionPorcentual() { return variacionPorcentual; }
    public void setVariacionPorcentual(BigDecimal variacionPorcentual) { this.variacionPorcentual = variacionPorcentual; }
}
