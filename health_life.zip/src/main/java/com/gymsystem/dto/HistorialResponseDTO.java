package com.gymsystem.dto;

import java.util.List;

public class HistorialResponseDTO {

    private Long clienteId;
    private String clienteNombre;
    private List<ProgresoResponseDTO> progreso;
    private List<MedidasResponseDTO> medidas;
    private EstadisticaDTO estadisticas;

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }

    public List<ProgresoResponseDTO> getProgreso() { return progreso; }
    public void setProgreso(List<ProgresoResponseDTO> progreso) { this.progreso = progreso; }

    public List<MedidasResponseDTO> getMedidas() { return medidas; }
    public void setMedidas(List<MedidasResponseDTO> medidas) { this.medidas = medidas; }

    public EstadisticaDTO getEstadisticas() { return estadisticas; }
    public void setEstadisticas(EstadisticaDTO estadisticas) { this.estadisticas = estadisticas; }
}
