package com.gymsystem;

import com.gymsystem.config.DatabaseConnection;
import com.gymsystem.dto.RegistroUsuarioDTO;
import com.gymsystem.dto.LoginDTO;
import com.gymsystem.model.*;
import com.gymsystem.security.AuthService;
import com.gymsystem.service.*;
import com.gymsystem.service.impl.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Main {

    private static final Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        log.info("========================================");
        log.info("  SISTEMA GYM & NUTRICIÓN - INICIANDO");
        log.info("========================================");

        try {
            if (DatabaseConnection.isPoolRunning()) {
                log.info("Pool de conexiones activo. Conexiones activas: {}",
                        DatabaseConnection.getActiveConnections());
            }

            //demoRegistroClientes();
            //demoRegistroProgreso();

            log.info("Sistema listo para integrar con Vaadin.");
        } catch (Exception e) {
            log.error("Error al iniciar el sistema", e);
        } finally {
            DatabaseConnection.shutdown();
            log.info("Pool de conexiones cerrado.");
        }
    }

    @SuppressWarnings("unused")
    private static void demoRegistroClientes() {
        log.info("--- DEMO: Registro de Usuarios ---");

        UsuarioService usuarioService = new UsuarioServiceImpl();
        AuthService authService = new AuthService();

        RegistroUsuarioDTO dtoCliente = new RegistroUsuarioDTO();
        dtoCliente.setUsername("cliente1");
        dtoCliente.setEmail("cliente1@demo.com");
        dtoCliente.setPassword("demo123");
        dtoCliente.setNombre("Carlos");
        dtoCliente.setApellido("Mendoza");
        dtoCliente.setRol("CLIENTE");
        dtoCliente.setFechaNacimiento(LocalDate.of(1990, 5, 15));
        dtoCliente.setAltura(BigDecimal.valueOf(1.75));
        dtoCliente.setGenero("M");

        try {
            usuarioService.registrarCliente(dtoCliente);
            log.info("Cliente registrado exitosamente en demo");
        } catch (Exception e) {
            log.warn("Demo registro cliente: {}", e.getMessage());
        }

        LoginDTO login = new LoginDTO("cliente1@demo.com", "demo123");
        try {
            Sesion sesion = authService.login(login);
            log.info("Login demo exitoso. Token: {}...", sesion.getToken().substring(0, 20));
            authService.logout(sesion.getToken());
        } catch (Exception e) {
            log.warn("Demo login: {}", e.getMessage());
        }
    }

    @SuppressWarnings("unused")
    private static void demoRegistroProgreso() {
        log.info("--- DEMO: Registro de Progreso ---");

        ProgresoService progresoService = new ProgresoServiceImpl();
        ClienteService clienteService = new ClienteServiceImpl();

        try {
            List<Cliente> clientes = clienteService.listarTodos();
            if (!clientes.isEmpty()) {
                Cliente cliente = clientes.get(0);

                ProgresoFisico p1 = new ProgresoFisico(cliente, BigDecimal.valueOf(80));
                p1.setRegistradoPor("cliente");
                progresoService.registrarPeso(p1);

                ProgresoFisico p2 = new ProgresoFisico(cliente, BigDecimal.valueOf(78.5));
                p2.setRegistradoPor("cliente");
                progresoService.registrarPeso(p2);

                var stats = progresoService.generarEstadisticas(cliente.getId());
                log.info("Estadísticas: Peso actual={}kg, IMC={}, Clasificación={}",
                        stats.getPesoActual(), stats.getImcActual(), stats.getClasificacionIMC());
            }
        } catch (Exception e) {
            log.warn("Demo progreso: {}", e.getMessage());
        }
    }
}
