package com.gymsystem.dao;

import com.gymsystem.model.Rutina;

import java.util.List;
import java.util.Optional;

public interface RutinaDAO extends GenericDAO<Rutina, Long> {

    List<Rutina> findByEntrenadorId(Long entrenadorId);

    List<Rutina> findByClienteId(Long clienteId);

    List<Rutina> findActivasByClienteId(Long clienteId);

    Optional<Rutina> findByIdWithEjercicios(Long id);

    void assignToCliente(Long rutinaId, Long clienteId);

    void deactivate(Long id);
}
