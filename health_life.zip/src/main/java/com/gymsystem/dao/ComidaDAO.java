package com.gymsystem.dao;

import com.gymsystem.model.Comida;

import java.util.List;

public interface ComidaDAO extends GenericDAO<Comida, Long> {

    List<Comida> findByPlanAlimenticioId(Long planAlimenticioId);

    List<Comida> findByTipoComida(Long planAlimenticioId, String tipoComida);

    void deleteByPlanAlimenticioId(Long planAlimenticioId);
}
