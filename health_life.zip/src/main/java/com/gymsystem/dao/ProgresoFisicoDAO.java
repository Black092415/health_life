package com.gymsystem.dao;

import com.gymsystem.model.ProgresoFisico;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ProgresoFisicoDAO extends GenericDAO<ProgresoFisico, Long> {

    List<ProgresoFisico> findByClienteId(Long clienteId);

    List<ProgresoFisico> findByClienteIdBetweenDates(Long clienteId, LocalDateTime desde, LocalDateTime hasta);

    Optional<ProgresoFisico> findLastByClienteId(Long clienteId);

    Optional<ProgresoFisico> findFirstByClienteId(Long clienteId);

    List<ProgresoFisico> findLastWeekly(Long clienteId, int semanas);
}
