package com.gymsystem.dao;

import com.gymsystem.model.Ejercicio;

import java.util.List;

public interface EjercicioDAO extends GenericDAO<Ejercicio, Long> {

    List<Ejercicio> findByGrupoMuscular(String grupoMuscular);

    List<Ejercicio> findByTipo(String tipo);

    List<Ejercicio> findByNivelDificultad(String nivel);

    List<Ejercicio> searchByNombre(String termino);

    List<Ejercicio> findActivos();
}
