package com.gymsystem.dao;

import com.gymsystem.model.Rol;

import java.util.List;
import java.util.Optional;

public interface RolDAO extends GenericDAO<Rol, Long> {

    Optional<Rol> findByNombre(String nombre);

    List<Rol> findByUsuarioId(Long usuarioId);

    void assignToUser(Long usuarioId, Long rolId);

    void removeFromUser(Long usuarioId, Long rolId);
}
