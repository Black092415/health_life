package com.gymsystem.dao.impl;

import com.gymsystem.dao.UsuarioDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.exception.DuplicateException;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.model.Rol;
import com.gymsystem.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class UsuarioDAOImpl extends BaseDAOImpl implements UsuarioDAO {

    private static final String INSERT = "INSERT INTO usuarios (username, email, password_hash, nombre, apellido, telefono) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String UPDATE = "UPDATE usuarios SET nombre=?, apellido=?, email=?, telefono=?, activo=? WHERE id=?";
    private static final String DELETE = "DELETE FROM usuarios WHERE id=?";
    private static final String SELECT_BY_ID = "SELECT * FROM usuarios WHERE id=?";
    private static final String SELECT_ALL = "SELECT * FROM usuarios ORDER BY nombre, apellido";
    private static final String SELECT_BY_EMAIL = "SELECT * FROM usuarios WHERE email=?";
    private static final String SELECT_BY_USERNAME = "SELECT * FROM usuarios WHERE username=?";
    private static final String UPDATE_LAST_ACCESS = "UPDATE usuarios SET ultimo_acceso=CURRENT_TIMESTAMP WHERE id=?";
    private static final String SELECT_COUNT = "SELECT COUNT(*) FROM usuarios";
    private static final String EXISTS_EMAIL = "SELECT COUNT(*) FROM usuarios WHERE email=?";
    private static final String EXISTS_USERNAME = "SELECT COUNT(*) FROM usuarios WHERE username=?";

    @Override
    public Usuario save(Usuario usuario) {
        verificarUnicidad(usuario);
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, usuario.getUsername());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getPasswordHash());
            stmt.setString(4, usuario.getNombre());
            stmt.setString(5, usuario.getApellido());
            setStringOrNull(stmt, 6, usuario.getTelefono());
            stmt.executeUpdate();

            usuario.setId(getGeneratedId(stmt));
            logger.info("Usuario creado: {}", usuario.getUsername());
            return usuario;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Usuario update(Usuario usuario) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(UPDATE);
            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getApellido());
            stmt.setString(3, usuario.getEmail());
            setStringOrNull(stmt, 4, usuario.getTelefono());
            stmt.setBoolean(5, usuario.isActivo());
            stmt.setLong(6, usuario.getId());
            stmt.executeUpdate();
            logger.info("Usuario actualizado: {}", usuario.getUsername());
            return usuario;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(DELETE);
            stmt.setLong(1, id);
            stmt.executeUpdate();
            logger.info("Usuario eliminado: id={}", id);
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Usuario> findById(Long id) {
        return findByIdBase(id, SELECT_BY_ID, false);
    }

    @Override
    public Optional<Usuario> findByIdWithRoles(Long id) {
        return findByIdBase(id, SELECT_BY_ID, true);
    }

    private Optional<Usuario> findByIdBase(Long id, String sql, boolean withRoles) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario u = mapUsuario(rs);
                if (withRoles) {
                    u.setRoles(findRolesByUsuarioId(conn, id));
                }
                return Optional.of(u);
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar usuario por id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Usuario> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Usuario> usuarios = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SELECT_ALL);
            rs = stmt.executeQuery();
            while (rs.next()) {
                usuarios.add(mapUsuario(rs));
            }
            return usuarios;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar usuarios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Usuario> findByEmail(String email) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SELECT_BY_EMAIL);
            stmt.setString(1, email);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapUsuario(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar usuario por email", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Usuario> findByUsername(String username) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SELECT_BY_USERNAME);
            stmt.setString(1, username);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapUsuario(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar usuario por username", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Usuario> findByEmailWithRoles(String email) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SELECT_BY_EMAIL);
            stmt.setString(1, email);
            rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario u = mapUsuario(rs);
                u.setRoles(findRolesByUsuarioId(conn, u.getId()));
                return Optional.of(u);
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar usuario con roles", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Usuario> findByRol(String nombreRol) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.* FROM usuarios u " +
                "JOIN usuarios_roles ur ON u.id = ur.usuario_id " +
                "JOIN roles r ON ur.rol_id = r.id " +
                "WHERE r.nombre = ?";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombreRol);
            rs = stmt.executeQuery();
            while (rs.next()) {
                usuarios.add(mapUsuario(rs));
            }
            return usuarios;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar usuarios por rol", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void updateLastAccess(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(UPDATE_LAST_ACCESS);
            stmt.setLong(1, usuarioId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.warn("Error al actualizar último acceso", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void activate(Long id) {
        cambiarEstado(id, true);
    }

    @Override
    public void deactivate(Long id) {
        cambiarEstado(id, false);
    }

    private void cambiarEstado(Long id, boolean activo) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE usuarios SET activo=? WHERE id=?");
            stmt.setBoolean(1, activo);
            stmt.setLong(2, id);
            stmt.executeUpdate();
            logger.info("Usuario {} {} ", id, activo ? "activado" : "desactivado");
        } catch (SQLException e) {
            throw new DatabaseException("Error al cambiar estado de usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public boolean existsByEmail(String email) {
        return existsByCampo(EXISTS_EMAIL, email);
    }

    @Override
    public boolean existsByUsername(String username) {
        return existsByCampo(EXISTS_USERNAME, username);
    }

    private boolean existsByCampo(String sql, String valor) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, valor);
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
            return false;
        } catch (SQLException e) {
            throw new DatabaseException("Error al verificar existencia", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SELECT_COUNT);
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar usuarios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private void verificarUnicidad(Usuario usuario) {
        if (existsByEmail(usuario.getEmail())) {
            throw new DuplicateException("usuario", "email", usuario.getEmail());
        }
        if (existsByUsername(usuario.getUsername())) {
            throw new DuplicateException("usuario", "username", usuario.getUsername());
        }
    }

    private Usuario mapUsuario(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setId(rs.getLong("id"));
        u.setUsername(rs.getString("username"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setNombre(rs.getString("nombre"));
        u.setApellido(rs.getString("apellido"));
        u.setTelefono(rs.getString("telefono"));
        u.setActivo(rs.getBoolean("activo"));
        u.setUltimoAcceso(toLocalDateTime(rs.getTimestamp("ultimo_acceso")));
        u.setFechaCreacion(toLocalDateTime(rs.getTimestamp("fecha_creacion")));
        u.setFechaActualizacion(toLocalDateTime(rs.getTimestamp("fecha_actualizacion")));
        return u;
    }

    private Set<Rol> findRolesByUsuarioId(Connection conn, Long usuarioId) throws SQLException {
        Set<Rol> roles = new HashSet<>();
        String sql = "SELECT r.* FROM roles r " +
                "JOIN usuarios_roles ur ON r.id = ur.rol_id WHERE ur.usuario_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, usuarioId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Rol r = new Rol();
                    r.setId(rs.getLong("id"));
                    r.setNombre(rs.getString("nombre"));
                    r.setDescripcion(rs.getString("descripcion"));
                    r.setActivo(rs.getBoolean("activo"));
                    roles.add(r);
                }
            }
        }
        return roles;
    }
}
