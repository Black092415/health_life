package com.gymsystem.dao.impl;

import com.gymsystem.dao.SesionDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Sesion;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SesionDAOImpl extends BaseDAOImpl implements SesionDAO {

    @Override
    public Sesion save(Sesion sesion) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO sesiones (usuario_id, token, ip_address, fecha_expiracion) VALUES (?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, sesion.getUsuario().getId());
            stmt.setString(2, sesion.getToken());
            setStringOrNull(stmt, 3, sesion.getIpAddress());
            stmt.setTimestamp(4, Timestamp.valueOf(sesion.getFechaExpiracion()));
            stmt.executeUpdate();
            sesion.setId(getGeneratedId(stmt));
            return sesion;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear sesión", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Sesion update(Sesion sesion) {
        return sesion;
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM sesiones WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar sesión", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Sesion> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM sesiones WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapSesion(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar sesión", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Sesion> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Sesion> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM sesiones ORDER BY fecha_inicio DESC");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapSesion(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar sesiones", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Sesion> findByToken(String token) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM sesiones WHERE token=? AND activa=true");
            stmt.setString(1, token);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapSesion(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar sesión por token", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Sesion> findActivasByUsuarioId(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Sesion> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM sesiones WHERE usuario_id=? AND activa=true ORDER BY fecha_inicio DESC");
            stmt.setLong(1, usuarioId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapSesion(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar sesiones activas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void cerrarSesion(String token) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE sesiones SET activa=false WHERE token=?");
            stmt.setString(1, token);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al cerrar sesión", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void cerrarTodasSesionesUsuario(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE sesiones SET activa=false WHERE usuario_id=? AND activa=true");
            stmt.setLong(1, usuarioId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al cerrar sesiones del usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void limpiarSesionesExpiradas() {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE sesiones SET activa=false WHERE fecha_expiracion < CURRENT_TIMESTAMP AND activa=true");
            int count = stmt.executeUpdate();
            if (count > 0) logger.info("{} sesiones expiradas limpiadas", count);
        } catch (SQLException e) {
            throw new DatabaseException("Error al limpiar sesiones expiradas", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public boolean isTokenValido(String token) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT COUNT(*) FROM sesiones WHERE token=? AND activa=true AND fecha_expiracion > CURRENT_TIMESTAMP");
            stmt.setString(1, token);
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
            return false;
        } catch (SQLException e) {
            throw new DatabaseException("Error al validar token", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM sesiones");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar sesiones", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Sesion mapSesion(ResultSet rs) throws SQLException {
        Sesion s = new Sesion();
        s.setId(rs.getLong("id"));
        s.setUsuario(new com.gymsystem.model.Usuario(rs.getLong("usuario_id")));
        s.setToken(rs.getString("token"));
        s.setIpAddress(rs.getString("ip_address"));
        s.setFechaInicio(toLocalDateTime(rs.getTimestamp("fecha_inicio")));
        s.setFechaExpiracion(toLocalDateTime(rs.getTimestamp("fecha_expiracion")));
        s.setActiva(rs.getBoolean("activa"));
        return s;
    }
}
