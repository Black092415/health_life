package com.gymsystem.dao.impl;

import com.gymsystem.dao.RutinaEjercicioDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Ejercicio;
import com.gymsystem.model.Rutina;
import com.gymsystem.model.RutinaEjercicio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RutinaEjercicioDAOImpl extends BaseDAOImpl implements RutinaEjercicioDAO {

    @Override
    public RutinaEjercicio save(RutinaEjercicio re) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO rutina_ejercicios (rutina_id, ejercicio_id, orden_ejecucion, series, repeticiones, duracion_segundos, descanso_segundos, notas) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, re.getRutina().getId());
            stmt.setLong(2, re.getEjercicio().getId());
            stmt.setInt(3, re.getOrdenEjecucion());
            setIntOrNull(stmt, 4, re.getSeries());
            setIntOrNull(stmt, 5, re.getRepeticiones());
            setIntOrNull(stmt, 6, re.getDuracionSegundos());
            setIntOrNull(stmt, 7, re.getDescansoSegundos());
            setStringOrNull(stmt, 8, re.getNotas());
            stmt.executeUpdate();
            re.setId(getGeneratedId(stmt));
            return re;
        } catch (SQLException e) {
            throw new DatabaseException("Error al agregar ejercicio a rutina", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public RutinaEjercicio update(RutinaEjercicio re) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE rutina_ejercicios SET orden_ejecucion=?, series=?, repeticiones=?, duracion_segundos=?, descanso_segundos=?, notas=? WHERE id=?");
            stmt.setInt(1, re.getOrdenEjecucion());
            setIntOrNull(stmt, 2, re.getSeries());
            setIntOrNull(stmt, 3, re.getRepeticiones());
            setIntOrNull(stmt, 4, re.getDuracionSegundos());
            setIntOrNull(stmt, 5, re.getDescansoSegundos());
            setStringOrNull(stmt, 6, re.getNotas());
            stmt.setLong(7, re.getId());
            stmt.executeUpdate();
            return re;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar rutina_ejercicio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM rutina_ejercicios WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar rutina_ejercicio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<RutinaEjercicio> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT re.*, e.* FROM rutina_ejercicios re JOIN ejercicios e ON re.ejercicio_id=e.id WHERE re.id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapRutinaEjercicio(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rutina_ejercicio", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<RutinaEjercicio> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<RutinaEjercicio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT re.*, e.* FROM rutina_ejercicios re JOIN ejercicios e ON re.ejercicio_id=e.id ORDER BY re.rutina_id, re.orden_ejecucion");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRutinaEjercicio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar rutina_ejercicios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<RutinaEjercicio> findByRutinaId(Long rutinaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<RutinaEjercicio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT re.*, e.* FROM rutina_ejercicios re JOIN ejercicios e ON re.ejercicio_id=e.id WHERE re.rutina_id=? ORDER BY re.orden_ejecucion");
            stmt.setLong(1, rutinaId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRutinaEjercicio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar ejercicios de rutina", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void deleteByRutinaId(Long rutinaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM rutina_ejercicios WHERE rutina_id=?");
            stmt.setLong(1, rutinaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar ejercicios de rutina", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void updateOrden(Long id, int nuevoOrden) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE rutina_ejercicios SET orden_ejecucion=? WHERE id=?");
            stmt.setInt(1, nuevoOrden);
            stmt.setLong(2, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar orden", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM rutina_ejercicios");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private RutinaEjercicio mapRutinaEjercicio(ResultSet rs) throws SQLException {
        RutinaEjercicio re = new RutinaEjercicio();
        re.setId(rs.getLong("re.id"));
        re.setRutina(new Rutina(rs.getLong("re.rutina_id")));

        Ejercicio e = new Ejercicio();
        e.setId(rs.getLong("e.id"));
        e.setNombre(rs.getString("e.nombre"));
        e.setGrupoMuscular(rs.getString("e.grupo_muscular"));
        e.setTipoEjercicio(rs.getString("e.tipo_ejercicio"));
        re.setEjercicio(e);

        re.setOrdenEjecucion(rs.getInt("re.orden_ejecucion"));
        re.setSeries(rs.getObject("re.series", Integer.class));
        re.setRepeticiones(rs.getObject("re.repeticiones", Integer.class));
        re.setDuracionSegundos(rs.getObject("re.duracion_segundos", Integer.class));
        re.setDescansoSegundos(rs.getObject("re.descanso_segundos", Integer.class));
        re.setNotas(rs.getString("re.notas"));
        return re;
    }
}
