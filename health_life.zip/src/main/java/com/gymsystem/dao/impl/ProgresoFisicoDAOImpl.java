package com.gymsystem.dao.impl;

import com.gymsystem.dao.ProgresoFisicoDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.ProgresoFisico;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProgresoFisicoDAOImpl extends BaseDAOImpl implements ProgresoFisicoDAO {

    @Override
    public ProgresoFisico save(ProgresoFisico pf) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO progreso_fisico (cliente_id, peso_kg, porcentaje_grasa, masa_muscular_kg, notas, registrado_por) VALUES (?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, pf.getCliente().getId());
            stmt.setBigDecimal(2, pf.getPesoKg());
            setBigDecimalOrNull(stmt, 3, pf.getPorcentajeGrasa());
            setBigDecimalOrNull(stmt, 4, pf.getMasaMuscularKg());
            setStringOrNull(stmt, 5, pf.getNotas());
            setStringOrNull(stmt, 6, pf.getRegistradoPor());
            stmt.executeUpdate();
            pf.setId(getGeneratedId(stmt));
            logger.info("Progreso registrado: cliente={}, peso={}kg", pf.getCliente().getId(), pf.getPesoKg());
            return pf;
        } catch (SQLException e) {
            throw new DatabaseException("Error al registrar progreso físico", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public ProgresoFisico update(ProgresoFisico pf) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE progreso_fisico SET peso_kg=?, porcentaje_grasa=?, masa_muscular_kg=?, notas=? WHERE id=?");
            stmt.setBigDecimal(1, pf.getPesoKg());
            setBigDecimalOrNull(stmt, 2, pf.getPorcentajeGrasa());
            setBigDecimalOrNull(stmt, 3, pf.getMasaMuscularKg());
            setStringOrNull(stmt, 4, pf.getNotas());
            stmt.setLong(5, pf.getId());
            stmt.executeUpdate();
            return pf;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar progreso físico", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM progreso_fisico WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar progreso", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<ProgresoFisico> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM progreso_fisico WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapProgreso(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar progreso", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<ProgresoFisico> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<ProgresoFisico> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM progreso_fisico ORDER BY fecha_registro DESC");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapProgreso(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar progresos", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<ProgresoFisico> findByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<ProgresoFisico> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM progreso_fisico WHERE cliente_id=? ORDER BY fecha_registro DESC");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapProgreso(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar progreso por cliente", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<ProgresoFisico> findByClienteIdBetweenDates(Long clienteId, LocalDateTime desde, LocalDateTime hasta) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<ProgresoFisico> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM progreso_fisico WHERE cliente_id=? AND fecha_registro BETWEEN ? AND ? ORDER BY fecha_registro ASC");
            stmt.setLong(1, clienteId);
            stmt.setTimestamp(2, Timestamp.valueOf(desde));
            stmt.setTimestamp(3, Timestamp.valueOf(hasta));
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapProgreso(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar progreso por fechas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<ProgresoFisico> findLastByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM progreso_fisico WHERE cliente_id=? ORDER BY fecha_registro DESC LIMIT 1");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapProgreso(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar último progreso", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<ProgresoFisico> findFirstByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM progreso_fisico WHERE cliente_id=? ORDER BY fecha_registro ASC LIMIT 1");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapProgreso(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar primer progreso", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<ProgresoFisico> findLastWeekly(Long clienteId, int semanas) {
        return findByClienteIdBetweenDates(
                clienteId,
                LocalDateTime.now().minusWeeks(semanas),
                LocalDateTime.now());
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM progreso_fisico");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar progresos", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private ProgresoFisico mapProgreso(ResultSet rs) throws SQLException {
        ProgresoFisico pf = new ProgresoFisico();
        pf.setId(rs.getLong("id"));
        pf.setCliente(new com.gymsystem.model.Cliente(rs.getLong("cliente_id")));
        pf.setFechaRegistro(toLocalDateTime(rs.getTimestamp("fecha_registro")));
        pf.setPesoKg(rs.getBigDecimal("peso_kg"));
        pf.setImc(rs.getBigDecimal("imc"));
        pf.setPorcentajeGrasa(rs.getBigDecimal("porcentaje_grasa"));
        pf.setMasaMuscularKg(rs.getBigDecimal("masa_muscular_kg"));
        pf.setNotas(rs.getString("notas"));
        pf.setRegistradoPor(rs.getString("registrado_por"));
        return pf;
    }
}
