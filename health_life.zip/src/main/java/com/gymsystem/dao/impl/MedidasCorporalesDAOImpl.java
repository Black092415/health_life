package com.gymsystem.dao.impl;

import com.gymsystem.dao.MedidasCorporalesDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.MedidasCorporales;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MedidasCorporalesDAOImpl extends BaseDAOImpl implements MedidasCorporalesDAO {

    @Override
    public MedidasCorporales save(MedidasCorporales mc) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO medidas_corporales (cliente_id, cintura_cm, cadera_cm, pecho_cm, brazo_izq_cm, brazo_der_cm, pierna_izq_cm, pierna_der_cm, notas, registrado_por) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, mc.getCliente().getId());
            setBigDecimalOrNull(stmt, 2, mc.getCinturaCm());
            setBigDecimalOrNull(stmt, 3, mc.getCaderaCm());
            setBigDecimalOrNull(stmt, 4, mc.getPechoCm());
            setBigDecimalOrNull(stmt, 5, mc.getBrazoIzqCm());
            setBigDecimalOrNull(stmt, 6, mc.getBrazoDerCm());
            setBigDecimalOrNull(stmt, 7, mc.getPiernaIzqCm());
            setBigDecimalOrNull(stmt, 8, mc.getPiernaDerCm());
            setStringOrNull(stmt, 9, mc.getNotas());
            setStringOrNull(stmt, 10, mc.getRegistradoPor());
            stmt.executeUpdate();
            mc.setId(getGeneratedId(stmt));
            logger.info("Medidas registradas: cliente={}", mc.getCliente().getId());
            return mc;
        } catch (SQLException e) {
            throw new DatabaseException("Error al registrar medidas corporales", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public MedidasCorporales update(MedidasCorporales mc) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE medidas_corporales SET cintura_cm=?, cadera_cm=?, pecho_cm=?, brazo_izq_cm=?, brazo_der_cm=?, pierna_izq_cm=?, pierna_der_cm=?, notas=? WHERE id=?");
            setBigDecimalOrNull(stmt, 1, mc.getCinturaCm());
            setBigDecimalOrNull(stmt, 2, mc.getCaderaCm());
            setBigDecimalOrNull(stmt, 3, mc.getPechoCm());
            setBigDecimalOrNull(stmt, 4, mc.getBrazoIzqCm());
            setBigDecimalOrNull(stmt, 5, mc.getBrazoDerCm());
            setBigDecimalOrNull(stmt, 6, mc.getPiernaIzqCm());
            setBigDecimalOrNull(stmt, 7, mc.getPiernaDerCm());
            setStringOrNull(stmt, 8, mc.getNotas());
            stmt.setLong(9, mc.getId());
            stmt.executeUpdate();
            return mc;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar medidas", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM medidas_corporales WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar medidas", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<MedidasCorporales> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM medidas_corporales WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapMedidas(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar medidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<MedidasCorporales> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<MedidasCorporales> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM medidas_corporales ORDER BY fecha_registro DESC");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapMedidas(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar medidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<MedidasCorporales> findByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<MedidasCorporales> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM medidas_corporales WHERE cliente_id=? ORDER BY fecha_registro DESC");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapMedidas(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar medidas por cliente", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<MedidasCorporales> findByClienteIdBetweenDates(Long clienteId, LocalDateTime desde, LocalDateTime hasta) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<MedidasCorporales> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM medidas_corporales WHERE cliente_id=? AND fecha_registro BETWEEN ? AND ? ORDER BY fecha_registro ASC");
            stmt.setLong(1, clienteId);
            stmt.setTimestamp(2, Timestamp.valueOf(desde));
            stmt.setTimestamp(3, Timestamp.valueOf(hasta));
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapMedidas(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar medidas por fechas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<MedidasCorporales> findLastByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM medidas_corporales WHERE cliente_id=? ORDER BY fecha_registro DESC LIMIT 1");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapMedidas(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar últimas medidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<MedidasCorporales> findFirstByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM medidas_corporales WHERE cliente_id=? ORDER BY fecha_registro ASC LIMIT 1");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapMedidas(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar primeras medidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM medidas_corporales");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar medidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private MedidasCorporales mapMedidas(ResultSet rs) throws SQLException {
        MedidasCorporales mc = new MedidasCorporales();
        mc.setId(rs.getLong("id"));
        mc.setCliente(new com.gymsystem.model.Cliente(rs.getLong("cliente_id")));
        mc.setFechaRegistro(toLocalDateTime(rs.getTimestamp("fecha_registro")));
        mc.setCinturaCm(rs.getBigDecimal("cintura_cm"));
        mc.setCaderaCm(rs.getBigDecimal("cadera_cm"));
        mc.setPechoCm(rs.getBigDecimal("pecho_cm"));
        mc.setBrazoIzqCm(rs.getBigDecimal("brazo_izq_cm"));
        mc.setBrazoDerCm(rs.getBigDecimal("brazo_der_cm"));
        mc.setPiernaIzqCm(rs.getBigDecimal("pierna_izq_cm"));
        mc.setPiernaDerCm(rs.getBigDecimal("pierna_der_cm"));
        mc.setCinturaCaderaRatio(rs.getBigDecimal("cintura_cadera_ratio"));
        mc.setNotas(rs.getString("notas"));
        mc.setRegistradoPor(rs.getString("registrado_por"));
        return mc;
    }
}
