package com.gymsystem.dao.impl;

import com.gymsystem.dao.ClienteDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Cliente;
import com.gymsystem.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ClienteDAOImpl extends BaseDAOImpl implements ClienteDAO {

    @Override
    public Cliente save(Cliente cliente) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO clientes (usuario_id, fecha_nacimiento, genero, altura, telefono_emergencia, notas_medicas, objetivo) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, cliente.getUsuario().getId());
            stmt.setDate(2, cliente.getFechaNacimiento() != null ? Date.valueOf(cliente.getFechaNacimiento()) : null);
            setStringOrNull(stmt, 3, cliente.getGenero());
            setBigDecimalOrNull(stmt, 4, cliente.getAltura());
            setStringOrNull(stmt, 5, cliente.getTelefonoEmergencia());
            setStringOrNull(stmt, 6, cliente.getNotasMedicas());
            setStringOrNull(stmt, 7, cliente.getObjetivo());
            stmt.executeUpdate();
            cliente.setId(getGeneratedId(stmt));
            logger.info("Cliente creado: id={}", cliente.getId());
            return cliente;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear cliente", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Cliente update(Cliente cliente) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE clientes SET fecha_nacimiento=?, genero=?, altura=?, telefono_emergencia=?, notas_medicas=?, objetivo=? WHERE id=?");
            stmt.setDate(1, cliente.getFechaNacimiento() != null ? Date.valueOf(cliente.getFechaNacimiento()) : null);
            setStringOrNull(stmt, 2, cliente.getGenero());
            setBigDecimalOrNull(stmt, 3, cliente.getAltura());
            setStringOrNull(stmt, 4, cliente.getTelefonoEmergencia());
            setStringOrNull(stmt, 5, cliente.getNotasMedicas());
            setStringOrNull(stmt, 6, cliente.getObjetivo());
            stmt.setLong(7, cliente.getId());
            stmt.executeUpdate();
            return cliente;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar cliente", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM clientes WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar cliente", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Cliente> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT c.*, u.* FROM clientes c JOIN usuarios u ON c.usuario_id=u.id WHERE c.id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapClienteWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar cliente por id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Cliente> findByIdWithUsuario(Long id) {
        return findById(id);
    }

    @Override
    public Optional<Cliente> findByUsuarioId(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT c.*, u.* FROM clientes c JOIN usuarios u ON c.usuario_id=u.id WHERE c.usuario_id=?");
            stmt.setLong(1, usuarioId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapClienteWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar cliente por usuario_id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Cliente> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cliente> clientes = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT c.*, u.* FROM clientes c JOIN usuarios u ON c.usuario_id=u.id ORDER BY u.nombre, u.apellido");
            rs = stmt.executeQuery();
            while (rs.next()) clientes.add(mapClienteWithUsuario(rs));
            return clientes;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar clientes", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Cliente> findByEntrenadorId(Long entrenadorId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT c.*, u.* FROM clientes c " +
                "JOIN usuarios u ON c.usuario_id=u.id " +
                "JOIN asignaciones a ON c.id=a.cliente_id " +
                "WHERE a.entrenador_id=? AND a.activa=true";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setLong(1, entrenadorId);
            rs = stmt.executeQuery();
            while (rs.next()) clientes.add(mapClienteWithUsuario(rs));
            return clientes;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar clientes por entrenador", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Cliente> findByNutricionistaId(Long nutricionistaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT c.*, u.* FROM clientes c " +
                "JOIN usuarios u ON c.usuario_id=u.id " +
                "JOIN asignaciones a ON c.id=a.cliente_id " +
                "WHERE a.nutricionista_id=? AND a.activa=true";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setLong(1, nutricionistaId);
            rs = stmt.executeQuery();
            while (rs.next()) clientes.add(mapClienteWithUsuario(rs));
            return clientes;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar clientes por nutricionista", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Cliente> searchByNombre(String termino) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT c.*, u.* FROM clientes c " +
                "JOIN usuarios u ON c.usuario_id=u.id " +
                "WHERE LOWER(u.nombre) LIKE ? OR LOWER(u.apellido) LIKE ? " +
                "OR LOWER(CONCAT(u.nombre, ' ', u.apellido)) LIKE ?";
        try {
            conn = getConnection();
            String pattern = "%" + termino.toLowerCase() + "%";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            stmt.setString(3, pattern);
            rs = stmt.executeQuery();
            while (rs.next()) clientes.add(mapClienteWithUsuario(rs));
            return clientes;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar clientes por nombre", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Cliente> searchByEmail(String termino) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT c.*, u.* FROM clientes c " +
                "JOIN usuarios u ON c.usuario_id=u.id WHERE LOWER(u.email) LIKE ?";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + termino.toLowerCase() + "%");
            rs = stmt.executeQuery();
            while (rs.next()) clientes.add(mapClienteWithUsuario(rs));
            return clientes;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar clientes por email", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void asignarEntrenador(Long clienteId, Long entrenadorId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO asignaciones (cliente_id, entrenador_id) VALUES (?, ?)");
            stmt.setLong(1, clienteId);
            stmt.setLong(2, entrenadorId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al asignar entrenador", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void asignarNutricionista(Long clienteId, Long nutricionistaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO asignaciones (cliente_id, nutricionista_id) VALUES (?, ?)");
            stmt.setLong(1, clienteId);
            stmt.setLong(2, nutricionistaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al asignar nutricionista", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM clientes");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar clientes", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Cliente mapClienteWithUsuario(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getLong("c.id"));

        Usuario u = new Usuario();
        u.setId(rs.getLong("u.id"));
        u.setUsername(rs.getString("u.username"));
        u.setEmail(rs.getString("u.email"));
        u.setNombre(rs.getString("u.nombre"));
        u.setApellido(rs.getString("u.apellido"));
        u.setTelefono(rs.getString("u.telefono"));
        u.setActivo(rs.getBoolean("u.activo"));
        u.setFechaCreacion(toLocalDateTime(rs.getTimestamp("u.fecha_creacion")));
        c.setUsuario(u);

        Date fn = rs.getDate("c.fecha_nacimiento");
        if (fn != null) c.setFechaNacimiento(fn.toLocalDate());
        c.setGenero(rs.getString("c.genero"));
        c.setAltura(rs.getBigDecimal("c.altura"));
        c.setTelefonoEmergencia(rs.getString("c.telefono_emergencia"));
        c.setNotasMedicas(rs.getString("c.notas_medicas"));
        c.setObjetivo(rs.getString("c.objetivo"));
        c.setFechaCreacion(toLocalDateTime(rs.getTimestamp("c.fecha_registro")));
        return c;
    }
}
