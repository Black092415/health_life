package com.gymsystem.dao.impl;

import com.gymsystem.dao.RecordatorioDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Recordatorio;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RecordatorioDAOImpl extends BaseDAOImpl implements RecordatorioDAO {

    @Override
    public Recordatorio save(Recordatorio recordatorio) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO recordatorios (cliente_id, creado_por, titulo, descripcion, tipo, fecha_programada, recurrencia) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, recordatorio.getCliente().getId());
            stmt.setLong(2, recordatorio.getCreadoPor().getId());
            stmt.setString(3, recordatorio.getTitulo());
            setStringOrNull(stmt, 4, recordatorio.getDescripcion());
            stmt.setString(5, recordatorio.getTipo());
            stmt.setTimestamp(6, Timestamp.valueOf(recordatorio.getFechaProgramada()));
            setStringOrNull(stmt, 7, recordatorio.getRecurrencia());
            stmt.executeUpdate();
            recordatorio.setId(getGeneratedId(stmt));
            logger.info("Recordatorio creado: {} para cliente {}", recordatorio.getTitulo(), recordatorio.getCliente().getId());
            return recordatorio;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear recordatorio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Recordatorio update(Recordatorio recordatorio) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE recordatorios SET titulo=?, descripcion=?, tipo=?, fecha_programada=?, recurrencia=?, completado=? WHERE id=?");
            stmt.setString(1, recordatorio.getTitulo());
            setStringOrNull(stmt, 2, recordatorio.getDescripcion());
            stmt.setString(3, recordatorio.getTipo());
            stmt.setTimestamp(4, Timestamp.valueOf(recordatorio.getFechaProgramada()));
            setStringOrNull(stmt, 5, recordatorio.getRecurrencia());
            stmt.setBoolean(6, recordatorio.isCompletado());
            stmt.setLong(7, recordatorio.getId());
            stmt.executeUpdate();
            return recordatorio;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar recordatorio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM recordatorios WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar recordatorio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Recordatorio> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM recordatorios WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapRecordatorio(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar recordatorio", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Recordatorio> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Recordatorio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM recordatorios ORDER BY fecha_programada");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRecordatorio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar recordatorios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Recordatorio> findByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Recordatorio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM recordatorios WHERE cliente_id=? ORDER BY fecha_programada DESC");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRecordatorio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar recordatorios por cliente", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Recordatorio> findPendientesByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Recordatorio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM recordatorios WHERE cliente_id=? AND completado=false AND fecha_programada >= CURRENT_TIMESTAMP ORDER BY fecha_programada");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRecordatorio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar recordatorios pendientes", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Recordatorio> findByDateRange(LocalDateTime desde, LocalDateTime hasta) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Recordatorio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM recordatorios WHERE fecha_programada BETWEEN ? AND ? ORDER BY fecha_programada");
            stmt.setTimestamp(1, Timestamp.valueOf(desde));
            stmt.setTimestamp(2, Timestamp.valueOf(hasta));
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRecordatorio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar recordatorios por rango", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Recordatorio> findByTipo(String tipo) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Recordatorio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM recordatorios WHERE tipo=? AND completado=false ORDER BY fecha_programada");
            stmt.setString(1, tipo);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRecordatorio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar recordatorios por tipo", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void marcarCompletado(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE recordatorios SET completado=true, fecha_completado=CURRENT_TIMESTAMP WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al marcar recordatorio como completado", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long countPendientesByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT COUNT(*) FROM recordatorios WHERE cliente_id=? AND completado=false");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar recordatorios pendientes", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM recordatorios");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar recordatorios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Recordatorio mapRecordatorio(ResultSet rs) throws SQLException {
        Recordatorio r = new Recordatorio();
        r.setId(rs.getLong("id"));
        r.setCliente(new com.gymsystem.model.Cliente(rs.getLong("cliente_id")));
        r.setCreadoPor(new com.gymsystem.model.Usuario(rs.getLong("creado_por")));
        r.setTitulo(rs.getString("titulo"));
        r.setDescripcion(rs.getString("descripcion"));
        r.setTipo(rs.getString("tipo"));
        r.setFechaProgramada(toLocalDateTime(rs.getTimestamp("fecha_programada")));
        r.setFechaCompletado(toLocalDateTime(rs.getTimestamp("fecha_completado")));
        r.setCompletado(rs.getBoolean("completado"));
        r.setRecurrencia(rs.getString("recurrencia"));
        r.setFechaCreacion(toLocalDateTime(rs.getTimestamp("fecha_creacion")));
        return r;
    }
}
