package com.gymsystem.dao.impl;

import com.gymsystem.dao.RutinaDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RutinaDAOImpl extends BaseDAOImpl implements RutinaDAO {

    @Override
    public Rutina save(Rutina rutina) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO rutinas (entrenador_id, cliente_id, nombre, descripcion, objetivo, duracion_semanas, frecuencia_semanal, nivel, fecha_inicio, fecha_fin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, rutina.getEntrenador().getId());
            setLongOrNull(stmt, 2, rutina.getCliente() != null ? rutina.getCliente().getId() : null);
            stmt.setString(3, rutina.getNombre());
            setStringOrNull(stmt, 4, rutina.getDescripcion());
            setStringOrNull(stmt, 5, rutina.getObjetivo());
            stmt.setInt(6, rutina.getDuracionSemanas());
            stmt.setInt(7, rutina.getFrecuenciaSemanal());
            setStringOrNull(stmt, 8, rutina.getNivel());
            stmt.setDate(9, rutina.getFechaInicio() != null ? Date.valueOf(rutina.getFechaInicio()) : null);
            stmt.setDate(10, rutina.getFechaFin() != null ? Date.valueOf(rutina.getFechaFin()) : null);
            stmt.executeUpdate();
            rutina.setId(getGeneratedId(stmt));
            logger.info("Rutina creada: {} (id={})", rutina.getNombre(), rutina.getId());
            return rutina;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear rutina", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Rutina update(Rutina rutina) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE rutinas SET nombre=?, descripcion=?, objetivo=?, duracion_semanas=?, frecuencia_semanal=?, nivel=?, fecha_inicio=?, fecha_fin=?, activa=? WHERE id=?");
            stmt.setString(1, rutina.getNombre());
            setStringOrNull(stmt, 2, rutina.getDescripcion());
            setStringOrNull(stmt, 3, rutina.getObjetivo());
            stmt.setInt(4, rutina.getDuracionSemanas());
            stmt.setInt(5, rutina.getFrecuenciaSemanal());
            setStringOrNull(stmt, 6, rutina.getNivel());
            stmt.setDate(7, rutina.getFechaInicio() != null ? Date.valueOf(rutina.getFechaInicio()) : null);
            stmt.setDate(8, rutina.getFechaFin() != null ? Date.valueOf(rutina.getFechaFin()) : null);
            stmt.setBoolean(9, rutina.isActiva());
            stmt.setLong(10, rutina.getId());
            stmt.executeUpdate();
            return rutina;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar rutina", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM rutinas WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar rutina", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Rutina> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM rutinas WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapRutina(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rutina", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Rutina> findByIdWithEjercicios(Long id) {
        Optional<Rutina> opt = findById(id);
        opt.ifPresent(rutina -> {
            RutinaEjercicioDAOImpl reDao = new RutinaEjercicioDAOImpl();
            rutina.setEjercicios(reDao.findByRutinaId(id));
        });
        return opt;
    }

    @Override
    public List<Rutina> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Rutina> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM rutinas ORDER BY fecha_creacion DESC");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRutina(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar rutinas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Rutina> findByEntrenadorId(Long entrenadorId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Rutina> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM rutinas WHERE entrenador_id=? ORDER BY fecha_creacion DESC");
            stmt.setLong(1, entrenadorId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRutina(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rutinas por entrenador", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Rutina> findByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Rutina> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM rutinas WHERE cliente_id=? ORDER BY fecha_creacion DESC");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRutina(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rutinas por cliente", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Rutina> findActivasByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Rutina> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM rutinas WHERE cliente_id=? AND activa=true ORDER BY fecha_creacion DESC");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapRutina(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rutinas activas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void assignToCliente(Long rutinaId, Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE rutinas SET cliente_id=? WHERE id=?");
            stmt.setLong(1, clienteId);
            stmt.setLong(2, rutinaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al asignar rutina a cliente", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void deactivate(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE rutinas SET activa=false WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al desactivar rutina", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM rutinas");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar rutinas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Rutina mapRutina(ResultSet rs) throws SQLException {
        Rutina r = new Rutina();
        r.setId(rs.getLong("id"));
        Entrenador e = new Entrenador(rs.getLong("entrenador_id"));
        r.setEntrenador(e);
        Long clienteId = rs.getLong("cliente_id");
        if (!rs.wasNull()) r.setCliente(new Cliente(clienteId));
        r.setNombre(rs.getString("nombre"));
        r.setDescripcion(rs.getString("descripcion"));
        r.setObjetivo(rs.getString("objetivo"));
        r.setDuracionSemanas(rs.getInt("duracion_semanas"));
        r.setFrecuenciaSemanal(rs.getInt("frecuencia_semanal"));
        r.setNivel(rs.getString("nivel"));
        r.setFechaInicio(toLocalDate(rs.getDate("fecha_inicio")));
        r.setFechaFin(toLocalDate(rs.getDate("fecha_fin")));
        r.setActiva(rs.getBoolean("activa"));
        r.setFechaCreacion(toLocalDateTime(rs.getTimestamp("fecha_creacion")));
        return r;
    }
}
