package com.gymsystem.dao.impl;

import com.gymsystem.config.DatabaseConnection;
import com.gymsystem.exception.DatabaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public abstract class BaseDAOImpl {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    protected Connection getConnection() {
        try {
            return DatabaseConnection.getConnection();
        } catch (SQLException e) {
            logger.error("Error al obtener conexión de BD", e);
            throw new DatabaseException("Error al obtener conexión", e);
        }
    }

    protected void closeResources(Connection conn, PreparedStatement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
        } catch (SQLException e) {
            logger.warn("Error al cerrar ResultSet", e);
        }
        try {
            if (stmt != null) stmt.close();
        } catch (SQLException e) {
            logger.warn("Error al cerrar PreparedStatement", e);
        }
        if (conn != null) {
            DatabaseConnection.closeConnection(conn);
        }
    }

    protected void closeResources(PreparedStatement stmt, ResultSet rs) {
        closeResources(null, stmt, rs);
    }

    protected Long getGeneratedId(PreparedStatement stmt) throws SQLException {
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            return rs.getLong(1);
        }
        return null;
    }

    // Utilidades de mapeo temporal
    protected Timestamp toTimestamp(LocalDateTime dateTime) {
        return dateTime != null ? Timestamp.valueOf(dateTime) : null;
    }

    protected LocalDateTime toLocalDateTime(Timestamp timestamp) {
        return timestamp != null ? timestamp.toLocalDateTime() : null;
    }

    protected Date toDate(LocalDate localDate) {
        return localDate != null ? Date.valueOf(localDate) : null;
    }

    protected LocalDate toLocalDate(Date date) {
        return date != null ? date.toLocalDate() : null;
    }

    protected Time toTime(LocalTime localTime) {
        return localTime != null ? Time.valueOf(localTime) : null;
    }

    protected LocalTime toLocalTime(Time time) {
        return time != null ? time.toLocalTime() : null;
    }

    protected void setStringOrNull(PreparedStatement stmt, int index, String value) throws SQLException {
        if (value != null) {
            stmt.setString(index, value);
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    protected void setIntOrNull(PreparedStatement stmt, int index, Integer value) throws SQLException {
        if (value != null) {
            stmt.setInt(index, value);
        } else {
            stmt.setNull(index, Types.INTEGER);
        }
    }

    protected void setBigDecimalOrNull(PreparedStatement stmt, int index, java.math.BigDecimal value) throws SQLException {
        if (value != null) {
            stmt.setBigDecimal(index, value);
        } else {
            stmt.setNull(index, Types.DECIMAL);
        }
    }

    protected void setBooleanOrNull(PreparedStatement stmt, int index, Boolean value) throws SQLException {
        if (value != null) {
            stmt.setBoolean(index, value);
        } else {
            stmt.setNull(index, Types.BOOLEAN);
        }
    }

    protected void setLongOrNull(PreparedStatement stmt, int index, Long value) throws SQLException {
        if (value != null) {
            stmt.setLong(index, value);
        } else {
            stmt.setNull(index, Types.BIGINT);
        }
    }
}
