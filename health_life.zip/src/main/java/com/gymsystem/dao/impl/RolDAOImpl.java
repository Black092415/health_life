package com.gymsystem.dao.impl;

import com.gymsystem.dao.RolDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Rol;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RolDAOImpl extends BaseDAOImpl implements RolDAO {

    @Override
    public Rol save(Rol rol) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO roles (nombre, descripcion) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, rol.getNombre());
            setStringOrNull(stmt, 2, rol.getDescripcion());
            stmt.executeUpdate();
            rol.setId(getGeneratedId(stmt));
            return rol;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear rol", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Rol update(Rol rol) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE roles SET nombre=?, descripcion=?, activo=? WHERE id=?");
            stmt.setString(1, rol.getNombre());
            setStringOrNull(stmt, 2, rol.getDescripcion());
            stmt.setBoolean(3, rol.isActivo());
            stmt.setLong(4, rol.getId());
            stmt.executeUpdate();
            return rol;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar rol", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM roles WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar rol", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Rol> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM roles WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapRol(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rol por id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Rol> findByNombre(String nombre) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM roles WHERE nombre=?");
            stmt.setString(1, nombre);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapRol(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar rol por nombre", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Rol> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Rol> roles = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM roles ORDER BY nombre");
            rs = stmt.executeQuery();
            while (rs.next()) roles.add(mapRol(rs));
            return roles;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar roles", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Rol> findByUsuarioId(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Rol> roles = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT r.* FROM roles r JOIN usuarios_roles ur ON r.id=ur.rol_id WHERE ur.usuario_id=?");
            stmt.setLong(1, usuarioId);
            rs = stmt.executeQuery();
            while (rs.next()) roles.add(mapRol(rs));
            return roles;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar roles de usuario", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void assignToUser(Long usuarioId, Long rolId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO usuarios_roles (usuario_id, rol_id) VALUES (?, ?) ON CONFLICT DO NOTHING");
            stmt.setLong(1, usuarioId);
            stmt.setLong(2, rolId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al asignar rol a usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void removeFromUser(Long usuarioId, Long rolId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "DELETE FROM usuarios_roles WHERE usuario_id=? AND rol_id=?");
            stmt.setLong(1, usuarioId);
            stmt.setLong(2, rolId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al remover rol de usuario", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM roles");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar roles", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Rol mapRol(ResultSet rs) throws SQLException {
        Rol r = new Rol();
        r.setId(rs.getLong("id"));
        r.setNombre(rs.getString("nombre"));
        r.setDescripcion(rs.getString("descripcion"));
        r.setActivo(rs.getBoolean("activo"));
        r.setFechaCreacion(toLocalDateTime(rs.getTimestamp("fecha_creacion")));
        return r;
    }
}
