package com.gymsystem.dao.impl;

import com.gymsystem.dao.NutricionistaDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Nutricionista;
import com.gymsystem.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class NutricionistaDAOImpl extends BaseDAOImpl implements NutricionistaDAO {

    @Override
    public Nutricionista save(Nutricionista nutricionista) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO nutricionistas (usuario_id, numero_licencia, especialidad, anios_experiencia, horario_disponible) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, nutricionista.getUsuario().getId());
            stmt.setString(2, nutricionista.getNumeroLicencia());
            setStringOrNull(stmt, 3, nutricionista.getEspecialidad());
            stmt.setInt(4, nutricionista.getAniosExperiencia());
            setStringOrNull(stmt, 5, nutricionista.getHorarioDisponible());
            stmt.executeUpdate();
            nutricionista.setId(getGeneratedId(stmt));
            logger.info("Nutricionista creado: id={}", nutricionista.getId());
            return nutricionista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear nutricionista", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Nutricionista update(Nutricionista nutricionista) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE nutricionistas SET numero_licencia=?, especialidad=?, anios_experiencia=?, horario_disponible=? WHERE id=?");
            stmt.setString(1, nutricionista.getNumeroLicencia());
            setStringOrNull(stmt, 2, nutricionista.getEspecialidad());
            stmt.setInt(3, nutricionista.getAniosExperiencia());
            setStringOrNull(stmt, 4, nutricionista.getHorarioDisponible());
            stmt.setLong(5, nutricionista.getId());
            stmt.executeUpdate();
            return nutricionista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar nutricionista", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM nutricionistas WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar nutricionista", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Nutricionista> findById(Long id) {
        return findByIdBase(id);
    }

    @Override
    public Optional<Nutricionista> findByIdWithUsuario(Long id) {
        return findByIdBase(id);
    }

    private Optional<Nutricionista> findByIdBase(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT n.*, u.* FROM nutricionistas n JOIN usuarios u ON n.usuario_id=u.id WHERE n.id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapNutricionistaWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar nutricionista por id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Nutricionista> findByUsuarioId(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT n.*, u.* FROM nutricionistas n JOIN usuarios u ON n.usuario_id=u.id WHERE n.usuario_id=?");
            stmt.setLong(1, usuarioId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapNutricionistaWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar nutricionista por usuario_id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Nutricionista> findByLicencia(String numeroLicencia) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT n.*, u.* FROM nutricionistas n JOIN usuarios u ON n.usuario_id=u.id WHERE n.numero_licencia=?");
            stmt.setString(1, numeroLicencia);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapNutricionistaWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar nutricionista por licencia", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Nutricionista> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Nutricionista> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT n.*, u.* FROM nutricionistas n JOIN usuarios u ON n.usuario_id=u.id ORDER BY u.nombre, u.apellido");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapNutricionistaWithUsuario(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar nutricionistas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Nutricionista> findByEspecialidad(String especialidad) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Nutricionista> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT n.*, u.* FROM nutricionistas n JOIN usuarios u ON n.usuario_id=u.id WHERE LOWER(n.especialidad) LIKE ?");
            stmt.setString(1, "%" + especialidad.toLowerCase() + "%");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapNutricionistaWithUsuario(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar nutricionistas por especialidad", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long countClientesAsignados(Long nutricionistaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT COUNT(*) FROM asignaciones WHERE nutricionista_id=? AND activa=true");
            stmt.setLong(1, nutricionistaId);
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar clientes asignados", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM nutricionistas");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar nutricionistas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Nutricionista mapNutricionistaWithUsuario(ResultSet rs) throws SQLException {
        Nutricionista n = new Nutricionista();
        n.setId(rs.getLong("n.id"));

        Usuario u = new Usuario();
        u.setId(rs.getLong("u.id"));
        u.setUsername(rs.getString("u.username"));
        u.setEmail(rs.getString("u.email"));
        u.setNombre(rs.getString("u.nombre"));
        u.setApellido(rs.getString("u.apellido"));
        u.setTelefono(rs.getString("u.telefono"));
        u.setActivo(rs.getBoolean("u.activo"));
        n.setUsuario(u);

        n.setNumeroLicencia(rs.getString("n.numero_licencia"));
        n.setEspecialidad(rs.getString("n.especialidad"));
        n.setAniosExperiencia(rs.getInt("n.anios_experiencia"));
        n.setHorarioDisponible(rs.getString("n.horario_disponible"));
        n.setFechaCreacion(toLocalDateTime(rs.getTimestamp("n.fecha_registro")));
        return n;
    }
}
