package com.gymsystem.dao.impl;

import com.gymsystem.dao.ClienteDAO;
import com.gymsystem.dao.EntrenadorDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Entrenador;
import com.gymsystem.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EntrenadorDAOImpl extends BaseDAOImpl implements EntrenadorDAO {

    @Override
    public Entrenador save(Entrenador entrenador) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO entrenadores (usuario_id, especialidad, certificacion, anios_experiencia, horario_disponible) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, entrenador.getUsuario().getId());
            setStringOrNull(stmt, 2, entrenador.getEspecialidad());
            setStringOrNull(stmt, 3, entrenador.getCertificacion());
            stmt.setInt(4, entrenador.getAniosExperiencia());
            setStringOrNull(stmt, 5, entrenador.getHorarioDisponible());
            stmt.executeUpdate();
            entrenador.setId(getGeneratedId(stmt));
            logger.info("Entrenador creado: id={}", entrenador.getId());
            return entrenador;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear entrenador", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Entrenador update(Entrenador entrenador) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE entrenadores SET especialidad=?, certificacion=?, anios_experiencia=?, horario_disponible=? WHERE id=?");
            setStringOrNull(stmt, 1, entrenador.getEspecialidad());
            setStringOrNull(stmt, 2, entrenador.getCertificacion());
            stmt.setInt(3, entrenador.getAniosExperiencia());
            setStringOrNull(stmt, 4, entrenador.getHorarioDisponible());
            stmt.setLong(5, entrenador.getId());
            stmt.executeUpdate();
            return entrenador;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar entrenador", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM entrenadores WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar entrenador", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Entrenador> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT e.*, u.* FROM entrenadores e JOIN usuarios u ON e.usuario_id=u.id WHERE e.id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapEntrenadorWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar entrenador por id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Entrenador> findByIdWithUsuario(Long id) {
        return findById(id);
    }

    @Override
    public Optional<Entrenador> findByUsuarioId(Long usuarioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT e.*, u.* FROM entrenadores e JOIN usuarios u ON e.usuario_id=u.id WHERE e.usuario_id=?");
            stmt.setLong(1, usuarioId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapEntrenadorWithUsuario(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar entrenador por usuario_id", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Entrenador> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Entrenador> entrenadores = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT e.*, u.* FROM entrenadores e JOIN usuarios u ON e.usuario_id=u.id ORDER BY u.nombre, u.apellido");
            rs = stmt.executeQuery();
            while (rs.next()) entrenadores.add(mapEntrenadorWithUsuario(rs));
            return entrenadores;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar entrenadores", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Entrenador> findByEspecialidad(String especialidad) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Entrenador> entrenadores = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT e.*, u.* FROM entrenadores e JOIN usuarios u ON e.usuario_id=u.id WHERE LOWER(e.especialidad) LIKE ?");
            stmt.setString(1, "%" + especialidad.toLowerCase() + "%");
            rs = stmt.executeQuery();
            while (rs.next()) entrenadores.add(mapEntrenadorWithUsuario(rs));
            return entrenadores;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar entrenadores por especialidad", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<ClienteDAO> findClientesByEntrenadorId(Long entrenadorId) {
        return List.of();
    }

    @Override
    public long countClientesAsignados(Long entrenadorId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT COUNT(*) FROM asignaciones WHERE entrenador_id=? AND activa=true");
            stmt.setLong(1, entrenadorId);
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar clientes asignados", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM entrenadores");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar entrenadores", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Entrenador mapEntrenadorWithUsuario(ResultSet rs) throws SQLException {
        Entrenador e = new Entrenador();
        e.setId(rs.getLong("e.id"));

        Usuario u = new Usuario();
        u.setId(rs.getLong("u.id"));
        u.setUsername(rs.getString("u.username"));
        u.setEmail(rs.getString("u.email"));
        u.setNombre(rs.getString("u.nombre"));
        u.setApellido(rs.getString("u.apellido"));
        u.setTelefono(rs.getString("u.telefono"));
        u.setActivo(rs.getBoolean("u.activo"));
        e.setUsuario(u);

        e.setEspecialidad(rs.getString("e.especialidad"));
        e.setCertificacion(rs.getString("e.certificacion"));
        e.setAniosExperiencia(rs.getInt("e.anios_experiencia"));
        e.setHorarioDisponible(rs.getString("e.horario_disponible"));
        e.setFechaCreacion(toLocalDateTime(rs.getTimestamp("e.fecha_registro")));
        return e;
    }
}
