package com.gymsystem.dao.impl;

import com.gymsystem.dao.ComidaDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Comida;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ComidaDAOImpl extends BaseDAOImpl implements ComidaDAO {

    @Override
    public Comida save(Comida comida) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO comidas (plan_alimenticio_id, nombre, tipo_comida, hora_sugerida, orden_dia, calorias, proteinas_gramos, carbohidratos_gramos, grasas_gramos, porcion_descripcion, notas_preparacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, comida.getPlanAlimenticio().getId());
            stmt.setString(2, comida.getNombre());
            stmt.setString(3, comida.getTipoComida());
            stmt.setTime(4, comida.getHoraSugerida() != null ? Time.valueOf(comida.getHoraSugerida()) : null);
            stmt.setInt(5, comida.getOrdenDia());
            setBigDecimalOrNull(stmt, 6, comida.getCalorias());
            setBigDecimalOrNull(stmt, 7, comida.getProteinasGramos());
            setBigDecimalOrNull(stmt, 8, comida.getCarbohidratosGramos());
            setBigDecimalOrNull(stmt, 9, comida.getGrasasGramos());
            setStringOrNull(stmt, 10, comida.getPorcionDescripcion());
            setStringOrNull(stmt, 11, comida.getNotasPreparacion());
            stmt.executeUpdate();
            comida.setId(getGeneratedId(stmt));
            return comida;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear comida", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Comida update(Comida comida) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE comidas SET nombre=?, tipo_comida=?, hora_sugerida=?, orden_dia=?, calorias=?, proteinas_gramos=?, carbohidratos_gramos=?, grasas_gramos=?, porcion_descripcion=?, notas_preparacion=? WHERE id=?");
            stmt.setString(1, comida.getNombre());
            stmt.setString(2, comida.getTipoComida());
            stmt.setTime(3, comida.getHoraSugerida() != null ? Time.valueOf(comida.getHoraSugerida()) : null);
            stmt.setInt(4, comida.getOrdenDia());
            setBigDecimalOrNull(stmt, 5, comida.getCalorias());
            setBigDecimalOrNull(stmt, 6, comida.getProteinasGramos());
            setBigDecimalOrNull(stmt, 7, comida.getCarbohidratosGramos());
            setBigDecimalOrNull(stmt, 8, comida.getGrasasGramos());
            setStringOrNull(stmt, 9, comida.getPorcionDescripcion());
            setStringOrNull(stmt, 10, comida.getNotasPreparacion());
            stmt.setLong(11, comida.getId());
            stmt.executeUpdate();
            return comida;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar comida", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM comidas WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar comida", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Comida> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM comidas WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapComida(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar comida", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Comida> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Comida> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM comidas ORDER BY plan_alimenticio_id, orden_dia");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapComida(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar comidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Comida> findByPlanAlimenticioId(Long planAlimenticioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Comida> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM comidas WHERE plan_alimenticio_id=? ORDER BY orden_dia");
            stmt.setLong(1, planAlimenticioId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapComida(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar comidas del plan", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Comida> findByTipoComida(Long planAlimenticioId, String tipoComida) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Comida> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM comidas WHERE plan_alimenticio_id=? AND tipo_comida=? ORDER BY orden_dia");
            stmt.setLong(1, planAlimenticioId);
            stmt.setString(2, tipoComida);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapComida(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar comidas por tipo", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void deleteByPlanAlimenticioId(Long planAlimenticioId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM comidas WHERE plan_alimenticio_id=?");
            stmt.setLong(1, planAlimenticioId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar comidas del plan", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM comidas");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar comidas", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Comida mapComida(ResultSet rs) throws SQLException {
        Comida c = new Comida();
        c.setId(rs.getLong("id"));
        c.setPlanAlimenticio(new com.gymsystem.model.PlanAlimenticio(rs.getLong("plan_alimenticio_id")));
        c.setNombre(rs.getString("nombre"));
        c.setTipoComida(rs.getString("tipo_comida"));
        c.setHoraSugerida(toLocalTime(rs.getTime("hora_sugerida")));
        c.setOrdenDia(rs.getInt("orden_dia"));
        c.setCalorias(rs.getBigDecimal("calorias"));
        c.setProteinasGramos(rs.getBigDecimal("proteinas_gramos"));
        c.setCarbohidratosGramos(rs.getBigDecimal("carbohidratos_gramos"));
        c.setGrasasGramos(rs.getBigDecimal("grasas_gramos"));
        c.setPorcionDescripcion(rs.getString("porcion_descripcion"));
        c.setNotasPreparacion(rs.getString("notas_preparacion"));
        return c;
    }
}
