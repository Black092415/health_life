package com.gymsystem.dao.impl;

import com.gymsystem.dao.EjercicioDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Ejercicio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EjercicioDAOImpl extends BaseDAOImpl implements EjercicioDAO {

    @Override
    public Ejercicio save(Ejercicio ejercicio) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO ejercicios (nombre, descripcion, grupo_muscular, tipo_ejercicio, equipo_necesario, nivel_dificultad, url_referencia) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, ejercicio.getNombre());
            setStringOrNull(stmt, 2, ejercicio.getDescripcion());
            stmt.setString(3, ejercicio.getGrupoMuscular());
            stmt.setString(4, ejercicio.getTipoEjercicio());
            setStringOrNull(stmt, 5, ejercicio.getEquipoNecesario());
            setStringOrNull(stmt, 6, ejercicio.getNivelDificultad());
            setStringOrNull(stmt, 7, ejercicio.getUrlReferencia());
            stmt.executeUpdate();
            ejercicio.setId(getGeneratedId(stmt));
            logger.info("Ejercicio creado: {}", ejercicio.getNombre());
            return ejercicio;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear ejercicio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Ejercicio update(Ejercicio ejercicio) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE ejercicios SET nombre=?, descripcion=?, grupo_muscular=?, tipo_ejercicio=?, equipo_necesario=?, nivel_dificultad=?, url_referencia=?, activo=? WHERE id=?");
            stmt.setString(1, ejercicio.getNombre());
            setStringOrNull(stmt, 2, ejercicio.getDescripcion());
            stmt.setString(3, ejercicio.getGrupoMuscular());
            stmt.setString(4, ejercicio.getTipoEjercicio());
            setStringOrNull(stmt, 5, ejercicio.getEquipoNecesario());
            setStringOrNull(stmt, 6, ejercicio.getNivelDificultad());
            setStringOrNull(stmt, 7, ejercicio.getUrlReferencia());
            stmt.setBoolean(8, ejercicio.isActivo());
            stmt.setLong(9, ejercicio.getId());
            stmt.executeUpdate();
            return ejercicio;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar ejercicio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM ejercicios WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar ejercicio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Ejercicio> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM ejercicios WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapEjercicio(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar ejercicio", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Ejercicio> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Ejercicio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM ejercicios ORDER BY nombre");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapEjercicio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar ejercicios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Ejercicio> findByGrupoMuscular(String grupoMuscular) {
        return findByCampo("grupo_muscular", grupoMuscular);
    }

    @Override
    public List<Ejercicio> findByTipo(String tipo) {
        return findByCampo("tipo_ejercicio", tipo);
    }

    @Override
    public List<Ejercicio> findByNivelDificultad(String nivel) {
        return findByCampo("nivel_dificultad", nivel);
    }

    private List<Ejercicio> findByCampo(String campo, String valor) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Ejercicio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM ejercicios WHERE " + campo + " = ? ORDER BY nombre");
            stmt.setString(1, valor);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapEjercicio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar ejercicios por " + campo, e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Ejercicio> searchByNombre(String termino) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Ejercicio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM ejercicios WHERE LOWER(nombre) LIKE ? ORDER BY nombre");
            stmt.setString(1, "%" + termino.toLowerCase() + "%");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapEjercicio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar ejercicios por nombre", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Ejercicio> findActivos() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Ejercicio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM ejercicios WHERE activo=true ORDER BY nombre");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapEjercicio(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar ejercicios activos", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM ejercicios");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar ejercicios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Ejercicio mapEjercicio(ResultSet rs) throws SQLException {
        Ejercicio e = new Ejercicio();
        e.setId(rs.getLong("id"));
        e.setNombre(rs.getString("nombre"));
        e.setDescripcion(rs.getString("descripcion"));
        e.setGrupoMuscular(rs.getString("grupo_muscular"));
        e.setTipoEjercicio(rs.getString("tipo_ejercicio"));
        e.setEquipoNecesario(rs.getString("equipo_necesario"));
        e.setNivelDificultad(rs.getString("nivel_dificultad"));
        e.setUrlReferencia(rs.getString("url_referencia"));
        e.setActivo(rs.getBoolean("activo"));
        e.setFechaCreacion(toLocalDateTime(rs.getTimestamp("fecha_creacion")));
        return e;
    }
}
