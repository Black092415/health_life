package com.gymsystem.dao.impl;

import com.gymsystem.dao.AsignacionDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.Asignacion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AsignacionDAOImpl extends BaseDAOImpl implements AsignacionDAO {

    @Override
    public Asignacion save(Asignacion asignacion) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO asignaciones (cliente_id, entrenador_id, nutricionista_id) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, asignacion.getCliente().getId());
            setLongOrNull(stmt, 2, asignacion.getEntrenador() != null ? asignacion.getEntrenador().getId() : null);
            setLongOrNull(stmt, 3, asignacion.getNutricionista() != null ? asignacion.getNutricionista().getId() : null);
            stmt.executeUpdate();
            asignacion.setId(getGeneratedId(stmt));
            return asignacion;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear asignación", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Asignacion update(Asignacion asignacion) {
        return asignacion;
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM asignaciones WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar asignación", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<Asignacion> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM asignaciones WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapAsignacion(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar asignación", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Asignacion> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Asignacion> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM asignaciones ORDER BY fecha_asignacion DESC");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapAsignacion(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar asignaciones", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<Asignacion> findActivaByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM asignaciones WHERE cliente_id=? AND activa=true ORDER BY fecha_asignacion DESC LIMIT 1");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapAsignacion(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar asignación activa", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Asignacion> findByEntrenadorId(Long entrenadorId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Asignacion> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM asignaciones WHERE entrenador_id=? AND activa=true ORDER BY fecha_asignacion DESC");
            stmt.setLong(1, entrenadorId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapAsignacion(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar asignaciones por entrenador", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<Asignacion> findByNutricionistaId(Long nutricionistaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Asignacion> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM asignaciones WHERE nutricionista_id=? AND activa=true ORDER BY fecha_asignacion DESC");
            stmt.setLong(1, nutricionistaId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapAsignacion(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar asignaciones por nutricionista", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void finalizarAsignacion(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE asignaciones SET activa=false, fecha_fin=CURRENT_TIMESTAMP WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al finalizar asignación", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM asignaciones");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar asignaciones", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private Asignacion mapAsignacion(ResultSet rs) throws SQLException {
        Asignacion a = new Asignacion();
        a.setId(rs.getLong("id"));
        a.setCliente(new com.gymsystem.model.Cliente(rs.getLong("cliente_id")));
        long entrenadorId = rs.getLong("entrenador_id");
        if (!rs.wasNull()) a.setEntrenador(new com.gymsystem.model.Entrenador(entrenadorId));
        long nutricionistaId = rs.getLong("nutricionista_id");
        if (!rs.wasNull()) a.setNutricionista(new com.gymsystem.model.Nutricionista(nutricionistaId));
        a.setFechaAsignacion(toLocalDateTime(rs.getTimestamp("fecha_asignacion")));
        a.setFechaFin(toLocalDateTime(rs.getTimestamp("fecha_fin")));
        a.setActiva(rs.getBoolean("activa"));
        return a;
    }
}
