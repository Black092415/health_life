package com.gymsystem.dao.impl;

import com.gymsystem.dao.PlanAlimenticioDAO;
import com.gymsystem.exception.DatabaseException;
import com.gymsystem.model.PlanAlimenticio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PlanAlimenticioDAOImpl extends BaseDAOImpl implements PlanAlimenticioDAO {

    @Override
    public PlanAlimenticio save(PlanAlimenticio plan) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "INSERT INTO planes_alimenticios (nutricionista_id, cliente_id, nombre, descripcion, objetivo_calorias, objetivo_proteinas, objetivo_carbohidratos, objetivo_grasas, objetivo_agua_lts, fecha_inicio, fecha_fin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setLong(1, plan.getNutricionista().getId());
            setLongOrNull(stmt, 2, plan.getCliente() != null ? plan.getCliente().getId() : null);
            stmt.setString(3, plan.getNombre());
            setStringOrNull(stmt, 4, plan.getDescripcion());
            setBigDecimalOrNull(stmt, 5, plan.getObjetivoCalorias());
            setBigDecimalOrNull(stmt, 6, plan.getObjetivoProteinas());
            setBigDecimalOrNull(stmt, 7, plan.getObjetivoCarbohidratos());
            setBigDecimalOrNull(stmt, 8, plan.getObjetivoGrasas());
            setBigDecimalOrNull(stmt, 9, plan.getObjetivoAguaLts());
            stmt.setDate(10, plan.getFechaInicio() != null ? Date.valueOf(plan.getFechaInicio()) : null);
            stmt.setDate(11, plan.getFechaFin() != null ? Date.valueOf(plan.getFechaFin()) : null);
            stmt.executeUpdate();
            plan.setId(getGeneratedId(stmt));
            logger.info("Plan alimenticio creado: {}", plan.getNombre());
            return plan;
        } catch (SQLException e) {
            throw new DatabaseException("Error al crear plan alimenticio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public PlanAlimenticio update(PlanAlimenticio plan) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "UPDATE planes_alimenticios SET nombre=?, descripcion=?, objetivo_calorias=?, objetivo_proteinas=?, objetivo_carbohidratos=?, objetivo_grasas=?, objetivo_agua_lts=?, fecha_inicio=?, fecha_fin=?, activo=? WHERE id=?");
            stmt.setString(1, plan.getNombre());
            setStringOrNull(stmt, 2, plan.getDescripcion());
            setBigDecimalOrNull(stmt, 3, plan.getObjetivoCalorias());
            setBigDecimalOrNull(stmt, 4, plan.getObjetivoProteinas());
            setBigDecimalOrNull(stmt, 5, plan.getObjetivoCarbohidratos());
            setBigDecimalOrNull(stmt, 6, plan.getObjetivoGrasas());
            setBigDecimalOrNull(stmt, 7, plan.getObjetivoAguaLts());
            stmt.setDate(8, plan.getFechaInicio() != null ? Date.valueOf(plan.getFechaInicio()) : null);
            stmt.setDate(9, plan.getFechaFin() != null ? Date.valueOf(plan.getFechaFin()) : null);
            stmt.setBoolean(10, plan.isActivo());
            stmt.setLong(11, plan.getId());
            stmt.executeUpdate();
            return plan;
        } catch (SQLException e) {
            throw new DatabaseException("Error al actualizar plan alimenticio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public void delete(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("DELETE FROM planes_alimenticios WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al eliminar plan alimenticio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public Optional<PlanAlimenticio> findById(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM planes_alimenticios WHERE id=?");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapPlan(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar plan alimenticio", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<PlanAlimenticio> findByIdWithComidas(Long id) {
        Optional<PlanAlimenticio> opt = findById(id);
        opt.ifPresent(plan -> {
            ComidaDAOImpl comidaDao = new ComidaDAOImpl();
            plan.setComidas(comidaDao.findByPlanAlimenticioId(id));
        });
        return opt;
    }

    @Override
    public List<PlanAlimenticio> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<PlanAlimenticio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT * FROM planes_alimenticios ORDER BY fecha_creacion DESC");
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapPlan(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al listar planes alimenticios", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<PlanAlimenticio> findByNutricionistaId(Long nutricionistaId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<PlanAlimenticio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM planes_alimenticios WHERE nutricionista_id=? ORDER BY fecha_creacion DESC");
            stmt.setLong(1, nutricionistaId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapPlan(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar planes por nutricionista", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public List<PlanAlimenticio> findByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<PlanAlimenticio> lista = new ArrayList<>();
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM planes_alimenticios WHERE cliente_id=? ORDER BY fecha_creacion DESC");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            while (rs.next()) lista.add(mapPlan(rs));
            return lista;
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar planes por cliente", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public Optional<PlanAlimenticio> findActivoByClienteId(Long clienteId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(
                    "SELECT * FROM planes_alimenticios WHERE cliente_id=? AND activo=true ORDER BY fecha_creacion DESC LIMIT 1");
            stmt.setLong(1, clienteId);
            rs = stmt.executeQuery();
            if (rs.next()) return Optional.of(mapPlan(rs));
            return Optional.empty();
        } catch (SQLException e) {
            throw new DatabaseException("Error al buscar plan activo", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    @Override
    public void deactivate(Long id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("UPDATE planes_alimenticios SET activo=false WHERE id=?");
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error al desactivar plan alimenticio", e);
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    @Override
    public long count() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            stmt = conn.prepareStatement("SELECT COUNT(*) FROM planes_alimenticios");
            rs = stmt.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error al contar planes", e);
        } finally {
            closeResources(conn, stmt, rs);
        }
    }

    private PlanAlimenticio mapPlan(ResultSet rs) throws SQLException {
        PlanAlimenticio p = new PlanAlimenticio();
        p.setId(rs.getLong("id"));
        p.setNutricionista(new com.gymsystem.model.Nutricionista(rs.getLong("nutricionista_id")));
        Long clienteId = rs.getLong("cliente_id");
        if (!rs.wasNull()) p.setCliente(new com.gymsystem.model.Cliente(clienteId));
        p.setNombre(rs.getString("nombre"));
        p.setDescripcion(rs.getString("descripcion"));
        p.setObjetivoCalorias(rs.getBigDecimal("objetivo_calorias"));
        p.setObjetivoProteinas(rs.getBigDecimal("objetivo_proteinas"));
        p.setObjetivoCarbohidratos(rs.getBigDecimal("objetivo_carbohidratos"));
        p.setObjetivoGrasas(rs.getBigDecimal("objetivo_grasas"));
        p.setObjetivoAguaLts(rs.getBigDecimal("objetivo_agua_lts"));
        p.setFechaInicio(toLocalDate(rs.getDate("fecha_inicio")));
        p.setFechaFin(toLocalDate(rs.getDate("fecha_fin")));
        p.setActivo(rs.getBoolean("activo"));
        p.setFechaCreacion(toLocalDateTime(rs.getTimestamp("fecha_creacion")));
        return p;
    }
}
