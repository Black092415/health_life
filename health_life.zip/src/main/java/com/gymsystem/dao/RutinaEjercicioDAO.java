package com.gymsystem.dao;

import com.gymsystem.model.RutinaEjercicio;

import java.util.List;

public interface RutinaEjercicioDAO extends GenericDAO<RutinaEjercicio, Long> {

    List<RutinaEjercicio> findByRutinaId(Long rutinaId);

    void deleteByRutinaId(Long rutinaId);

    void updateOrden(Long id, int nuevoOrden);
}
