package com.gymsystem.dao;

import com.gymsystem.model.MedidasCorporales;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MedidasCorporalesDAO extends GenericDAO<MedidasCorporales, Long> {

    List<MedidasCorporales> findByClienteId(Long clienteId);

    List<MedidasCorporales> findByClienteIdBetweenDates(Long clienteId, LocalDateTime desde, LocalDateTime hasta);

    Optional<MedidasCorporales> findLastByClienteId(Long clienteId);

    Optional<MedidasCorporales> findFirstByClienteId(Long clienteId);
}
