package com.gymsystem.dao;

import com.gymsystem.model.Nutricionista;

import java.util.List;
import java.util.Optional;

public interface NutricionistaDAO extends GenericDAO<Nutricionista, Long> {

    Optional<Nutricionista> findByUsuarioId(Long usuarioId);

    Optional<Nutricionista> findByIdWithUsuario(Long id);

    Optional<Nutricionista> findByLicencia(String numeroLicencia);

    List<Nutricionista> findByEspecialidad(String especialidad);

    long countClientesAsignados(Long nutricionistaId);
}
