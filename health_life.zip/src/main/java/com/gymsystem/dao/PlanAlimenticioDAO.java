package com.gymsystem.dao;

import com.gymsystem.model.PlanAlimenticio;

import java.util.List;
import java.util.Optional;

public interface PlanAlimenticioDAO extends GenericDAO<PlanAlimenticio, Long> {

    List<PlanAlimenticio> findByNutricionistaId(Long nutricionistaId);

    List<PlanAlimenticio> findByClienteId(Long clienteId);

    Optional<PlanAlimenticio> findActivoByClienteId(Long clienteId);

    Optional<PlanAlimenticio> findByIdWithComidas(Long id);

    void deactivate(Long id);
}
