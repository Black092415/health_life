package com.gymsystem.dao;

import com.gymsystem.model.Sesion;

import java.util.List;
import java.util.Optional;

public interface SesionDAO extends GenericDAO<Sesion, Long> {

    Optional<Sesion> findByToken(String token);

    List<Sesion> findActivasByUsuarioId(Long usuarioId);

    void cerrarSesion(String token);

    void cerrarTodasSesionesUsuario(Long usuarioId);

    void limpiarSesionesExpiradas();

    boolean isTokenValido(String token);
}
