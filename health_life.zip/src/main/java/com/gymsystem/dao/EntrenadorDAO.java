package com.gymsystem.dao;

import com.gymsystem.model.Entrenador;

import java.util.List;
import java.util.Optional;

public interface EntrenadorDAO extends GenericDAO<Entrenador, Long> {

    Optional<Entrenador> findByUsuarioId(Long usuarioId);

    Optional<Entrenador> findByIdWithUsuario(Long id);

    List<Entrenador> findByEspecialidad(String especialidad);

    List<ClienteDAO> findClientesByEntrenadorId(Long entrenadorId);

    long countClientesAsignados(Long entrenadorId);
}
