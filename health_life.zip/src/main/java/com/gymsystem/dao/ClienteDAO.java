package com.gymsystem.dao;

import com.gymsystem.model.Cliente;

import java.util.List;
import java.util.Optional;

public interface ClienteDAO extends GenericDAO<Cliente, Long> {

    Optional<Cliente> findByUsuarioId(Long usuarioId);

    Optional<Cliente> findByIdWithUsuario(Long id);

    List<Cliente> findByEntrenadorId(Long entrenadorId);

    List<Cliente> findByNutricionistaId(Long nutricionistaId);

    List<Cliente> searchByNombre(String termino);

    List<Cliente> searchByEmail(String termino);

    void asignarEntrenador(Long clienteId, Long entrenadorId);

    void asignarNutricionista(Long clienteId, Long nutricionistaId);
}
