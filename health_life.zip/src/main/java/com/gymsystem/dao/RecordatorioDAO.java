package com.gymsystem.dao;

import com.gymsystem.model.Recordatorio;

import java.time.LocalDateTime;
import java.util.List;

public interface RecordatorioDAO extends GenericDAO<Recordatorio, Long> {

    List<Recordatorio> findByClienteId(Long clienteId);

    List<Recordatorio> findPendientesByClienteId(Long clienteId);

    List<Recordatorio> findByDateRange(LocalDateTime desde, LocalDateTime hasta);

    List<Recordatorio> findByTipo(String tipo);

    void marcarCompletado(Long id);

    long countPendientesByClienteId(Long clienteId);
}
