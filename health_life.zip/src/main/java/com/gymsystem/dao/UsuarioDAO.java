package com.gymsystem.dao;

import com.gymsystem.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioDAO extends GenericDAO<Usuario, Long> {

    Optional<Usuario> findByEmail(String email);

    Optional<Usuario> findByUsername(String username);

    Optional<Usuario> findByEmailWithRoles(String email);

    Optional<Usuario> findByIdWithRoles(Long id);

    List<Usuario> findByRol(String nombreRol);

    void updateLastAccess(Long usuarioId);

    void activate(Long id);

    void deactivate(Long id);

    boolean existsByEmail(String email);

    boolean existsByUsername(String username);
}
