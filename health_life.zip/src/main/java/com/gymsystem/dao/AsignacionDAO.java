package com.gymsystem.dao;

import com.gymsystem.model.Asignacion;

import java.util.List;
import java.util.Optional;

public interface AsignacionDAO extends GenericDAO<Asignacion, Long> {

    Optional<Asignacion> findActivaByClienteId(Long clienteId);

    List<Asignacion> findByEntrenadorId(Long entrenadorId);

    List<Asignacion> findByNutricionistaId(Long nutricionistaId);

    void finalizarAsignacion(Long id);
}
