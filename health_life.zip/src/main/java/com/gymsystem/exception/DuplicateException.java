package com.gymsystem.exception;

public class DuplicateException extends RuntimeException {

    public DuplicateException(String message) {
        super(message);
    }

    public DuplicateException(String message, Throwable cause) {
        super(message, cause);
    }

    public DuplicateException(String entidad, String campo, String valor) {
        super(String.format("Ya existe un registro de %s con %s = '%s'", entidad, campo, valor));
    }
}
