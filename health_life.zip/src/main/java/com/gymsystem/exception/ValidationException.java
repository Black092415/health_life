package com.gymsystem.exception;

import java.util.ArrayList;
import java.util.List;

public class ValidationException extends RuntimeException {

    private final List<String> errores;

    public ValidationException(String message) {
        super(message);
        this.errores = new ArrayList<>();
        this.errores.add(message);
    }

    public ValidationException(List<String> errores) {
        super(String.join("; ", errores));
        this.errores = new ArrayList<>(errores);
    }

    public List<String> getErrores() {
        return errores;
    }
}
