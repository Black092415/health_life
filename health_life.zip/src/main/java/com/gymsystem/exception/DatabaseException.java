package com.gymsystem.exception;

public class DatabaseException extends RuntimeException {

    public DatabaseException(String message) {
        super(message);
    }

    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }

    public static DatabaseException forOperation(String operation, Throwable cause) {
        return new DatabaseException("Error en operacion de base de datos: " + operation, cause);
    }
}
