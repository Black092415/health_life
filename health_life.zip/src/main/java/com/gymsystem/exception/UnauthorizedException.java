package com.gymsystem.exception;

public class UnauthorizedException extends RuntimeException {

    public UnauthorizedException(String message) {
        super(message);
    }

    public UnauthorizedException(String usuario, String accion) {
        super(String.format("El usuario '%s' no tiene permisos para realizar: %s", usuario, accion));
    }
}
