package com.gymsystem.exception;

public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }

    public NotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotFoundException(String entidad, Long id) {
        super(String.format("No se encontró %s con id = %d", entidad, id));
    }

    public NotFoundException(String entidad, String campo, String valor) {
        super(String.format("No se encontró %s con %s = '%s'", entidad, campo, valor));
    }
}
