package com.gymsystem.security;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.UUID;

public final class TokenService {

    private static final SecureRandom secureRandom = new SecureRandom();
    private static final int TOKEN_BYTES = 48;

    private TokenService() {}

    public static String generarToken() {
        byte[] tokenBytes = new byte[TOKEN_BYTES];
        secureRandom.nextBytes(tokenBytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(tokenBytes);
    }

    public static String generarTokenUUID() {
        return UUID.randomUUID().toString()
                + "-" + UUID.randomUUID().toString();
    }

    public static String generarCodigoCorto() {
        int code = secureRandom.nextInt(900000) + 100000;
        return String.valueOf(code);
    }
}
