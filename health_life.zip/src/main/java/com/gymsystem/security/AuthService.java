package com.gymsystem.security;

import com.gymsystem.dao.SesionDAO;
import com.gymsystem.dao.UsuarioDAO;
import com.gymsystem.dao.impl.SesionDAOImpl;
import com.gymsystem.dao.impl.UsuarioDAOImpl;
import com.gymsystem.dto.LoginDTO;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.exception.UnauthorizedException;
import com.gymsystem.model.Sesion;
import com.gymsystem.model.Usuario;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

public class AuthService {

    private static final Logger audit = LoggerFactory.getLogger("com.gymsystem.audit");
    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private static final long SESION_DURACION_HORAS = 24;

    private final UsuarioDAO usuarioDAO;
    private final SesionDAO sesionDAO;
    private final PasswordService passwordService;

    public AuthService() {
        this.usuarioDAO = new UsuarioDAOImpl();
        this.sesionDAO = new SesionDAOImpl();
        this.passwordService = new PasswordService();
    }

    public AuthService(UsuarioDAO usuarioDAO, SesionDAO sesionDAO, PasswordService passwordService) {
        this.usuarioDAO = usuarioDAO;
        this.sesionDAO = sesionDAO;
        this.passwordService = passwordService;
    }

    public Sesion login(LoginDTO loginDTO) {
        Usuario usuario = usuarioDAO.findByEmailWithRoles(loginDTO.getEmail())
                .orElseThrow(() -> new NotFoundException("Usuario", "email", loginDTO.getEmail()));

        if (!usuario.isActivo()) {
            audit.warn("LOGIN_FALLIDO_INACTIVO | Email: {}", loginDTO.getEmail());
            throw new UnauthorizedException("La cuenta está desactivada. Contacte al administrador.");
        }

        if (!passwordService.verifyPassword(loginDTO.getPassword(), usuario.getPasswordHash())) {
            audit.warn("LOGIN_FALLIDO_PASSWORD | Email: {}", loginDTO.getEmail());
            throw new UnauthorizedException("Credenciales inválidas");
        }

        usuarioDAO.updateLastAccess(usuario.getId());

        String token = TokenService.generarTokenUUID();
        Sesion sesion = new Sesion(
                usuario,
                token,
                LocalDateTime.now().plusHours(SESION_DURACION_HORAS)
        );
        sesion = sesionDAO.save(sesion);

        audit.info("LOGIN_EXITOSO | Usuario: {} | ID: {} | Rol: {}",
                usuario.getEmail(), usuario.getId(),
                usuario.getRoles().stream().map(r -> r.getNombre()).reduce("", (a, b) -> a + "," + b));
        log.info("Sesión iniciada para: {}", usuario.getEmail());
        return sesion;
    }

    public void logout(String token) {
        sesionDAO.cerrarSesion(token);
        audit.info("LOGOUT | Token: {}", token);
    }

    public Usuario validarSesion(String token) {
        if (token == null || token.isBlank()) {
            throw new UnauthorizedException("Token de sesión requerido");
        }

        if (!sesionDAO.isTokenValido(token)) {
            throw new UnauthorizedException("Sesión expirada o inválida");
        }

        Sesion sesion = sesionDAO.findByToken(token)
                .orElseThrow(() -> new UnauthorizedException("Sesión no encontrada"));

        return usuarioDAO.findByIdWithRoles(sesion.getUsuario().getId())
                .orElseThrow(() -> new NotFoundException("Usuario", sesion.getUsuario().getId()));
    }

    public void validarPermiso(Usuario usuario, String... rolesPermitidos) {
        boolean tienePermiso = false;
        for (String rol : rolesPermitidos) {
            if (usuario.tieneRol(rol)) {
                tienePermiso = true;
                break;
            }
        }
        if (!tienePermiso) {
            throw new UnauthorizedException(usuario.getUsername(), "Acceso denegado. Requiere rol: " + String.join(", ", rolesPermitidos));
        }
    }

    public boolean esAdmin(Usuario usuario) {
        return usuario.tieneRol("ADMIN");
    }

    public boolean esEntrenador(Usuario usuario) {
        return usuario.tieneRol("ENTRENADOR");
    }

    public boolean esNutricionista(Usuario usuario) {
        return usuario.tieneRol("NUTRICIONISTA");
    }

    public boolean esCliente(Usuario usuario) {
        return usuario.tieneRol("CLIENTE");
    }
}
