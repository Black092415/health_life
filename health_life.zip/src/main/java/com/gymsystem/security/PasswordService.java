package com.gymsystem.security;

import at.favre.lib.crypto.bcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PasswordService {

    private static final Logger log = LoggerFactory.getLogger(PasswordService.class);
    private static final int COST_FACTOR = 10;

    public String hashPassword(String plainPassword) {
        if (plainPassword == null || plainPassword.isBlank()) {
            throw new IllegalArgumentException("La contraseña no puede estar vacía");
        }
        String hash = BCrypt.withDefaults()
                .hashToString(COST_FACTOR, plainPassword.toCharArray());
        log.debug("Contraseña hasheada correctamente");
        return hash;
    }

    public boolean verifyPassword(String plainPassword, String hashedPassword) {
        if (plainPassword == null || hashedPassword == null) return false;
        BCrypt.Result result = BCrypt.verifyer()
                .verify(plainPassword.toCharArray(), hashedPassword);
        return result.verified;
    }

    public boolean necesitaRehash(String hashedPassword) {
        return false;
    }
}
