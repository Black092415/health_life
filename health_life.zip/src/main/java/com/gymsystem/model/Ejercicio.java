package com.gymsystem.model;

import java.util.Objects;

public class Ejercicio extends BaseEntity {

    private String nombre;
    private String descripcion;
    private String grupoMuscular;
    private String tipoEjercicio;
    private String equipoNecesario;
    private String nivelDificultad;
    private String urlReferencia;
    private boolean activo;

    public Ejercicio() {
        this.activo = true;
    }

    public Ejercicio(Long id) {
        super(id);
    }

    public Ejercicio(String nombre, String grupoMuscular, String tipoEjercicio) {
        this();
        this.nombre = nombre;
        this.grupoMuscular = grupoMuscular;
        this.tipoEjercicio = tipoEjercicio;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getGrupoMuscular() { return grupoMuscular; }
    public void setGrupoMuscular(String grupoMuscular) { this.grupoMuscular = grupoMuscular; }

    public String getTipoEjercicio() { return tipoEjercicio; }
    public void setTipoEjercicio(String tipoEjercicio) { this.tipoEjercicio = tipoEjercicio; }

    public String getEquipoNecesario() { return equipoNecesario; }
    public void setEquipoNecesario(String equipoNecesario) { this.equipoNecesario = equipoNecesario; }

    public String getNivelDificultad() { return nivelDificultad; }
    public void setNivelDificultad(String nivelDificultad) { this.nivelDificultad = nivelDificultad; }

    public String getUrlReferencia() { return urlReferencia; }
    public void setUrlReferencia(String urlReferencia) { this.urlReferencia = urlReferencia; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ejercicio ejercicio = (Ejercicio) o;
        return Objects.equals(id, ejercicio.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Ejercicio{id=" + id + ", nombre='" + nombre + "', grupoMuscular='" + grupoMuscular + "'}";
    }
}
