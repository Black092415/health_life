package com.gymsystem.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

public class MedidasCorporales {

    private Long id;
    private Cliente cliente;
    private LocalDateTime fechaRegistro;
    private BigDecimal cinturaCm;
    private BigDecimal caderaCm;
    private BigDecimal pechoCm;
    private BigDecimal brazoIzqCm;
    private BigDecimal brazoDerCm;
    private BigDecimal piernaIzqCm;
    private BigDecimal piernaDerCm;
    private BigDecimal cinturaCaderaRatio;
    private String notas;
    private String registradoPor;

    public MedidasCorporales() {
        this.fechaRegistro = LocalDateTime.now();
    }

    public MedidasCorporales(Cliente cliente) {
        this();
        this.cliente = cliente;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public BigDecimal getCinturaCm() { return cinturaCm; }
    public void setCinturaCm(BigDecimal cinturaCm) { this.cinturaCm = cinturaCm; }

    public BigDecimal getCaderaCm() { return caderaCm; }
    public void setCaderaCm(BigDecimal caderaCm) { this.caderaCm = caderaCm; }

    public BigDecimal getPechoCm() { return pechoCm; }
    public void setPechoCm(BigDecimal pechoCm) { this.pechoCm = pechoCm; }

    public BigDecimal getBrazoIzqCm() { return brazoIzqCm; }
    public void setBrazoIzqCm(BigDecimal brazoIzqCm) { this.brazoIzqCm = brazoIzqCm; }

    public BigDecimal getBrazoDerCm() { return brazoDerCm; }
    public void setBrazoDerCm(BigDecimal brazoDerCm) { this.brazoDerCm = brazoDerCm; }

    public BigDecimal getPiernaIzqCm() { return piernaIzqCm; }
    public void setPiernaIzqCm(BigDecimal piernaIzqCm) { this.piernaIzqCm = piernaIzqCm; }

    public BigDecimal getPiernaDerCm() { return piernaDerCm; }
    public void setPiernaDerCm(BigDecimal piernaDerCm) { this.piernaDerCm = piernaDerCm; }

    public BigDecimal getCinturaCaderaRatio() { return cinturaCaderaRatio; }
    public void setCinturaCaderaRatio(BigDecimal cinturaCaderaRatio) { this.cinturaCaderaRatio = cinturaCaderaRatio; }

    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }

    public String getRegistradoPor() { return registradoPor; }
    public void setRegistradoPor(String registradoPor) { this.registradoPor = registradoPor; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MedidasCorporales that = (MedidasCorporales) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "MedidasCorporales{id=" + id + ", cintura=" + cinturaCm + "cm, cadera=" + caderaCm + "cm}";
    }
}
