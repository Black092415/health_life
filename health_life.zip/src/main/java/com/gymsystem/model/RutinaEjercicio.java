package com.gymsystem.model;

import java.util.Objects;

public class RutinaEjercicio {

    private Long id;
    private Rutina rutina;
    private Ejercicio ejercicio;
    private int ordenEjecucion;
    private Integer series;
    private Integer repeticiones;
    private Integer duracionSegundos;
    private Integer descansoSegundos;
    private String notas;

    public RutinaEjercicio() {
    }

    public RutinaEjercicio(Rutina rutina, Ejercicio ejercicio, int ordenEjecucion) {
        this.rutina = rutina;
        this.ejercicio = ejercicio;
        this.ordenEjecucion = ordenEjecucion;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Rutina getRutina() { return rutina; }
    public void setRutina(Rutina rutina) { this.rutina = rutina; }

    public Ejercicio getEjercicio() { return ejercicio; }
    public void setEjercicio(Ejercicio ejercicio) { this.ejercicio = ejercicio; }

    public int getOrdenEjecucion() { return ordenEjecucion; }
    public void setOrdenEjecucion(int ordenEjecucion) { this.ordenEjecucion = ordenEjecucion; }

    public Integer getSeries() { return series; }
    public void setSeries(Integer series) { this.series = series; }

    public Integer getRepeticiones() { return repeticiones; }
    public void setRepeticiones(Integer repeticiones) { this.repeticiones = repeticiones; }

    public Integer getDuracionSegundos() { return duracionSegundos; }
    public void setDuracionSegundos(Integer duracionSegundos) { this.duracionSegundos = duracionSegundos; }

    public Integer getDescansoSegundos() { return descansoSegundos; }
    public void setDescansoSegundos(Integer descansoSegundos) { this.descansoSegundos = descansoSegundos; }

    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RutinaEjercicio that = (RutinaEjercicio) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "RutinaEjercicio{id=" + id + ", ejercicio=" + (ejercicio != null ? ejercicio.getNombre() : "null")
                + ", orden=" + ordenEjecucion + ", series=" + series + "}";
    }
}
