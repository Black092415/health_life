package com.gymsystem.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Recordatorio extends BaseEntity {

    private Cliente cliente;
    private Usuario creadoPor;
    private String titulo;
    private String descripcion;
    private String tipo;
    private LocalDateTime fechaProgramada;
    private LocalDateTime fechaCompletado;
    private boolean completado;
    private String recurrencia;

    public Recordatorio() {
        this.completado = false;
    }

    public Recordatorio(Long id) {
        super(id);
    }

    public Recordatorio(Cliente cliente, String titulo, LocalDateTime fechaProgramada) {
        this();
        this.cliente = cliente;
        this.titulo = titulo;
        this.fechaProgramada = fechaProgramada;
    }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Usuario getCreadoPor() { return creadoPor; }
    public void setCreadoPor(Usuario creadoPor) { this.creadoPor = creadoPor; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public LocalDateTime getFechaProgramada() { return fechaProgramada; }
    public void setFechaProgramada(LocalDateTime fechaProgramada) { this.fechaProgramada = fechaProgramada; }

    public LocalDateTime getFechaCompletado() { return fechaCompletado; }
    public void setFechaCompletado(LocalDateTime fechaCompletado) { this.fechaCompletado = fechaCompletado; }

    public boolean isCompletado() { return completado; }
    public void setCompletado(boolean completado) { this.completado = completado; }

    public String getRecurrencia() { return recurrencia; }
    public void setRecurrencia(String recurrencia) { this.recurrencia = recurrencia; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Recordatorio that = (Recordatorio) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Recordatorio{id=" + id + ", titulo='" + titulo + "', fecha=" + fechaProgramada + "}";
    }
}
