package com.gymsystem.model;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.Objects;

public class Comida {

    private Long id;
    private PlanAlimenticio planAlimenticio;
    private String nombre;
    private String tipoComida;
    private LocalTime horaSugerida;
    private int ordenDia;
    private BigDecimal calorias;
    private BigDecimal proteinasGramos;
    private BigDecimal carbohidratosGramos;
    private BigDecimal grasasGramos;
    private String porcionDescripcion;
    private String notasPreparacion;

    public Comida() {
    }

    public Comida(PlanAlimenticio planAlimenticio, String nombre, String tipoComida, int ordenDia) {
        this.planAlimenticio = planAlimenticio;
        this.nombre = nombre;
        this.tipoComida = tipoComida;
        this.ordenDia = ordenDia;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public PlanAlimenticio getPlanAlimenticio() { return planAlimenticio; }
    public void setPlanAlimenticio(PlanAlimenticio planAlimenticio) { this.planAlimenticio = planAlimenticio; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipoComida() { return tipoComida; }
    public void setTipoComida(String tipoComida) { this.tipoComida = tipoComida; }

    public LocalTime getHoraSugerida() { return horaSugerida; }
    public void setHoraSugerida(LocalTime horaSugerida) { this.horaSugerida = horaSugerida; }

    public int getOrdenDia() { return ordenDia; }
    public void setOrdenDia(int ordenDia) { this.ordenDia = ordenDia; }

    public BigDecimal getCalorias() { return calorias; }
    public void setCalorias(BigDecimal calorias) { this.calorias = calorias; }

    public BigDecimal getProteinasGramos() { return proteinasGramos; }
    public void setProteinasGramos(BigDecimal proteinasGramos) { this.proteinasGramos = proteinasGramos; }

    public BigDecimal getCarbohidratosGramos() { return carbohidratosGramos; }
    public void setCarbohidratosGramos(BigDecimal carbohidratosGramos) { this.carbohidratosGramos = carbohidratosGramos; }

    public BigDecimal getGrasasGramos() { return grasasGramos; }
    public void setGrasasGramos(BigDecimal grasasGramos) { this.grasasGramos = grasasGramos; }

    public String getPorcionDescripcion() { return porcionDescripcion; }
    public void setPorcionDescripcion(String porcionDescripcion) { this.porcionDescripcion = porcionDescripcion; }

    public String getNotasPreparacion() { return notasPreparacion; }
    public void setNotasPreparacion(String notasPreparacion) { this.notasPreparacion = notasPreparacion; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Comida comida = (Comida) o;
        return Objects.equals(id, comida.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Comida{id=" + id + ", nombre='" + nombre + "', tipo='" + tipoComida + "', calorias=" + calorias + "}";
    }
}
