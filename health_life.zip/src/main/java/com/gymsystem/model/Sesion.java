package com.gymsystem.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Sesion {

    private Long id;
    private Usuario usuario;
    private String token;
    private String ipAddress;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaExpiracion;
    private boolean activa;

    public Sesion() {
        this.fechaInicio = LocalDateTime.now();
        this.activa = true;
    }

    public Sesion(Usuario usuario, String token, LocalDateTime fechaExpiracion) {
        this();
        this.usuario = usuario;
        this.token = token;
        this.fechaExpiracion = fechaExpiracion;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public LocalDateTime getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDateTime fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDateTime getFechaExpiracion() { return fechaExpiracion; }
    public void setFechaExpiracion(LocalDateTime fechaExpiracion) { this.fechaExpiracion = fechaExpiracion; }

    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }

    public boolean isExpirada() {
        return LocalDateTime.now().isAfter(fechaExpiracion);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sesion sesion = (Sesion) o;
        return Objects.equals(id, sesion.id) || Objects.equals(token, sesion.token);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, token);
    }

    @Override
    public String toString() {
        return "Sesion{id=" + id + ", usuario=" + (usuario != null ? usuario.getUsername() : "null")
                + ", activa=" + activa + "}";
    }
}
