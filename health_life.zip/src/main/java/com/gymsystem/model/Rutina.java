package com.gymsystem.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Rutina extends BaseEntity {

    private Entrenador entrenador;
    private Cliente cliente;
    private String nombre;
    private String descripcion;
    private String objetivo;
    private int duracionSemanas;
    private int frecuenciaSemanal;
    private String nivel;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private boolean activa;
    private List<RutinaEjercicio> ejercicios;

    public Rutina() {
        this.activa = true;
        this.ejercicios = new ArrayList<>();
    }

    public Rutina(Long id) {
        super(id);
        this.ejercicios = new ArrayList<>();
    }

    public Rutina(String nombre, Entrenador entrenador) {
        this();
        this.nombre = nombre;
        this.entrenador = entrenador;
    }

    public Entrenador getEntrenador() { return entrenador; }
    public void setEntrenador(Entrenador entrenador) { this.entrenador = entrenador; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getObjetivo() { return objetivo; }
    public void setObjetivo(String objetivo) { this.objetivo = objetivo; }

    public int getDuracionSemanas() { return duracionSemanas; }
    public void setDuracionSemanas(int duracionSemanas) { this.duracionSemanas = duracionSemanas; }

    public int getFrecuenciaSemanal() { return frecuenciaSemanal; }
    public void setFrecuenciaSemanal(int frecuenciaSemanal) { this.frecuenciaSemanal = frecuenciaSemanal; }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }

    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }

    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }

    public List<RutinaEjercicio> getEjercicios() { return ejercicios; }
    public void setEjercicios(List<RutinaEjercicio> ejercicios) { this.ejercicios = ejercicios; }

    public void addEjercicio(RutinaEjercicio ejercicio) {
        this.ejercicios.add(ejercicio);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rutina rutina = (Rutina) o;
        return Objects.equals(id, rutina.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Rutina{id=" + id + ", nombre='" + nombre + "', activa=" + activa + "}";
    }
}
