package com.gymsystem.model;

import java.util.Objects;

public class Nutricionista extends BaseEntity {

    private Usuario usuario;
    private String numeroLicencia;
    private String especialidad;
    private int aniosExperiencia;
    private String horarioDisponible;

    public Nutricionista() {
    }

    public Nutricionista(Long id) {
        super(id);
    }

    public Nutricionista(Usuario usuario) {
        this.usuario = usuario;
    }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getNumeroLicencia() { return numeroLicencia; }
    public void setNumeroLicencia(String numeroLicencia) { this.numeroLicencia = numeroLicencia; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public int getAniosExperiencia() { return aniosExperiencia; }
    public void setAniosExperiencia(int aniosExperiencia) { this.aniosExperiencia = aniosExperiencia; }

    public String getHorarioDisponible() { return horarioDisponible; }
    public void setHorarioDisponible(String horarioDisponible) { this.horarioDisponible = horarioDisponible; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Nutricionista that = (Nutricionista) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Nutricionista{id=" + id + ", usuario=" + (usuario != null ? usuario.getNombreCompleto() : "null")
                + ", licencia='" + numeroLicencia + "'}";
    }
}
