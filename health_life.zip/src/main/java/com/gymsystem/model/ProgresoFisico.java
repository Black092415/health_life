package com.gymsystem.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

public class ProgresoFisico {

    private Long id;
    private Cliente cliente;
    private LocalDateTime fechaRegistro;
    private BigDecimal pesoKg;
    private BigDecimal imc;
    private BigDecimal porcentajeGrasa;
    private BigDecimal masaMuscularKg;
    private String notas;
    private String registradoPor;

    public ProgresoFisico() {
        this.fechaRegistro = LocalDateTime.now();
    }

    public ProgresoFisico(Cliente cliente, BigDecimal pesoKg) {
        this();
        this.cliente = cliente;
        this.pesoKg = pesoKg;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public BigDecimal getPesoKg() { return pesoKg; }
    public void setPesoKg(BigDecimal pesoKg) { this.pesoKg = pesoKg; }

    public BigDecimal getImc() { return imc; }
    public void setImc(BigDecimal imc) { this.imc = imc; }

    public BigDecimal getPorcentajeGrasa() { return porcentajeGrasa; }
    public void setPorcentajeGrasa(BigDecimal porcentajeGrasa) { this.porcentajeGrasa = porcentajeGrasa; }

    public BigDecimal getMasaMuscularKg() { return masaMuscularKg; }
    public void setMasaMuscularKg(BigDecimal masaMuscularKg) { this.masaMuscularKg = masaMuscularKg; }

    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }

    public String getRegistradoPor() { return registradoPor; }
    public void setRegistradoPor(String registradoPor) { this.registradoPor = registradoPor; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProgresoFisico that = (ProgresoFisico) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "ProgresoFisico{id=" + id + ", peso=" + pesoKg + "kg, imc=" + imc + "}";
    }
}
