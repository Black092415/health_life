package com.gymsystem.model;

import java.util.Objects;

public class Entrenador extends BaseEntity {

    private Usuario usuario;
    private String especialidad;
    private String certificacion;
    private int aniosExperiencia;
    private String horarioDisponible;

    public Entrenador() {
    }

    public Entrenador(Long id) {
        super(id);
    }

    public Entrenador(Usuario usuario) {
        this.usuario = usuario;
    }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getCertificacion() { return certificacion; }
    public void setCertificacion(String certificacion) { this.certificacion = certificacion; }

    public int getAniosExperiencia() { return aniosExperiencia; }
    public void setAniosExperiencia(int aniosExperiencia) { this.aniosExperiencia = aniosExperiencia; }

    public String getHorarioDisponible() { return horarioDisponible; }
    public void setHorarioDisponible(String horarioDisponible) { this.horarioDisponible = horarioDisponible; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Entrenador that = (Entrenador) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Entrenador{id=" + id + ", usuario=" + (usuario != null ? usuario.getNombreCompleto() : "null")
                + ", especialidad='" + especialidad + "'}";
    }
}
