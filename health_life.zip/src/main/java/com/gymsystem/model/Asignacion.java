package com.gymsystem.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Asignacion {

    private Long id;
    private Cliente cliente;
    private Entrenador entrenador;
    private Nutricionista nutricionista;
    private LocalDateTime fechaAsignacion;
    private LocalDateTime fechaFin;
    private boolean activa;

    public Asignacion() {
        this.fechaAsignacion = LocalDateTime.now();
        this.activa = true;
    }

    public Asignacion(Cliente cliente) {
        this();
        this.cliente = cliente;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Entrenador getEntrenador() { return entrenador; }
    public void setEntrenador(Entrenador entrenador) { this.entrenador = entrenador; }

    public Nutricionista getNutricionista() { return nutricionista; }
    public void setNutricionista(Nutricionista nutricionista) { this.nutricionista = nutricionista; }

    public LocalDateTime getFechaAsignacion() { return fechaAsignacion; }
    public void setFechaAsignacion(LocalDateTime fechaAsignacion) { this.fechaAsignacion = fechaAsignacion; }

    public LocalDateTime getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDateTime fechaFin) { this.fechaFin = fechaFin; }

    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Asignacion that = (Asignacion) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Asignacion{id=" + id + ", cliente=" + (cliente != null ? cliente.getId() : null)
                + ", activa=" + activa + "}";
    }
}
