package com.gymsystem.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PlanAlimenticio extends BaseEntity {

    private Nutricionista nutricionista;
    private Cliente cliente;
    private String nombre;
    private String descripcion;
    private BigDecimal objetivoCalorias;
    private BigDecimal objetivoProteinas;
    private BigDecimal objetivoCarbohidratos;
    private BigDecimal objetivoGrasas;
    private BigDecimal objetivoAguaLts;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private boolean activo;
    private List<Comida> comidas;

    public PlanAlimenticio() {
        this.activo = true;
        this.comidas = new ArrayList<>();
    }

    public PlanAlimenticio(Long id) {
        super(id);
        this.comidas = new ArrayList<>();
    }

    public PlanAlimenticio(String nombre, Nutricionista nutricionista) {
        this();
        this.nombre = nombre;
        this.nutricionista = nutricionista;
    }

    public Nutricionista getNutricionista() { return nutricionista; }
    public void setNutricionista(Nutricionista nutricionista) { this.nutricionista = nutricionista; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getObjetivoCalorias() { return objetivoCalorias; }
    public void setObjetivoCalorias(BigDecimal objetivoCalorias) { this.objetivoCalorias = objetivoCalorias; }

    public BigDecimal getObjetivoProteinas() { return objetivoProteinas; }
    public void setObjetivoProteinas(BigDecimal objetivoProteinas) { this.objetivoProteinas = objetivoProteinas; }

    public BigDecimal getObjetivoCarbohidratos() { return objetivoCarbohidratos; }
    public void setObjetivoCarbohidratos(BigDecimal objetivoCarbohidratos) { this.objetivoCarbohidratos = objetivoCarbohidratos; }

    public BigDecimal getObjetivoGrasas() { return objetivoGrasas; }
    public void setObjetivoGrasas(BigDecimal objetivoGrasas) { this.objetivoGrasas = objetivoGrasas; }

    public BigDecimal getObjetivoAguaLts() { return objetivoAguaLts; }
    public void setObjetivoAguaLts(BigDecimal objetivoAguaLts) { this.objetivoAguaLts = objetivoAguaLts; }

    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public List<Comida> getComidas() { return comidas; }
    public void setComidas(List<Comida> comidas) { this.comidas = comidas; }

    public void addComida(Comida comida) {
        this.comidas.add(comida);
    }

    public BigDecimal getTotalCalorias() {
        return comidas.stream()
                .map(c -> c.getCalorias() != null ? c.getCalorias() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlanAlimenticio that = (PlanAlimenticio) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "PlanAlimenticio{id=" + id + ", nombre='" + nombre + "', activo=" + activo + "}";
    }
}
