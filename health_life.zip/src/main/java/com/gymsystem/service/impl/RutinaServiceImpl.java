package com.gymsystem.service.impl;

import com.gymsystem.dao.RutinaDAO;
import com.gymsystem.dao.RutinaEjercicioDAO;
import com.gymsystem.dao.impl.RutinaDAOImpl;
import com.gymsystem.dao.impl.RutinaEjercicioDAOImpl;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.model.Rutina;
import com.gymsystem.model.RutinaEjercicio;
import com.gymsystem.service.RutinaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class RutinaServiceImpl implements RutinaService {

    private static final Logger log = LoggerFactory.getLogger(RutinaServiceImpl.class);
    private static final Logger audit = LoggerFactory.getLogger("com.gymsystem.audit");

    private final RutinaDAO rutinaDAO;
    private final RutinaEjercicioDAO rutinaEjercicioDAO;

    public RutinaServiceImpl() {
        this.rutinaDAO = new RutinaDAOImpl();
        this.rutinaEjercicioDAO = new RutinaEjercicioDAOImpl();
    }

    public RutinaServiceImpl(RutinaDAO rutinaDAO, RutinaEjercicioDAO rutinaEjercicioDAO) {
        this.rutinaDAO = rutinaDAO;
        this.rutinaEjercicioDAO = rutinaEjercicioDAO;
    }

    @Override
    public Rutina crearRutina(Rutina rutina) {
        Rutina saved = rutinaDAO.save(rutina);
        audit.info("CREAR_RUTINA | RutinaId: {} | Nombre: {} | EntrenadorId: {}",
                saved.getId(), saved.getNombre(), rutina.getEntrenador().getId());
        log.info("Rutina creada: {}", saved.getNombre());
        return saved;
    }

    @Override
    public Rutina actualizarRutina(Rutina rutina) {
        rutinaDAO.findById(rutina.getId())
                .orElseThrow(() -> new NotFoundException("Rutina", rutina.getId()));
        return rutinaDAO.update(rutina);
    }

    @Override
    public void eliminarRutina(Long id) {
        rutinaDAO.delete(id);
        audit.info("ELIMINAR_RUTINA | RutinaId: {}", id);
    }

    @Override
    public Rutina buscarPorId(Long id) {
        return rutinaDAO.findById(id)
                .orElseThrow(() -> new NotFoundException("Rutina", id));
    }

    @Override
    public Rutina buscarConEjercicios(Long id) {
        return rutinaDAO.findByIdWithEjercicios(id)
                .orElseThrow(() -> new NotFoundException("Rutina", id));
    }

    @Override
    public List<Rutina> listarPorEntrenador(Long entrenadorId) {
        return rutinaDAO.findByEntrenadorId(entrenadorId);
    }

    @Override
    public List<Rutina> listarPorCliente(Long clienteId) {
        return rutinaDAO.findByClienteId(clienteId);
    }

    @Override
    public List<Rutina> listarActivasPorCliente(Long clienteId) {
        return rutinaDAO.findActivasByClienteId(clienteId);
    }

    @Override
    public void asignarACliente(Long rutinaId, Long clienteId) {
        rutinaDAO.findById(rutinaId)
                .orElseThrow(() -> new NotFoundException("Rutina", rutinaId));
        rutinaDAO.assignToCliente(rutinaId, clienteId);
        audit.info("ASIGNAR_RUTINA | RutinaId: {} | ClienteId: {}", rutinaId, clienteId);
    }

    @Override
    public void desactivarRutina(Long id) {
        rutinaDAO.deactivate(id);
        audit.info("DESACTIVAR_RUTINA | RutinaId: {}", id);
    }

    @Override
    public RutinaEjercicio agregarEjercicio(RutinaEjercicio re) {
        RutinaEjercicio saved = rutinaEjercicioDAO.save(re);
        log.info("Ejercicio agregado a rutina {}: {}", re.getRutina().getId(), re.getEjercicio().getNombre());
        return saved;
    }

    @Override
    public void removerEjercicio(Long rutinaEjercicioId) {
        rutinaEjercicioDAO.delete(rutinaEjercicioId);
    }

    @Override
    public List<RutinaEjercicio> listarEjerciciosDeRutina(Long rutinaId) {
        return rutinaEjercicioDAO.findByRutinaId(rutinaId);
    }
}
