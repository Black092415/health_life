package com.gymsystem.service.impl;

import com.gymsystem.dao.EjercicioDAO;
import com.gymsystem.dao.impl.EjercicioDAOImpl;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.model.Ejercicio;
import com.gymsystem.service.EjercicioService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class EjercicioServiceImpl implements EjercicioService {

    private static final Logger log = LoggerFactory.getLogger(EjercicioServiceImpl.class);
    private final EjercicioDAO ejercicioDAO;

    public EjercicioServiceImpl() {
        this.ejercicioDAO = new EjercicioDAOImpl();
    }

    public EjercicioServiceImpl(EjercicioDAO ejercicioDAO) {
        this.ejercicioDAO = ejercicioDAO;
    }

    @Override
    public Ejercicio crearEjercicio(Ejercicio ejercicio) {
        Ejercicio saved = ejercicioDAO.save(ejercicio);
        log.info("Ejercicio creado: {}", saved.getNombre());
        return saved;
    }

    @Override
    public Ejercicio actualizarEjercicio(Ejercicio ejercicio) {
        ejercicioDAO.findById(ejercicio.getId())
                .orElseThrow(() -> new NotFoundException("Ejercicio", ejercicio.getId()));
        return ejercicioDAO.update(ejercicio);
    }

    @Override
    public void eliminarEjercicio(Long id) {
        ejercicioDAO.delete(id);
    }

    @Override
    public Ejercicio buscarPorId(Long id) {
        return ejercicioDAO.findById(id)
                .orElseThrow(() -> new NotFoundException("Ejercicio", id));
    }

    @Override
    public List<Ejercicio> listarTodos() {
        return ejercicioDAO.findAll();
    }

    @Override
    public List<Ejercicio> buscarPorGrupoMuscular(String grupoMuscular) {
        return ejercicioDAO.findByGrupoMuscular(grupoMuscular);
    }

    @Override
    public List<Ejercicio> buscarPorTipo(String tipo) {
        return ejercicioDAO.findByTipo(tipo);
    }

    @Override
    public List<Ejercicio> buscarPorNivel(String nivel) {
        return ejercicioDAO.findByNivelDificultad(nivel);
    }

    @Override
    public List<Ejercicio> buscarPorNombre(String termino) {
        return ejercicioDAO.searchByNombre(termino);
    }

    @Override
    public List<Ejercicio> listarActivos() {
        return ejercicioDAO.findActivos();
    }
}
