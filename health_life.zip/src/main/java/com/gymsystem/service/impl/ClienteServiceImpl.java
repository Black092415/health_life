package com.gymsystem.service.impl;

import com.gymsystem.dao.ClienteDAO;
import com.gymsystem.dao.impl.ClienteDAOImpl;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.model.Cliente;
import com.gymsystem.service.ClienteService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ClienteServiceImpl implements ClienteService {

    private static final Logger log = LoggerFactory.getLogger(ClienteServiceImpl.class);
    private final ClienteDAO clienteDAO;

    public ClienteServiceImpl() {
        this.clienteDAO = new ClienteDAOImpl();
    }

    public ClienteServiceImpl(ClienteDAO clienteDAO) {
        this.clienteDAO = clienteDAO;
    }

    @Override
    public Cliente buscarPorId(Long id) {
        return clienteDAO.findById(id)
                .orElseThrow(() -> new NotFoundException("Cliente", id));
    }

    @Override
    public Cliente buscarPorUsuarioId(Long usuarioId) {
        return clienteDAO.findByUsuarioId(usuarioId)
                .orElseThrow(() -> new NotFoundException("Cliente", "usuario_id", usuarioId.toString()));
    }

    @Override
    public List<Cliente> listarTodos() {
        return clienteDAO.findAll();
    }

    @Override
    public List<Cliente> buscarPorEntrenador(Long entrenadorId) {
        return clienteDAO.findByEntrenadorId(entrenadorId);
    }

    @Override
    public List<Cliente> buscarPorNutricionista(Long nutricionistaId) {
        return clienteDAO.findByNutricionistaId(nutricionistaId);
    }

    @Override
    public List<Cliente> buscarPorNombre(String termino) {
        return clienteDAO.searchByNombre(termino);
    }

    @Override
    public void asignarEntrenador(Long clienteId, Long entrenadorId) {
        clienteDAO.findById(clienteId)
                .orElseThrow(() -> new NotFoundException("Cliente", clienteId));
        clienteDAO.asignarEntrenador(clienteId, entrenadorId);
        log.info("Entrenador {} asignado a cliente {}", entrenadorId, clienteId);
    }

    @Override
    public void asignarNutricionista(Long clienteId, Long nutricionistaId) {
        clienteDAO.findById(clienteId)
                .orElseThrow(() -> new NotFoundException("Cliente", clienteId));
        clienteDAO.asignarNutricionista(clienteId, nutricionistaId);
        log.info("Nutricionista {} asignado a cliente {}", nutricionistaId, clienteId);
    }

    @Override
    public long contarClientes() {
        return clienteDAO.count();
    }
}
