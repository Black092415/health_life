package com.gymsystem.service.impl;

import com.gymsystem.dao.ClienteDAO;
import com.gymsystem.dao.EntrenadorDAO;
import com.gymsystem.dao.NutricionistaDAO;
import com.gymsystem.dao.RolDAO;
import com.gymsystem.dao.UsuarioDAO;
import com.gymsystem.dao.impl.ClienteDAOImpl;
import com.gymsystem.dao.impl.EntrenadorDAOImpl;
import com.gymsystem.dao.impl.NutricionistaDAOImpl;
import com.gymsystem.dao.impl.RolDAOImpl;
import com.gymsystem.dao.impl.UsuarioDAOImpl;
import com.gymsystem.dto.RegistroUsuarioDTO;
import com.gymsystem.exception.DuplicateException;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.exception.ValidationException;
import com.gymsystem.model.*;
import com.gymsystem.security.PasswordService;
import com.gymsystem.service.UsuarioService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class UsuarioServiceImpl implements UsuarioService {

    private static final Logger audit = LoggerFactory.getLogger("com.gymsystem.audit");
    private static final Logger log = LoggerFactory.getLogger(UsuarioServiceImpl.class);

    private final UsuarioDAO usuarioDAO;
    private final RolDAO rolDAO;
    private final ClienteDAO clienteDAO;
    private final EntrenadorDAO entrenadorDAO;
    private final NutricionistaDAO nutricionistaDAO;
    private final PasswordService passwordService;

    public UsuarioServiceImpl() {
        this.usuarioDAO = new UsuarioDAOImpl();
        this.rolDAO = new RolDAOImpl();
        this.clienteDAO = new ClienteDAOImpl();
        this.entrenadorDAO = new EntrenadorDAOImpl();
        this.nutricionistaDAO = new NutricionistaDAOImpl();
        this.passwordService = new PasswordService();
    }

    public UsuarioServiceImpl(UsuarioDAO usuarioDAO, RolDAO rolDAO, ClienteDAO clienteDAO,
                              EntrenadorDAO entrenadorDAO, NutricionistaDAO nutricionistaDAO,
                              PasswordService passwordService) {
        this.usuarioDAO = usuarioDAO;
        this.rolDAO = rolDAO;
        this.clienteDAO = clienteDAO;
        this.entrenadorDAO = entrenadorDAO;
        this.nutricionistaDAO = nutricionistaDAO;
        this.passwordService = passwordService;
    }

    @Override
    public Usuario registrarCliente(RegistroUsuarioDTO dto) {
        validarRegistro(dto);

        Usuario usuario = crearUsuarioBase(dto);
        usuario = usuarioDAO.save(usuario);

        Rol rolCliente = rolDAO.findByNombre("CLIENTE")
                .orElseThrow(() -> new NotFoundException("Rol CLIENTE no encontrado"));
        rolDAO.assignToUser(usuario.getId(), rolCliente.getId());
        usuario.addRol(rolCliente);

        Cliente cliente = new Cliente(usuario);
        cliente.setFechaNacimiento(dto.getFechaNacimiento());
        cliente.setGenero(dto.getGenero());
        cliente.setAltura(dto.getAltura());
        clienteDAO.save(cliente);

        audit.info("ALTA_CLIENTE | Usuario: {} | ClienteId: {}", usuario.getEmail(), cliente.getId());
        log.info("Cliente registrado exitosamente: {}", usuario.getEmail());
        return usuario;
    }

    @Override
    public Usuario registrarEntrenador(RegistroUsuarioDTO dto) {
        validarRegistro(dto);

        Usuario usuario = crearUsuarioBase(dto);
        usuario = usuarioDAO.save(usuario);

        Rol rolEntrenador = rolDAO.findByNombre("ENTRENADOR")
                .orElseThrow(() -> new NotFoundException("Rol ENTRENADOR no encontrado"));
        rolDAO.assignToUser(usuario.getId(), rolEntrenador.getId());
        usuario.addRol(rolEntrenador);

        Entrenador entrenador = new Entrenador(usuario);
        entrenador.setEspecialidad(dto.getEspecialidad());
        entrenador.setCertificacion(dto.getCertificacion());
        entrenador.setAniosExperiencia(dto.getAniosExperiencia() != null ? dto.getAniosExperiencia() : 0);
        entrenador.setHorarioDisponible(dto.getHorarioDisponible());
        entrenadorDAO.save(entrenador);

        audit.info("ALTA_ENTRENADOR | Usuario: {} | EntrenadorId: {}", usuario.getEmail(), entrenador.getId());
        log.info("Entrenador registrado exitosamente: {}", usuario.getEmail());
        return usuario;
    }

    @Override
    public Usuario registrarNutricionista(RegistroUsuarioDTO dto) {
        validarRegistro(dto);

        if (dto.getNumeroLicencia() == null || dto.getNumeroLicencia().isBlank()) {
            throw new ValidationException("El número de licencia es obligatorio para nutricionistas");
        }

        Usuario usuario = crearUsuarioBase(dto);
        usuario = usuarioDAO.save(usuario);

        Rol rolNutricionista = rolDAO.findByNombre("NUTRICIONISTA")
                .orElseThrow(() -> new NotFoundException("Rol NUTRICIONISTA no encontrado"));
        rolDAO.assignToUser(usuario.getId(), rolNutricionista.getId());
        usuario.addRol(rolNutricionista);

        Nutricionista nutricionista = new Nutricionista(usuario);
        nutricionista.setNumeroLicencia(dto.getNumeroLicencia());
        nutricionista.setEspecialidad(dto.getEspecialidad());
        nutricionista.setAniosExperiencia(dto.getAniosExperiencia() != null ? dto.getAniosExperiencia() : 0);
        nutricionista.setHorarioDisponible(dto.getHorarioDisponible());
        nutricionistaDAO.save(nutricionista);

        audit.info("ALTA_NUTRICIONISTA | Usuario: {} | NutricionistaId: {} | Licencia: {}",
                usuario.getEmail(), nutricionista.getId(), dto.getNumeroLicencia());
        log.info("Nutricionista registrado exitosamente: {}", usuario.getEmail());
        return usuario;
    }

    @Override
    public Usuario actualizarUsuario(Usuario usuario) {
        Usuario existente = usuarioDAO.findById(usuario.getId())
                .orElseThrow(() -> new NotFoundException("Usuario", usuario.getId()));
        return usuarioDAO.update(usuario);
    }

    @Override
    public Usuario buscarPorId(Long id) {
        return usuarioDAO.findByIdWithRoles(id)
                .orElseThrow(() -> new NotFoundException("Usuario", id));
    }

    @Override
    public Usuario buscarPorEmail(String email) {
        return usuarioDAO.findByEmailWithRoles(email)
                .orElseThrow(() -> new NotFoundException("Usuario", "email", email));
    }

    @Override
    public Usuario buscarPorUsername(String username) {
        return usuarioDAO.findByUsername(username)
                .orElseThrow(() -> new NotFoundException("Usuario", "username", username));
    }

    @Override
    public List<Usuario> listarTodos() {
        return usuarioDAO.findAll();
    }

    @Override
    public List<Usuario> listarPorRol(String nombreRol) {
        return usuarioDAO.findByRol(nombreRol);
    }

    @Override
    public void activar(Long id) {
        usuarioDAO.activate(id);
        audit.info("USUARIO_ACTIVADO | UsuarioId: {}", id);
    }

    @Override
    public void desactivar(Long id) {
        usuarioDAO.deactivate(id);
        audit.info("USUARIO_DESACTIVADO | UsuarioId: {}", id);
    }

    @Override
    public boolean emailExiste(String email) {
        return usuarioDAO.existsByEmail(email);
    }

    @Override
    public boolean usernameExiste(String username) {
        return usuarioDAO.existsByUsername(username);
    }

    private void validarRegistro(RegistroUsuarioDTO dto) {
        if (dto.getEmail() == null || dto.getEmail().isBlank())
            throw new ValidationException("El email es obligatorio");
        if (dto.getPassword() == null || dto.getPassword().length() < 6)
            throw new ValidationException("La contraseña debe tener al menos 6 caracteres");
        if (dto.getNombre() == null || dto.getNombre().isBlank())
            throw new ValidationException("El nombre es obligatorio");
        if (dto.getApellido() == null || dto.getApellido().isBlank())
            throw new ValidationException("El apellido es obligatorio");

        if (usuarioDAO.existsByEmail(dto.getEmail()))
            throw new DuplicateException("usuario", "email", dto.getEmail());
        if (dto.getUsername() != null && usuarioDAO.existsByUsername(dto.getUsername()))
            throw new DuplicateException("usuario", "username", dto.getUsername());
    }

    private Usuario crearUsuarioBase(RegistroUsuarioDTO dto) {
        Usuario usuario = new Usuario();
        usuario.setUsername(dto.getUsername() != null ? dto.getUsername() : dto.getEmail());
        usuario.setEmail(dto.getEmail());
        usuario.setPasswordHash(passwordService.hashPassword(dto.getPassword()));
        usuario.setNombre(dto.getNombre());
        usuario.setApellido(dto.getApellido());
        usuario.setTelefono(dto.getTelefono());
        return usuario;
    }
}
