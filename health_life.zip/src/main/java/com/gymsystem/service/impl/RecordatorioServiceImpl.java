package com.gymsystem.service.impl;

import com.gymsystem.dao.RecordatorioDAO;
import com.gymsystem.dao.impl.RecordatorioDAOImpl;
import com.gymsystem.model.Recordatorio;
import com.gymsystem.service.RecordatorioService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;

public class RecordatorioServiceImpl implements RecordatorioService {

    private static final Logger log = LoggerFactory.getLogger(RecordatorioServiceImpl.class);
    private final RecordatorioDAO recordatorioDAO;

    public RecordatorioServiceImpl() {
        this.recordatorioDAO = new RecordatorioDAOImpl();
    }

    public RecordatorioServiceImpl(RecordatorioDAO recordatorioDAO) {
        this.recordatorioDAO = recordatorioDAO;
    }

    @Override
    public Recordatorio crearRecordatorio(Recordatorio recordatorio) {
        Recordatorio saved = recordatorioDAO.save(recordatorio);
        log.info("Recordatorio creado: {} para cliente {}", saved.getTitulo(), recordatorio.getCliente().getId());
        return saved;
    }

    @Override
    public void marcarCompletado(Long id) {
        recordatorioDAO.marcarCompletado(id);
        log.info("Recordatorio {} marcado como completado", id);
    }

    @Override
    public void eliminarRecordatorio(Long id) {
        recordatorioDAO.delete(id);
    }

    @Override
    public List<Recordatorio> listarPorCliente(Long clienteId) {
        return recordatorioDAO.findByClienteId(clienteId);
    }

    @Override
    public List<Recordatorio> listarPendientes(Long clienteId) {
        return recordatorioDAO.findPendientesByClienteId(clienteId);
    }

    @Override
    public List<Recordatorio> listarPorRangoFechas(LocalDateTime desde, LocalDateTime hasta) {
        return recordatorioDAO.findByDateRange(desde, hasta);
    }

    @Override
    public List<Recordatorio> listarPorTipo(String tipo) {
        return recordatorioDAO.findByTipo(tipo);
    }

    @Override
    public long contarPendientes(Long clienteId) {
        return recordatorioDAO.countPendientesByClienteId(clienteId);
    }
}
