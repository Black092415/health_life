package com.gymsystem.service.impl;

import com.gymsystem.dao.ClienteDAO;
import com.gymsystem.dao.MedidasCorporalesDAO;
import com.gymsystem.dao.ProgresoFisicoDAO;
import com.gymsystem.dao.impl.ClienteDAOImpl;
import com.gymsystem.dao.impl.MedidasCorporalesDAOImpl;
import com.gymsystem.dao.impl.ProgresoFisicoDAOImpl;
import com.gymsystem.dto.*;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.exception.ValidationException;
import com.gymsystem.model.Cliente;
import com.gymsystem.model.MedidasCorporales;
import com.gymsystem.model.ProgresoFisico;
import com.gymsystem.service.ProgresoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class ProgresoServiceImpl implements ProgresoService {

    private static final Logger log = LoggerFactory.getLogger(ProgresoServiceImpl.class);
    private static final Logger audit = LoggerFactory.getLogger("com.gymsystem.audit");

    private final ProgresoFisicoDAO progresoDAO;
    private final MedidasCorporalesDAO medidasDAO;
    private final ClienteDAO clienteDAO;

    public ProgresoServiceImpl() {
        this.progresoDAO = new ProgresoFisicoDAOImpl();
        this.medidasDAO = new MedidasCorporalesDAOImpl();
        this.clienteDAO = new ClienteDAOImpl();
    }

    public ProgresoServiceImpl(ProgresoFisicoDAO progresoDAO, MedidasCorporalesDAO medidasDAO, ClienteDAO clienteDAO) {
        this.progresoDAO = progresoDAO;
        this.medidasDAO = medidasDAO;
        this.clienteDAO = clienteDAO;
    }

    @Override
    public ProgresoFisico registrarPeso(ProgresoFisico progreso) {
        if (progreso.getPesoKg() == null || progreso.getPesoKg().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException("El peso debe ser un valor positivo");
        }
        Cliente cliente = clienteDAO.findById(progreso.getCliente().getId())
                .orElseThrow(() -> new NotFoundException("Cliente", progreso.getCliente().getId()));

        progreso.setCliente(cliente);
        ProgresoFisico saved = progresoDAO.save(progreso);

        String clasif = clasificarIMC(saved.getImc());
        audit.info("REGISTRO_PESO | ClienteId: {} | Peso: {}kg | IMC: {} | Clasificación: {}",
                cliente.getId(), saved.getPesoKg(), saved.getImc(), clasif);
        log.info("Peso registrado para cliente {}: {} kg", cliente.getId(), saved.getPesoKg());
        return saved;
    }

    @Override
    public MedidasCorporales registrarMedidas(MedidasCorporales medidas) {
        Cliente cliente = clienteDAO.findById(medidas.getCliente().getId())
                .orElseThrow(() -> new NotFoundException("Cliente", medidas.getCliente().getId()));
        medidas.setCliente(cliente);
        MedidasCorporales saved = medidasDAO.save(medidas);
        audit.info("REGISTRO_MEDIDAS | ClienteId: {} | Cintura: {}cm | Cadera: {}cm",
                cliente.getId(), saved.getCinturaCm(), saved.getCaderaCm());
        return saved;
    }

    @Override
    public List<ProgresoFisico> historialPeso(Long clienteId) {
        return progresoDAO.findByClienteId(clienteId);
    }

    @Override
    public List<MedidasCorporales> historialMedidas(Long clienteId) {
        return medidasDAO.findByClienteId(clienteId);
    }

    @Override
    public ProgresoResponseDTO obtenerUltimoProgreso(Long clienteId) {
        ProgresoFisico ultimo = progresoDAO.findLastByClienteId(clienteId)
                .orElseThrow(() -> new NotFoundException("Progreso", "cliente_id", clienteId.toString()));
        ProgresoFisico primero = progresoDAO.findFirstByClienteId(clienteId).orElse(null);
        ProgresoFisico anterior = findAnterior(clienteId, ultimo.getFechaRegistro());

        ProgresoResponseDTO dto = new ProgresoResponseDTO();
        dto.setId(ultimo.getId());
        dto.setClienteId(clienteId);
        dto.setFechaRegistro(ultimo.getFechaRegistro());
        dto.setPesoKg(ultimo.getPesoKg());
        dto.setImc(ultimo.getImc());
        dto.setPorcentajeGrasa(ultimo.getPorcentajeGrasa());
        dto.setMasaMuscularKg(ultimo.getMasaMuscularKg());

        if (primero != null) dto.setPesoInicial(primero.getPesoKg());
        if (anterior != null) dto.setPesoAnterior(anterior.getPesoKg());

        if (dto.getPesoAnterior() != null) {
            dto.setVariacionPeso(ultimo.getPesoKg().subtract(dto.getPesoAnterior()));
            if (dto.getPesoAnterior().compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal variacion = ultimo.getPesoKg().subtract(dto.getPesoAnterior())
                        .multiply(BigDecimal.valueOf(100))
                        .divide(dto.getPesoAnterior(), 2, RoundingMode.HALF_UP);
                dto.setVariacionPorcentual(variacion);
            }
        }

        return dto;
    }

    @Override
    public EstadisticaDTO generarEstadisticas(Long clienteId) {
        List<ProgresoFisico> registros = progresoDAO.findByClienteId(clienteId);
        if (registros.isEmpty()) {
            throw new NotFoundException("No hay registros de progreso para el cliente " + clienteId);
        }

        Cliente cliente = clienteDAO.findById(clienteId)
                .orElseThrow(() -> new NotFoundException("Cliente", clienteId));

        EstadisticaDTO stats = new EstadisticaDTO();
        stats.setClienteId(clienteId);
        stats.setClienteNombre(cliente.getUsuario().getNombreCompleto());

        ProgresoFisico primero = registros.get(registros.size() - 1);
        ProgresoFisico ultimo = registros.get(0);

        stats.setPesoActual(ultimo.getPesoKg());
        stats.setPesoInicial(primero.getPesoKg());
        stats.setImcActual(ultimo.getImc());
        stats.setImcInicial(primero.getImc());

        if (primero.getPesoKg() != null && primero.getPesoKg().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal variacion = ultimo.getPesoKg().subtract(primero.getPesoKg());
            stats.setVariacionPeso(variacion);
            BigDecimal variacionPorc = variacion.multiply(BigDecimal.valueOf(100))
                    .divide(primero.getPesoKg(), 2, RoundingMode.HALF_UP);
            stats.setVariacionPorcentual(variacionPorc);
        }

        BigDecimal suma = registros.stream()
                .map(ProgresoFisico::getPesoKg)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        stats.setPesoPromedio(suma.divide(BigDecimal.valueOf(registros.size()), 2, RoundingMode.HALF_UP));

        stats.setPesoMinimo(registros.stream()
                .map(ProgresoFisico::getPesoKg)
                .min(BigDecimal::compareTo).orElse(BigDecimal.ZERO));
        stats.setPesoMaximo(registros.stream()
                .map(ProgresoFisico::getPesoKg)
                .max(BigDecimal::compareTo).orElse(BigDecimal.ZERO));

        stats.setTotalRegistros(registros.size());
        stats.setTotalMedidas(medidasDAO.findByClienteId(clienteId).size());

        if (primero.getFechaRegistro() != null) {
            stats.setDiasDesdePrimerRegistro((int) ChronoUnit.DAYS.between(
                    primero.getFechaRegistro(), LocalDateTime.now()));
        }

        if (ultimo.getImc() != null) {
            stats.setClasificacionIMC(clasificarIMC(ultimo.getImc()));
        }

        stats.setEvolucionMensual(calcularEvolucionMensual(registros));

        return stats;
    }

    @Override
    public HistorialResponseDTO generarHistorialCompleto(Long clienteId) {
        Cliente cliente = clienteDAO.findById(clienteId)
                .orElseThrow(() -> new NotFoundException("Cliente", clienteId));

        HistorialResponseDTO historial = new HistorialResponseDTO();
        historial.setClienteId(clienteId);
        historial.setClienteNombre(cliente.getUsuario().getNombreCompleto());

        List<ProgresoFisico> progresos = progresoDAO.findByClienteId(clienteId);
        List<ProgresoResponseDTO> progresoDTOs = progresos.stream().map(p -> {
            ProgresoResponseDTO dto = new ProgresoResponseDTO();
            dto.setId(p.getId());
            dto.setClienteId(clienteId);
            dto.setFechaRegistro(p.getFechaRegistro());
            dto.setPesoKg(p.getPesoKg());
            dto.setImc(p.getImc());
            dto.setPorcentajeGrasa(p.getPorcentajeGrasa());
            dto.setMasaMuscularKg(p.getMasaMuscularKg());
            return dto;
        }).collect(Collectors.toList());
        historial.setProgreso(progresoDTOs);

        List<MedidasCorporales> medidasList = medidasDAO.findByClienteId(clienteId);
        List<MedidasResponseDTO> medidasDTOs = medidasList.stream().map(m -> {
            MedidasResponseDTO dto = new MedidasResponseDTO();
            dto.setId(m.getId());
            dto.setClienteId(clienteId);
            dto.setFechaRegistro(m.getFechaRegistro());
            dto.setCinturaCm(m.getCinturaCm());
            dto.setCaderaCm(m.getCaderaCm());
            dto.setPechoCm(m.getPechoCm());
            dto.setBrazoIzqCm(m.getBrazoIzqCm());
            dto.setBrazoDerCm(m.getBrazoDerCm());
            dto.setPiernaIzqCm(m.getPiernaIzqCm());
            dto.setPiernaDerCm(m.getPiernaDerCm());
            dto.setCinturaCaderaRatio(m.getCinturaCaderaRatio());
            dto.setRegistradoPor(m.getRegistradoPor());
            return dto;
        }).collect(Collectors.toList());
        historial.setMedidas(medidasDTOs);

        historial.setEstadisticas(generarEstadisticas(clienteId));

        return historial;
    }

    @Override
    public List<ProgresoResponseDTO> obtenerEvolucion(Long clienteId, int semanas) {
        List<ProgresoFisico> registros = progresoDAO.findLastWeekly(clienteId, semanas);
        return registros.stream().map(p -> {
            ProgresoResponseDTO dto = new ProgresoResponseDTO();
            dto.setId(p.getId());
            dto.setClienteId(clienteId);
            dto.setFechaRegistro(p.getFechaRegistro());
            dto.setPesoKg(p.getPesoKg());
            dto.setImc(p.getImc());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public double calcularIMC(double pesoKg, double alturaMts) {
        if (alturaMts <= 0) throw new ValidationException("La altura debe ser mayor a 0");
        return Math.round((pesoKg / (alturaMts * alturaMts)) * 100.0) / 100.0;
    }

    private ProgresoFisico findAnterior(Long clienteId, LocalDateTime fechaActual) {
        List<ProgresoFisico> todos = progresoDAO.findByClienteId(clienteId);
        for (int i = 0; i < todos.size(); i++) {
            if (todos.get(i).getFechaRegistro().equals(fechaActual) && i + 1 < todos.size()) {
                return todos.get(i + 1);
            }
        }
        return null;
    }

    private String clasificarIMC(BigDecimal imc) {
        if (imc == null) return "Desconocido";
        double valor = imc.doubleValue();
        if (valor < 16.0) return "Infrapeso severo";
        if (valor < 17.0) return "Infrapeso moderado";
        if (valor < 18.5) return "Infrapeso";
        if (valor < 25.0) return "Normal";
        if (valor < 30.0) return "Sobrepeso";
        if (valor < 35.0) return "Obesidad tipo I";
        if (valor < 40.0) return "Obesidad tipo II";
        return "Obesidad tipo III";
    }

    private Map<String, BigDecimal> calcularEvolucionMensual(List<ProgresoFisico> registros) {
        Map<String, BigDecimal> evolucion = new TreeMap<>();
        Map<String, List<BigDecimal>> agrupado = new HashMap<>();

        for (ProgresoFisico p : registros) {
            String mes = p.getFechaRegistro().getYear() + "-"
                    + String.format("%02d", p.getFechaRegistro().getMonthValue());
            agrupado.computeIfAbsent(mes, k -> new ArrayList<>()).add(p.getPesoKg());
        }

        for (Map.Entry<String, List<BigDecimal>> entry : agrupado.entrySet()) {
            BigDecimal promedio = entry.getValue().stream()
                    .reduce(BigDecimal.ZERO, BigDecimal::add)
                    .divide(BigDecimal.valueOf(entry.getValue().size()), 2, RoundingMode.HALF_UP);
            evolucion.put(entry.getKey(), promedio);
        }

        return evolucion;
    }
}
