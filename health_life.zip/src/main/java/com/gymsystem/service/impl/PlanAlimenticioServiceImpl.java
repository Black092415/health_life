package com.gymsystem.service.impl;

import com.gymsystem.dao.ComidaDAO;
import com.gymsystem.dao.PlanAlimenticioDAO;
import com.gymsystem.dao.impl.ComidaDAOImpl;
import com.gymsystem.dao.impl.PlanAlimenticioDAOImpl;
import com.gymsystem.exception.NotFoundException;
import com.gymsystem.model.Comida;
import com.gymsystem.model.PlanAlimenticio;
import com.gymsystem.service.PlanAlimenticioService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class PlanAlimenticioServiceImpl implements PlanAlimenticioService {

    private static final Logger log = LoggerFactory.getLogger(PlanAlimenticioServiceImpl.class);
    private static final Logger audit = LoggerFactory.getLogger("com.gymsystem.audit");

    private final PlanAlimenticioDAO planDAO;
    private final ComidaDAO comidaDAO;

    public PlanAlimenticioServiceImpl() {
        this.planDAO = new PlanAlimenticioDAOImpl();
        this.comidaDAO = new ComidaDAOImpl();
    }

    public PlanAlimenticioServiceImpl(PlanAlimenticioDAO planDAO, ComidaDAO comidaDAO) {
        this.planDAO = planDAO;
        this.comidaDAO = comidaDAO;
    }

    @Override
    public PlanAlimenticio crearPlan(PlanAlimenticio plan) {
        PlanAlimenticio saved = planDAO.save(plan);
        audit.info("CREAR_PLAN_ALIMENTICIO | PlanId: {} | NutricionistaId: {}",
                saved.getId(), plan.getNutricionista().getId());
        log.info("Plan alimenticio creado: {}", saved.getNombre());
        return saved;
    }

    @Override
    public PlanAlimenticio actualizarPlan(PlanAlimenticio plan) {
        planDAO.findById(plan.getId())
                .orElseThrow(() -> new NotFoundException("Plan alimenticio", plan.getId()));
        return planDAO.update(plan);
    }

    @Override
    public void eliminarPlan(Long id) {
        planDAO.delete(id);
    }

    @Override
    public PlanAlimenticio buscarPorId(Long id) {
        return planDAO.findById(id)
                .orElseThrow(() -> new NotFoundException("Plan alimenticio", id));
    }

    @Override
    public PlanAlimenticio buscarConComidas(Long id) {
        return planDAO.findByIdWithComidas(id)
                .orElseThrow(() -> new NotFoundException("Plan alimenticio", id));
    }

    @Override
    public List<PlanAlimenticio> listarPorNutricionista(Long nutricionistaId) {
        return planDAO.findByNutricionistaId(nutricionistaId);
    }

    @Override
    public List<PlanAlimenticio> listarPorCliente(Long clienteId) {
        return planDAO.findByClienteId(clienteId);
    }

    @Override
    public PlanAlimenticio buscarActivoPorCliente(Long clienteId) {
        return planDAO.findActivoByClienteId(clienteId)
                .orElseThrow(() -> new NotFoundException("No hay plan activo para el cliente " + clienteId));
    }

    @Override
    public void desactivarPlan(Long id) {
        planDAO.deactivate(id);
        audit.info("DESACTIVAR_PLAN | PlanId: {}", id);
    }

    @Override
    public Comida agregarComida(Comida comida) {
        return comidaDAO.save(comida);
    }

    @Override
    public void removerComida(Long comidaId) {
        comidaDAO.delete(comidaId);
    }

    @Override
    public List<Comida> listarComidasDePlan(Long planId) {
        return comidaDAO.findByPlanAlimenticioId(planId);
    }
}
