package com.gymsystem.service;

import com.gymsystem.model.Rutina;
import com.gymsystem.model.RutinaEjercicio;

import java.util.List;

public interface RutinaService {

    Rutina crearRutina(Rutina rutina);

    Rutina actualizarRutina(Rutina rutina);

    void eliminarRutina(Long id);

    Rutina buscarPorId(Long id);

    Rutina buscarConEjercicios(Long id);

    List<Rutina> listarPorEntrenador(Long entrenadorId);

    List<Rutina> listarPorCliente(Long clienteId);

    List<Rutina> listarActivasPorCliente(Long clienteId);

    void asignarACliente(Long rutinaId, Long clienteId);

    void desactivarRutina(Long id);

    RutinaEjercicio agregarEjercicio(RutinaEjercicio re);

    void removerEjercicio(Long rutinaEjercicioId);

    List<RutinaEjercicio> listarEjerciciosDeRutina(Long rutinaId);
}
