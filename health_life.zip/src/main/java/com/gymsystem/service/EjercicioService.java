package com.gymsystem.service;

import com.gymsystem.model.Ejercicio;

import java.util.List;

public interface EjercicioService {

    Ejercicio crearEjercicio(Ejercicio ejercicio);

    Ejercicio actualizarEjercicio(Ejercicio ejercicio);

    void eliminarEjercicio(Long id);

    Ejercicio buscarPorId(Long id);

    List<Ejercicio> listarTodos();

    List<Ejercicio> buscarPorGrupoMuscular(String grupoMuscular);

    List<Ejercicio> buscarPorTipo(String tipo);

    List<Ejercicio> buscarPorNivel(String nivel);

    List<Ejercicio> buscarPorNombre(String termino);

    List<Ejercicio> listarActivos();
}
