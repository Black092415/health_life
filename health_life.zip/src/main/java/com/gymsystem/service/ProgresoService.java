package com.gymsystem.service;

import com.gymsystem.dto.EstadisticaDTO;
import com.gymsystem.dto.HistorialResponseDTO;
import com.gymsystem.dto.ProgresoResponseDTO;
import com.gymsystem.model.MedidasCorporales;
import com.gymsystem.model.ProgresoFisico;

import java.util.List;

public interface ProgresoService {

    ProgresoFisico registrarPeso(ProgresoFisico progreso);

    MedidasCorporales registrarMedidas(MedidasCorporales medidas);

    List<ProgresoFisico> historialPeso(Long clienteId);

    List<MedidasCorporales> historialMedidas(Long clienteId);

    ProgresoResponseDTO obtenerUltimoProgreso(Long clienteId);

    EstadisticaDTO generarEstadisticas(Long clienteId);

    HistorialResponseDTO generarHistorialCompleto(Long clienteId);

    List<ProgresoResponseDTO> obtenerEvolucion(Long clienteId, int semanas);

    double calcularIMC(double pesoKg, double alturaMts);
}
