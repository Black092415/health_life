package com.gymsystem.service;

import com.gymsystem.dto.RegistroUsuarioDTO;
import com.gymsystem.model.Cliente;
import com.gymsystem.model.Entrenador;
import com.gymsystem.model.Nutricionista;
import com.gymsystem.model.Usuario;

import java.util.List;

public interface UsuarioService {

    Usuario registrarCliente(RegistroUsuarioDTO dto);

    Usuario registrarEntrenador(RegistroUsuarioDTO dto);

    Usuario registrarNutricionista(RegistroUsuarioDTO dto);

    Usuario actualizarUsuario(Usuario usuario);

    Usuario buscarPorId(Long id);

    Usuario buscarPorEmail(String email);

    Usuario buscarPorUsername(String username);

    List<Usuario> listarTodos();

    List<Usuario> listarPorRol(String nombreRol);

    void activar(Long id);

    void desactivar(Long id);

    boolean emailExiste(String email);

    boolean usernameExiste(String username);
}
