package com.gymsystem.service;

import com.gymsystem.model.Recordatorio;

import java.time.LocalDateTime;
import java.util.List;

public interface RecordatorioService {

    Recordatorio crearRecordatorio(Recordatorio recordatorio);

    void marcarCompletado(Long id);

    void eliminarRecordatorio(Long id);

    List<Recordatorio> listarPorCliente(Long clienteId);

    List<Recordatorio> listarPendientes(Long clienteId);

    List<Recordatorio> listarPorRangoFechas(LocalDateTime desde, LocalDateTime hasta);

    List<Recordatorio> listarPorTipo(String tipo);

    long contarPendientes(Long clienteId);
}
