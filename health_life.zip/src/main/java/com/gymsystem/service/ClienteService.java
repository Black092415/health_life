package com.gymsystem.service;

import com.gymsystem.model.Cliente;

import java.util.List;

public interface ClienteService {

    Cliente buscarPorId(Long id);

    Cliente buscarPorUsuarioId(Long usuarioId);

    List<Cliente> listarTodos();

    List<Cliente> buscarPorEntrenador(Long entrenadorId);

    List<Cliente> buscarPorNutricionista(Long nutricionistaId);

    List<Cliente> buscarPorNombre(String termino);

    void asignarEntrenador(Long clienteId, Long entrenadorId);

    void asignarNutricionista(Long clienteId, Long nutricionistaId);

    long contarClientes();
}
