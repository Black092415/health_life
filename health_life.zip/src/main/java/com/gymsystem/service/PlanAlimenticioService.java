package com.gymsystem.service;

import com.gymsystem.model.Comida;
import com.gymsystem.model.PlanAlimenticio;

import java.util.List;

public interface PlanAlimenticioService {

    PlanAlimenticio crearPlan(PlanAlimenticio plan);

    PlanAlimenticio actualizarPlan(PlanAlimenticio plan);

    void eliminarPlan(Long id);

    PlanAlimenticio buscarPorId(Long id);

    PlanAlimenticio buscarConComidas(Long id);

    List<PlanAlimenticio> listarPorNutricionista(Long nutricionistaId);

    List<PlanAlimenticio> listarPorCliente(Long clienteId);

    PlanAlimenticio buscarActivoPorCliente(Long clienteId);

    void desactivarPlan(Long id);

    Comida agregarComida(Comida comida);

    void removerComida(Long comidaId);

    List<Comida> listarComidasDePlan(Long planId);
}
