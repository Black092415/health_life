package com.gymsystem.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Savepoint;

public final class DatabaseManager {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseManager.class);

    private DatabaseManager() {
    }

    public static void beginTransaction(Connection connection) throws SQLException {
        if (connection != null) {
            connection.setAutoCommit(false);
            logger.debug("Transacción iniciada");
        }
    }

    public static void commitTransaction(Connection connection) throws SQLException {
        if (connection != null) {
            connection.commit();
            connection.setAutoCommit(true);
            logger.debug("Transacción confirmada (commit)");
        }
    }

    public static void rollbackTransaction(Connection connection) throws SQLException {
        if (connection != null) {
            connection.rollback();
            connection.setAutoCommit(true);
            logger.warn("Transacción revertida (rollback)");
        }
    }

    public static Savepoint createSavepoint(Connection connection, String name) throws SQLException {
        if (connection != null) {
            Savepoint savepoint = connection.setSavepoint(name);
            logger.debug("Savepoint '{}' creado", name);
            return savepoint;
        }
        return null;
    }

    public static void rollbackToSavepoint(Connection connection, Savepoint savepoint) throws SQLException {
        if (connection != null && savepoint != null) {
            connection.rollback(savepoint);
            logger.debug("Rollback a savepoint '{}'", savepoint.getSavepointName());
        }
    }

    public static void executeInTransaction(TransactionCallback callback) {
        Connection connection = null;
        try {
            connection = DatabaseConnection.getConnection();
            beginTransaction(connection);
            callback.execute(connection);
            commitTransaction(connection);
        } catch (Exception e) {
            try {
                if (connection != null) {
                    rollbackTransaction(connection);
                }
            } catch (SQLException ex) {
                logger.error("Error al hacer rollback", ex);
            }
            throw new RuntimeException("Error en transacción: " + e.getMessage(), e);
        } finally {
            DatabaseConnection.closeConnection(connection);
        }
    }

    @FunctionalInterface
    public interface TransactionCallback {
        void execute(Connection connection) throws Exception;
    }
}
