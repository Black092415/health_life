package com.gymsystem.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public final class DatabaseConnection {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseConnection.class);
    private static final String PROPERTIES_FILE = "database.properties";
    private static HikariDataSource dataSource;

    static {
        initializeDataSource();
    }

    private DatabaseConnection() {
    }

    private static void initializeDataSource() {
        Properties props = new Properties();
        try (InputStream input = DatabaseConnection.class.getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {

            if (input == null) {
                logger.error("No se encontró el archivo {}", PROPERTIES_FILE);
                throw new RuntimeException("Archivo " + PROPERTIES_FILE + " no encontrado");
            }

            props.load(input);
            logger.info("Configuración de base de datos cargada desde {}", PROPERTIES_FILE);

            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(props.getProperty("db.url"));
            config.setUsername(props.getProperty("db.username"));
            config.setPassword(props.getProperty("db.password"));
            config.setSchema(props.getProperty("db.schema"));

            config.setMaximumPoolSize(Integer.parseInt(props.getProperty("pool.maximumPoolSize", "10")));
            config.setMinimumIdle(Integer.parseInt(props.getProperty("pool.minimumIdle", "2")));
            config.setConnectionTimeout(Long.parseLong(props.getProperty("pool.connectionTimeout", "30000")));
            config.setIdleTimeout(Long.parseLong(props.getProperty("pool.idleTimeout", "600000")));
            config.setMaxLifetime(Long.parseLong(props.getProperty("pool.maxLifetime", "1800000")));
            config.setLeakDetectionThreshold(Long.parseLong(props.getProperty("pool.leakDetectionThreshold", "60000")));
            config.setPoolName(props.getProperty("pool.poolName", "GymSystemPool"));

            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            config.addDataSourceProperty("useServerPrepStmts", "true");

            dataSource = new HikariDataSource(config);
            logger.info("HikariCP pool '{}' inicializado con {} conexiones máximas",
                    config.getPoolName(), config.getMaximumPoolSize());

        } catch (IOException e) {
            logger.error("Error al cargar configuración de BD", e);
            throw new RuntimeException("Error al cargar configuración de base de datos", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        if (dataSource == null || dataSource.isClosed()) {
            logger.warn("DataSource cerrado o nulo, reinicializando...");
            initializeDataSource();
        }
        Connection connection = dataSource.getConnection();
        logger.debug("Conexión obtenida del pool: {}", connection.hashCode());
        return connection;
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                logger.debug("Conexión devuelta al pool");
            } catch (SQLException e) {
                logger.error("Error al cerrar conexión", e);
            }
        }
    }

    public static void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            logger.info("Pool de conexiones cerrado correctamente");
        }
    }

    public static boolean isPoolRunning() {
        return dataSource != null && !dataSource.isClosed();
    }

    public static int getActiveConnections() {
        return dataSource != null ? dataSource.getHikariPoolMXBean().getActiveConnections() : 0;
    }

    public static int getIdleConnections() {
        return dataSource != null ? dataSource.getHikariPoolMXBean().getIdleConnections() : 0;
    }
}
