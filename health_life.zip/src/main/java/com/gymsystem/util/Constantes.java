package com.gymsystem.util;

public final class Constantes {

    private Constantes() {}

    // Roles
    public static final String ROL_ADMIN = "ADMIN";
    public static final String ROL_ENTRENADOR = "ENTRENADOR";
    public static final String ROL_NUTRICIONISTA = "NUTRICIONISTA";
    public static final String ROL_CLIENTE = "CLIENTE";

    // Tipos de ejercicio
    public static final String TIPO_FUERZA = "fuerza";
    public static final String TIPO_CARDIO = "cardio";
    public static final String TIPO_FLEXIBILIDAD = "flexibilidad";
    public static final String TIPO_HIIT = "hiit";

    // Niveles de dificultad
    public static final String NIVEL_PRINCIPIANTE = "principiante";
    public static final String NIVEL_INTERMEDIO = "intermedio";
    public static final String NIVEL_AVANZADO = "avanzado";

    // Tipos de comida
    public static final String COMIDA_DESAYUNO = "desayuno";
    public static final String COMIDA_MEDIA_MANANA = "media_manana";
    public static final String COMIDA_ALMUERZO = "almuerzo";
    public static final String COMIDA_MERIENDA = "merienda";
    public static final String COMIDA_CENA = "cena";

    // Tipos de recordatorio
    public static final String RECORDATORIO_ENTRENAMIENTO = "entrenamiento";
    public static final String RECORDATORIO_CITA = "cita_nutricion";
    public static final String RECORDATORIO_PESAJE = "pesaje";
    public static final String RECORDATORIO_MEDICION = "medicion";
    public static final String RECORDATORIO_GENERAL = "general";

    // Recurrencia
    public static final String RECURRENCIA_UNICO = "unico";
    public static final String RECURRENCIA_DIARIO = "diario";
    public static final String RECURRENCIA_SEMANAL = "semanal";

    // Género
    public static final String GENERO_MASCULINO = "M";
    public static final String GENERO_FEMENINO = "F";
    public static final String GENERO_OTRO = "O";

    // Sesión
    public static final int SESION_DURACION_HORAS = 24;
    public static final int BCrypt_COST = 10;
}
