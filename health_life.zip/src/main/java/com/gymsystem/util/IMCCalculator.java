package com.gymsystem.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class IMCCalculator {

    private IMCCalculator() {}

    public static BigDecimal calcular(BigDecimal pesoKg, BigDecimal alturaMts) {
        if (pesoKg == null || alturaMts == null) return null;
        if (alturaMts.compareTo(BigDecimal.ZERO) <= 0 ||
                pesoKg.compareTo(BigDecimal.ZERO) <= 0) return null;

        return pesoKg.divide(alturaMts.multiply(alturaMts), 2, RoundingMode.HALF_UP);
    }

    public static String clasificar(BigDecimal imc) {
        if (imc == null) return "Desconocido";
        double valor = imc.doubleValue();
        if (valor < 16.0) return "Infrapeso severo";
        if (valor < 17.0) return "Infrapeso moderado";
        if (valor < 18.5) return "Infrapeso";
        if (valor < 25.0) return "Peso normal";
        if (valor < 30.0) return "Sobrepeso";
        if (valor < 35.0) return "Obesidad tipo I";
        if (valor < 40.0) return "Obesidad tipo II";
        return "Obesidad tipo III";
    }

    public static double calcular(double pesoKg, double alturaMts) {
        if (alturaMts <= 0) throw new IllegalArgumentException("Altura debe ser > 0");
        return Math.round((pesoKg / (alturaMts * alturaMts)) * 100.0) / 100.0;
    }
}
