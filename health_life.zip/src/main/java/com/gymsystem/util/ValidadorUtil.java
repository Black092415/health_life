package com.gymsystem.util;

import com.gymsystem.exception.ValidationException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class ValidadorUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern TELEFONO_PATTERN =
            Pattern.compile("^\\+?[0-9]{7,15}$");

    private ValidadorUtil() {}

    public static void validarEmail(String email) {
        if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
            throw new ValidationException("Formato de email inválido: " + email);
        }
    }

    public static void validarTelefono(String telefono) {
        if (telefono != null && !telefono.isBlank() && !TELEFONO_PATTERN.matcher(telefono).matches()) {
            throw new ValidationException("Formato de teléfono inválido: " + telefono);
        }
    }

    public static void validarNoNulo(Object valor, String nombre) {
        if (valor == null) {
            throw new ValidationException(nombre + " no puede ser nulo");
        }
    }

    public static void validarNoVacio(String valor, String nombre) {
        if (valor == null || valor.isBlank()) {
            throw new ValidationException(nombre + " no puede estar vacío");
        }
    }

    public static void validarPositivo(BigDecimal valor, String nombre) {
        if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException(nombre + " debe ser un valor positivo");
        }
    }

    public static void validarEntre(BigDecimal valor, String nombre, BigDecimal min, BigDecimal max) {
        if (valor == null) return;
        if (valor.compareTo(min) < 0 || valor.compareTo(max) > 0) {
            throw new ValidationException(nombre + " debe estar entre " + min + " y " + max);
        }
    }

    public static List<String> validarTodo(Object... pares) {
        List<String> errores = new ArrayList<>();
        for (int i = 0; i < pares.length; i += 2) {
            String nombre = (String) pares[i];
            Object valor = pares[i + 1];
            if (valor instanceof String && ((String) valor).isBlank()) {
                errores.add(nombre + " no puede estar vacío");
            } else if (valor == null) {
                errores.add(nombre + " no puede ser nulo");
            }
        }
        return errores;
    }
}
