package com.gymsystem.validator;

import com.gymsystem.dto.RegistroUsuarioDTO;
import com.gymsystem.exception.ValidationException;
import com.gymsystem.util.ValidadorUtil;

import java.util.ArrayList;
import java.util.List;

public class UsuarioValidator {

    public void validarRegistro(RegistroUsuarioDTO dto) {
        List<String> errores = new ArrayList<>();

        if (dto.getEmail() == null || dto.getEmail().isBlank()) {
            errores.add("El email es obligatorio");
        } else if (!dto.getEmail().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            errores.add("Formato de email inválido");
        }

        if (dto.getPassword() == null || dto.getPassword().length() < 6) {
            errores.add("La contraseña debe tener al menos 6 caracteres");
        }

        if (dto.getNombre() == null || dto.getNombre().isBlank()) {
            errores.add("El nombre es obligatorio");
        }

        if (dto.getApellido() == null || dto.getApellido().isBlank()) {
            errores.add("El apellido es obligatorio");
        }

        if (dto.getRol() != null) {
            String rol = dto.getRol().toUpperCase();
            if (!rol.equals("CLIENTE") && !rol.equals("ENTRENADOR") &&
                    !rol.equals("NUTRICIONISTA") && !rol.equals("ADMIN")) {
                errores.add("Rol inválido: " + dto.getRol());
            }
        }

        if (!errores.isEmpty()) {
            throw new ValidationException(errores);
        }
    }

    public void validarPassword(String password) {
        if (password == null || password.length() < 6) {
            throw new ValidationException("La contraseña debe tener al menos 6 caracteres");
        }
    }
}
