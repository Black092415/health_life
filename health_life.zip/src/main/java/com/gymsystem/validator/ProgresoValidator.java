package com.gymsystem.validator;

import com.gymsystem.exception.ValidationException;
import com.gymsystem.model.ProgresoFisico;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ProgresoValidator {

    public void validarRegistroPeso(ProgresoFisico progreso) {
        List<String> errores = new ArrayList<>();

        if (progreso.getCliente() == null || progreso.getCliente().getId() == null) {
            errores.add("El cliente es obligatorio");
        }

        if (progreso.getPesoKg() == null) {
            errores.add("El peso es obligatorio");
        } else if (progreso.getPesoKg().compareTo(BigDecimal.ZERO) <= 0) {
            errores.add("El peso debe ser mayor a 0");
        } else if (progreso.getPesoKg().compareTo(BigDecimal.valueOf(300)) > 0) {
            errores.add("El peso no puede ser mayor a 300 kg");
        }

        if (progreso.getPorcentajeGrasa() != null &&
                (progreso.getPorcentajeGrasa().compareTo(BigDecimal.ZERO) < 0 ||
                 progreso.getPorcentajeGrasa().compareTo(BigDecimal.valueOf(100)) > 0)) {
            errores.add("El porcentaje de grasa debe estar entre 0 y 100");
        }

        if (!errores.isEmpty()) {
            throw new ValidationException(errores);
        }
    }
}
