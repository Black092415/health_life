# Sistema de Gestión para Gimnasios y Nutricionistas - Análisis

## REQUERIMIENTOS FUNCIONALES

### Módulo Autenticación y Roles
- RF-01: El sistema debe permitir el registro de usuarios con credenciales únicas.
- RF-02: El sistema debe autenticar usuarios mediante email y contraseña hasheada.
- RF-03: El sistema debe soportar 4 roles: Administrador, Entrenador, Nutricionista, Cliente.
- RF-04: El sistema debe restringir el acceso a funcionalidades según el rol.
- RF-05: El sistema debe gestionar sesiones activas.

### Módulo Clientes
- RF-06: El sistema debe registrar clientes con datos personales y de contacto.
- RF-07: El sistema debe permitir actualizar datos del cliente.
- RF-08: El sistema debe permitir buscar clientes por nombre, email o documento.

### Módulo Entrenadores
- RF-09: El sistema debe registrar entrenadores con sus especialidades.
- RF-10: El sistema debe asignar entrenadores a clientes.

### Módulo Nutricionistas
- RF-11: El sistema debe registrar nutricionistas con sus credenciales profesionales.
- RF-12: El sistema debe asignar nutricionistas a clientes.

### Módulo Rutinas
- RF-13: El sistema debe crear rutinas con ejercicios, series, repeticiones y descanso.
- RF-14: El sistema debe asignar rutinas a clientes con fecha de inicio y fin.
- RF-15: El sistema debe categorizar ejercicios por grupo muscular y tipo.

### Módulo Planes Alimenticios
- RF-16: El sistema debe crear planes alimenticios con comidas distribuidas en el día.
- RF-17: El sistema debe asignar planes a clientes con fechas de vigencia.
- RF-18: El sistema debe especificar macronutrientes por comida.

### Módulo Seguimiento Corporal
- RF-19: El sistema debe registrar peso corporal con fecha.
- RF-20: El sistema debe registrar medidas corporales (cintura, cadera, etc.).
- RF-21: El sistema debe calcular IMC automáticamente.
- RF-22: El sistema debe generar historial de progreso del cliente.

### Módulo Estadísticas
- RF-23: El sistema debe generar estadísticas de evolución de peso.
- RF-24: El sistema debe mostrar progreso en medidas corporales.
- RF-25: El sistema debe calcular variaciones porcentuales.

### Módulo Recordatorios
- RF-26: El sistema debe crear recordatorios de entrenamiento.
- RF-27: El sistema debe listar recordatorios por cliente y fecha.

## REQUERIMIENTOS NO FUNCIONALES

- RNF-01: Escalabilidad horizontal vía pool de conexiones JDBC.
- RNF-02: Seguridad con hashing BCrypt para contraseñas.
- RNF-03: Logging estructurado con SLF4J + Logback.
- RNF-04: Normalización de base de datos hasta 3FN.
- RNF-05: Código fuente con principios SOLID.
- RNF-06: Documentación del código en español.
- RNF-07: Preparado para integración con Vaadin.

## CASOS DE USO

| Código | Nombre | Actor Principal |
|--------|--------|----------------|
| CU-01 | Iniciar Sesión | Todos |
| CU-02 | Cerrar Sesión | Todos |
| CU-03 | Registrar Cliente | Administrador |
| CU-04 | Modificar Cliente | Administrador, Entrenador |
| CU-05 | Asignar Entrenador | Administrador |
| CU-06 | Asignar Nutricionista | Administrador |
| CU-07 | Crear Rutina | Entrenador |
| CU-08 | Asignar Rutina a Cliente | Entrenador |
| CU-09 | Crear Plan Alimenticio | Nutricionista |
| CU-10 | Asignar Plan a Cliente | Nutricionista |
| CU-11 | Registrar Peso | Cliente |
| CU-12 | Registrar Medidas | Cliente, Nutricionista |
| CU-13 | Ver Historial Progreso | Cliente, Entrenador, Nutricionista |
| CU-14 | Generar Estadísticas | Entrenador, Nutricionista |
| CU-15 | Gestionar Recordatorios | Entrenador, Cliente |
| CU-16 | Ver Rutina Asignada | Cliente |

## HISTORIAS DE USUARIO

- HU-01: Como administrador, quiero registrar clientes para gestionar su membresía.
- HU-02: Como entrenador, quiero crear rutinas personalizadas para asignarlas a mis clientes.
- HU-03: Como nutricionista, quiero diseñar planes alimenticios para mis pacientes.
- HU-04: Como cliente, quiero registrar mi peso para ver mi evolución.
- HU-05: Como cliente, quiero ver mi rutina asignada para seguirla en el gimnasio.
- HU-06: Como entrenador, quiero ver el progreso de mis clientes para ajustar las rutinas.
- HU-07: Como nutricionista, quiero registrar medidas corporales para evaluar resultados.
- HU-08: Como administrador, quiero gestionar usuarios del sistema para controlar accesos.

## REGLAS DE NEGOCIO

- RN-01: Un cliente puede tener solo un entrenador activo a la vez.
- RN-02: Un cliente puede tener solo un plan alimenticio activo a la vez.
- RN-03: Un cliente puede tener múltiples rutinas (una activa por tipo).
- RN-04: El peso debe ser un valor positivo mayor a 0.
- RN-05: La altura debe estar entre 0.5m y 2.5m.
- RN-06: El IMC se calcula como peso(kg) / altura(m)^2.
- RN-07: Un entrenador no puede crear planes alimenticios (solo nutricionistas).
- RN-08: Un nutricionista no puede crear rutinas de ejercicio (solo entrenadores).
- RN-09: Las contraseñas deben almacenarse hasheadas con BCrypt.
- RN-10: El email debe ser único en el sistema.

## DIAGRAMA CONCEPTUAL DE MÓDULOS

```
┌─────────────────────────────────────────────────────────────┐
│                    SISTEMA GYM & NUTRICIÓN                   │
├──────────┬──────────┬──────────┬──────────┬──────────┬──────┤
│          │          │          │          │          │      │
│  Auth &  │Clientes  │Rutinas   │  Planes  │Seguim.  │Repo-  │
│  Roles   │   &      │   &      │Aliment.  │ Corporal│rtes   │
│          │Usuarios  │Ejercicios│          │   &      │       │
│          │          │          │          │Estadís.  │       │
├──────────┴──────────┴──────────┴──────────┴──────────┴──────┤
│                    CAPA DE SERVICIOS (Service)               │
├─────────────────────────────────────────────────────────────┤
│                    CAPA DE ACCESO (DAO)                      │
├─────────────────────────────────────────────────────────────┤
│                    BASE DE DATOS (PostgreSQL)                │
└─────────────────────────────────────────────────────────────┘
```
