-- ============================================================
-- SISTEMA DE GESTIÓN PARA GIMNASIOS Y NUTRICIONISTAS
-- Motor: PostgreSQL 16
-- Esquema: gym_system
-- ============================================================

-- DROP SCHEMA IF EXISTS gym_system CASCADE;
CREATE SCHEMA IF NOT EXISTS gym_system;

SET search_path TO gym_system;

-- ============================================================
-- TABLA: roles
-- ============================================================
CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion VARCHAR(255),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLA: usuarios (autenticación y control de acceso)
-- ============================================================
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    ultimo_acceso TIMESTAMP,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLA: usuarios_roles (relación muchos a muchos)
-- ============================================================
CREATE TABLE usuarios_roles (
    usuario_id INTEGER NOT NULL,
    rol_id INTEGER NOT NULL,
    PRIMARY KEY (usuario_id, rol_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (rol_id) REFERENCES roles(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: clientes
-- ============================================================
CREATE TABLE clientes (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL UNIQUE,
    fecha_nacimiento DATE,
    genero CHAR(1) CHECK (genero IN ('M', 'F', 'O')),
    altura DECIMAL(4,2) CHECK (altura > 0 AND altura <= 2.50),
    telefono_emergencia VARCHAR(20),
    notas_medicas TEXT,
    objetivo VARCHAR(100),
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: entrenadores
-- ============================================================
CREATE TABLE entrenadores (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL UNIQUE,
    especialidad VARCHAR(100),
    certificacion VARCHAR(255),
    anios_experiencia INTEGER CHECK (anios_experiencia >= 0),
    horario_disponible TEXT,
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: nutricionistas
-- ============================================================
CREATE TABLE nutricionistas (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL UNIQUE,
    numero_licencia VARCHAR(50) NOT NULL UNIQUE,
    especialidad VARCHAR(100),
    anios_experiencia INTEGER CHECK (anios_experiencia >= 0),
    horario_disponible TEXT,
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: asignaciones (cliente-entrenador y cliente-nutricionista)
-- ============================================================
CREATE TABLE asignaciones (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER NOT NULL,
    entrenador_id INTEGER,
    nutricionista_id INTEGER,
    fecha_asignacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_fin TIMESTAMP,
    activa BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE,
    FOREIGN KEY (entrenador_id) REFERENCES entrenadores(id) ON DELETE SET NULL,
    FOREIGN KEY (nutricionista_id) REFERENCES nutricionistas(id) ON DELETE SET NULL,
    CONSTRAINT asignacion_valida CHECK (
        entrenador_id IS NOT NULL OR nutricionista_id IS NOT NULL
    )
);

-- ============================================================
-- TABLA: ejercicios
-- ============================================================
CREATE TABLE ejercicios (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    grupo_muscular VARCHAR(50) NOT NULL,
    tipo_ejercicio VARCHAR(50) NOT NULL,
    equipo_necesario VARCHAR(100),
    nivel_dificultad VARCHAR(20) CHECK (nivel_dificultad IN ('principiante', 'intermedio', 'avanzado')),
    url_referencia VARCHAR(500),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLA: rutinas
-- ============================================================
CREATE TABLE rutinas (
    id SERIAL PRIMARY KEY,
    entrenador_id INTEGER NOT NULL,
    cliente_id INTEGER,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    objetivo VARCHAR(100),
    duracion_semanas INTEGER CHECK (duracion_semanas > 0),
    frecuencia_semanal INTEGER CHECK (frecuencia_semanal BETWEEN 1 AND 7),
    nivel VARCHAR(20) CHECK (nivel IN ('principiante', 'intermedio', 'avanzado')),
    fecha_inicio DATE,
    fecha_fin DATE,
    activa BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (entrenador_id) REFERENCES entrenadores(id) ON DELETE CASCADE,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
);

-- ============================================================
-- TABLA: rutina_ejercicios (detalle de ejercicios en rutina)
-- ============================================================
CREATE TABLE rutina_ejercicios (
    id SERIAL PRIMARY KEY,
    rutina_id INTEGER NOT NULL,
    ejercicio_id INTEGER NOT NULL,
    orden_ejecucion INTEGER NOT NULL CHECK (orden_ejecucion > 0),
    series INTEGER NOT NULL CHECK (series > 0),
    repeticiones INTEGER CHECK (repeticiones > 0),
    duracion_segundos INTEGER CHECK (duracion_segundos > 0),
    descanso_segundos INTEGER CHECK (descanso_segundos >= 0),
    notas TEXT,
    UNIQUE (rutina_id, ejercicio_id, orden_ejecucion),
    FOREIGN KEY (rutina_id) REFERENCES rutinas(id) ON DELETE CASCADE,
    FOREIGN KEY (ejercicio_id) REFERENCES ejercicios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: planes_alimenticios
-- ============================================================
CREATE TABLE planes_alimenticios (
    id SERIAL PRIMARY KEY,
    nutricionista_id INTEGER NOT NULL,
    cliente_id INTEGER,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    objetivo_calorias DECIMAL(7,2),
    objetivo_proteinas DECIMAL(7,2),
    objetivo_carbohidratos DECIMAL(7,2),
    objetivo_grasas DECIMAL(7,2),
    objetivo_agua_lts DECIMAL(4,2),
    fecha_inicio DATE,
    fecha_fin DATE,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (nutricionista_id) REFERENCES nutricionistas(id) ON DELETE CASCADE,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
);

-- ============================================================
-- TABLA: comidas
-- ============================================================
CREATE TABLE comidas (
    id SERIAL PRIMARY KEY,
    plan_alimenticio_id INTEGER NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    tipo_comida VARCHAR(50) NOT NULL CHECK (tipo_comida IN (
        'desayuno', 'media_manana', 'almuerzo', 'merienda', 'cena', 'postre', 'colacion'
    )),
    hora_sugerida TIME,
    orden_dia INTEGER NOT NULL CHECK (orden_dia > 0),
    calorias DECIMAL(7,2),
    proteinas_gramos DECIMAL(7,2),
    carbohidratos_gramos DECIMAL(7,2),
    grasas_gramos DECIMAL(7,2),
    porcion_descripcion TEXT,
    notas_preparacion TEXT,
    FOREIGN KEY (plan_alimenticio_id) REFERENCES planes_alimenticios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: progreso_fisico (registro de peso periódico)
-- ============================================================
CREATE TABLE progreso_fisico (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER NOT NULL,
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    peso_kg DECIMAL(5,2) NOT NULL CHECK (peso_kg > 0),
    imc DECIMAL(4,2),
    porcentaje_grasa DECIMAL(4,2) CHECK (porcentaje_grasa >= 0 AND porcentaje_grasa <= 100),
    masa_muscular_kg DECIMAL(5,2) CHECK (masa_muscular_kg > 0),
    notas TEXT,
    registrado_por VARCHAR(50) NOT NULL DEFAULT 'cliente',
    UNIQUE (cliente_id, fecha_registro),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: medidas_corporales
-- ============================================================
CREATE TABLE medidas_corporales (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER NOT NULL,
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cintura_cm DECIMAL(5,2) CHECK (cintura_cm > 0),
    cadera_cm DECIMAL(5,2) CHECK (cadera_cm > 0),
    pecho_cm DECIMAL(5,2) CHECK (pecho_cm > 0),
    brazo_izq_cm DECIMAL(5,2) CHECK (brazo_izq_cm > 0),
    brazo_der_cm DECIMAL(5,2) CHECK (brazo_der_cm > 0),
    pierna_izq_cm DECIMAL(5,2) CHECK (pierna_izq_cm > 0),
    pierna_der_cm DECIMAL(5,2) CHECK (pierna_der_cm > 0),
    cintura_cadera_ratio DECIMAL(4,2),
    notas TEXT,
    registrado_por VARCHAR(50) NOT NULL DEFAULT 'nutricionista',
    UNIQUE (cliente_id, fecha_registro),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: recordatorios
-- ============================================================
CREATE TABLE recordatorios (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER NOT NULL,
    creado_por INTEGER NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT,
    tipo VARCHAR(50) NOT NULL CHECK (tipo IN (
        'entrenamiento', 'cita_nutricion', 'pesaje', 'medicion', 'general'
    )),
    fecha_programada TIMESTAMP NOT NULL,
    fecha_completado TIMESTAMP,
    completado BOOLEAN NOT NULL DEFAULT FALSE,
    recurrencia VARCHAR(20) CHECK (recurrencia IN (
        'unico', 'diario', 'semanal', 'quincenal', 'mensual'
    )),
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE,
    FOREIGN KEY (creado_por) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: sesiones (control de sesiones activas)
-- ============================================================
CREATE TABLE sesiones (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    ip_address VARCHAR(45),
    fecha_inicio TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion TIMESTAMP NOT NULL,
    activa BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLA: auditoria_log (log de operaciones críticas)
-- ============================================================
CREATE TABLE auditoria_log (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER,
    accion VARCHAR(100) NOT NULL,
    entidad VARCHAR(100),
    entidad_id INTEGER,
    detalle TEXT,
    ip_address VARCHAR(45),
    fecha_evento TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- ÍNDICES
-- ============================================================

-- Usuarios
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_username ON usuarios(username);
CREATE INDEX idx_usuarios_activo ON usuarios(activo);

-- Clientes
CREATE INDEX idx_clientes_usuario ON clientes(usuario_id);
CREATE INDEX idx_clientes_objetivo ON clientes(objetivo);

-- Asignaciones
CREATE INDEX idx_asignaciones_cliente ON asignaciones(cliente_id);
CREATE INDEX idx_asignaciones_entrenador ON asignaciones(entrenador_id);
CREATE INDEX idx_asignaciones_nutricionista ON asignaciones(nutricionista_id);
CREATE INDEX idx_asignaciones_activa ON asignaciones(activa);

-- Ejercicios y Rutinas
CREATE INDEX idx_ejercicios_grupo_muscular ON ejercicios(grupo_muscular);
CREATE INDEX idx_ejercicios_tipo ON ejercicios(tipo_ejercicio);
CREATE INDEX idx_rutinas_entrenador ON rutinas(entrenador_id);
CREATE INDEX idx_rutinas_cliente ON rutinas(cliente_id);
CREATE INDEX idx_rutinas_activa ON rutinas(activa);
CREATE INDEX idx_rutina_ejercicios_rutina ON rutina_ejercicios(rutina_id);

-- Planes y Comidas
CREATE INDEX idx_planes_nutricionista ON planes_alimenticios(nutricionista_id);
CREATE INDEX idx_planes_cliente ON planes_alimenticios(cliente_id);
CREATE INDEX idx_planes_activo ON planes_alimenticios(activo);
CREATE INDEX idx_comidas_plan ON comidas(plan_alimenticio_id);

-- Progreso y Medidas
CREATE INDEX idx_progreso_cliente ON progreso_fisico(cliente_id);
CREATE INDEX idx_progreso_fecha ON progreso_fisico(cliente_id, fecha_registro DESC);
CREATE INDEX idx_medidas_cliente ON medidas_corporales(cliente_id);
CREATE INDEX idx_medidas_fecha ON medidas_corporales(cliente_id, fecha_registro DESC);

-- Recordatorios
CREATE INDEX idx_recordatorios_cliente ON recordatorios(cliente_id);
CREATE INDEX idx_recordatorios_fecha ON recordatorios(cliente_id, fecha_programada);
CREATE INDEX idx_recordatorios_completado ON recordatorios(completado);

-- Sesiones y Auditoría
CREATE INDEX idx_sesiones_usuario ON sesiones(usuario_id);
CREATE INDEX idx_sesiones_token ON sesiones(token);
CREATE INDEX idx_sesiones_activa ON sesiones(activa);
CREATE INDEX idx_auditoria_usuario ON auditoria_log(usuario_id);
CREATE INDEX idx_auditoria_fecha ON auditoria_log(fecha_evento DESC);
CREATE INDEX idx_auditoria_accion ON auditoria_log(accion);

-- ============================================================
-- FUNCIÓN: actualizar fecha_actualizacion automáticamente
-- ============================================================
CREATE OR REPLACE FUNCTION actualizar_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.fecha_actualizacion = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_usuarios_actualizacion
    BEFORE UPDATE ON usuarios
    FOR EACH ROW
    EXECUTE FUNCTION actualizar_timestamp();

-- ============================================================
-- FUNCIÓN: calcular IMC automáticamente
-- ============================================================
CREATE OR REPLACE FUNCTION calcular_imc()
RETURNS TRIGGER AS $$
DECLARE
    v_altura DECIMAL(4,2);
BEGIN
    SELECT altura INTO v_altura FROM clientes WHERE id = NEW.cliente_id;
    IF v_altura IS NOT NULL AND v_altura > 0 THEN
        NEW.imc = ROUND((NEW.peso_kg / (v_altura * v_altura))::numeric, 2);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_progreso_imc
    BEFORE INSERT OR UPDATE OF peso_kg ON progreso_fisico
    FOR EACH ROW
    EXECUTE FUNCTION calcular_imc();

-- ============================================================
-- FUNCIÓN: calcular ratio cintura-cadera
-- ============================================================
CREATE OR REPLACE FUNCTION calcular_cintura_cadera()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.cintura_cm IS NOT NULL AND NEW.cadera_cm IS NOT NULL AND NEW.cadera_cm > 0 THEN
        NEW.cintura_cadera_ratio = ROUND((NEW.cintura_cm / NEW.cadera_cm)::numeric, 2);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_medidas_cintura_cadera
    BEFORE INSERT OR UPDATE OF cintura_cm, cadera_cm ON medidas_corporales
    FOR EACH ROW
    EXECUTE FUNCTION calcular_cintura_cadera();

-- ============================================================
-- DATOS INICIALES: Roles del sistema
-- ============================================================
INSERT INTO roles (nombre, descripcion) VALUES
    ('ADMIN', 'Administrador del sistema con acceso total'),
    ('ENTRENADOR', 'Profesional de entrenamiento físico'),
    ('NUTRICIONISTA', 'Profesional en nutrición y dietética'),
    ('CLIENTE', 'Usuario final que recibe los servicios');

-- ============================================================
-- DATOS INICIALES: Usuario administrador por defecto
-- Password: admin123 (BCrypt hash)
-- ============================================================
INSERT INTO usuarios (username, email, password_hash, nombre, apellido)
VALUES (
    'admin',
    'admin@gymsystem.com',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    'Administrador',
    'Sistema'
);

INSERT INTO usuarios_roles (usuario_id, rol_id) VALUES (1, 1);
